﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Quran2.CustomControl
{
    public class POSSuggestionBox : SuggestionBoxBase
    {
        protected override ICollectionView source => App.POS;
        protected override void setQueryAndRefresh() {
            App.posQuery = Text.ToLower();
            App.POS.Refresh();
        }
        protected override void setText() {
            Text = ((PartsOfSpeech)listSuggestion.SelectedItem).Tag;
        }
    }
}
