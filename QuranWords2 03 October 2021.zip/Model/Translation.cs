﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quran2
{
    public class Translation
    {
        public int Surah { get; set; }
        public int Ayah { get; set; }
        public string Bangla { get; set; }
        public string English { get; set; }
    }
}
