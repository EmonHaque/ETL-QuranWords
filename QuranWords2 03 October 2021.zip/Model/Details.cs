﻿namespace Quran2
{
    public class Details
    {
        public int Id { get; set; }
        public string Tag { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public override string ToString() {
            return Tag + " " + Name + " " + Description;
        }
    }
}
