﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quran2
{
    public class Morph
    {
        public string Word { get; set; }
        public string Tags { get; set; }
        public int Times { get; set; }
    }
}
