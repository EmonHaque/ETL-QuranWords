﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace Quran2
{
    public partial class App : Application
    {
        public static object Key;
        public static string detailsQuery, posQuery;
        CollectionViewSource posSource, detailSource;
        public static List<Occurence> occurenceList;
        public static List<CorpusData> corpusData;
        public static List<CorpusData> concatData;
        public static List<Word> words;
        public static List<Segment> segments;
        public static List<PartsOfSpeech> poss;
        public static List<Details> details;
        public static List<Translation> translation;
        public static List<Root> roots;
        public static List<RootLess> rootLess;
        public static ICollectionView POS { get; set; }
        public static ICollectionView Details { get; set; }
        public static event Action WordsRenewed;
        protected override void OnStartup(StartupEventArgs e) {
            Key = new object();
            base.OnStartup(e);
            getData();
            posSource = new CollectionViewSource() { Source = App.poss };
            detailSource = new CollectionViewSource() { Source = App.details };
            POS = posSource.View;
            Details = detailSource.View;
            POS.Filter = filterPOS;
            Details.Filter = filterDetails;
            SegmentView.SegmentsAdded += onSegmentAdded;
        }

        void onSegmentAdded() {
            concatData = App.corpusData
                .GroupBy(x => new { x.Surah, x.Ayah, x.Word })
                .Select(x => new CorpusData {
                    Surah = x.Key.Surah,
                    Ayah = x.Key.Ayah,
                    Word = x.Key.Word,
                    Content = string.Join(null, x.Select(y => y.Content)),
                    POS = string.Join(',', x.Select(y => y.POS))
                })
                .ToList();

            words = new List<Word>();
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = @"WITH T (Surah, Ayah, Word, Segments) AS(
                                    	SELECT Surah, Ayah, Word, Count(Segment) 
                                    	FROM CorpusSegment
                                    	GROUP BY Surah, Ayah, Word
                                    )
                                    SELECT Minimal, Corpus, IsOk, Minimal = Corpus IsSpellingOk,
                                    Segments, count(*) Occurence FROM Words w
                                    LEFT JOIN T t ON (t.Surah = w.Surah AND t.Ayah = w.Ayah AND t.Word = WordNo)
                                    GROUP BY Minimal, Corpus
                                    ORDER BY Segments DESC";
            var reader = command.ExecuteReader();
            while (reader.Read()) {
                words.Add(new Word() {
                    Minimal = reader.GetString(0),
                    Corpus = reader.GetString(1),
                    IsOk = reader.IsDBNull(2) ? false : true,
                    IsSpellingOk = reader.GetBoolean(3),
                    Segments = reader.GetInt32(4),
                    Occurence = reader.GetInt32(5)
                });
            }
            WordsRenewed?.Invoke();
        }

        void getData() {
            occurenceList = new List<Occurence>();
            corpusData = new List<CorpusData>();
            words = new List<Word>();
            segments = new List<Segment>();
            poss = new List<PartsOfSpeech>();
            details = new List<Details>();
            translation = new List<Translation>();
            roots = new List<Root>();
            rootLess = new List<RootLess>();

            List<Word> internalWords = new();
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = @"SELECT * FROM Words;
                                    WITH T (Surah, Ayah, Word, Segments) AS(
                                    	SELECT Surah, Ayah, Word, Count(Segment) 
                                    	FROM CorpusSegment
                                    	GROUP BY Surah, Ayah, Word
                                    )
                                    SELECT Minimal, Corpus, IsOk, Minimal = Corpus IsSpellingOk,
                                    Segments, count(*) Occurence FROM Words w
                                    LEFT JOIN T t ON (t.Surah = w.Surah AND t.Ayah = w.Ayah AND t.Word = WordNo)
                                    GROUP BY Minimal, Corpus
                                    ORDER BY Segments DESC;
                                    SELECT * FROM CorpusSegment;
                                    SELECT * FROM PartsOfSpeech;
                                    SELECT * FROM Details;
                                    SELECT * FROM Translation;
                                    SELECT * FROM Roots;
                                    SELECT DISTINCT Content, POS, Detail, count(*) Occurence FROM CorpusSegment
                                    WHERE Root IS NULL OR Root = ''
                                    GROUP BY Content, POS, Detail
                                    ORDER BY Content";

            var reader = command.ExecuteReader();
            while (reader.Read()) {
                occurenceList.Add(new Occurence() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    WordNo = reader.GetInt32(2),
                    Minimal = reader.GetString(3),
                    Corpus = reader.IsDBNull(4) ? null : reader.GetString(4),
                    IsOk = reader.IsDBNull(5) ? false : true
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                words.Add(new Word() {
                    Minimal = reader.GetString(0),
                    Corpus = reader.GetString(1),
                    IsOk = reader.IsDBNull(2) ? false : true,
                    IsSpellingOk = reader.GetBoolean(3),
                    Segments = reader.GetInt32(4),
                    Occurence = reader.GetInt32(5)
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                corpusData.Add(new CorpusData() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    Word = reader.GetInt32(2),
                    Segment = reader.GetInt32(3),
                    Content = reader.GetString(4),
                    POS = reader.GetString(5),
                    Detail = reader.IsDBNull(6) ? null : reader.GetString(6),
                    Root = reader.IsDBNull(7) ? null : reader.GetString(7),
                    IsOk = reader.IsDBNull(8) ? false : true,
                    CleanWord = reader.IsDBNull(9) ? "" : reader.GetString(9)
                });
            }
            
            reader.NextResult();
            while (reader.Read()) {
                poss.Add(new PartsOfSpeech() {
                    Id = reader.GetInt32(0),
                    Name = reader.IsDBNull(1) ? "" : reader.GetString(1),
                    Tag = reader.GetString(2),
                    Description = reader.GetString(3)
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                details.Add(new Details() {
                    Id = reader.GetInt32(0),
                    Tag = reader.GetString(1),
                    Name = reader.IsDBNull(2) ? "" : reader.GetString(2),
                    Description = reader.GetString(3)
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                translation.Add(new Translation() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    Bangla = reader.GetString(2),
                    English = reader.GetString(3)
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                roots.Add(new Root() {
                    Id = reader.GetInt32(0),
                    CorpusRoot = reader.GetString(1),
                    PRLKey = reader.IsDBNull(2) ? "" : reader.GetString(2),
                    Meaning = reader.IsDBNull(3) ? "" : reader.GetString(3),
                    Reference = reader.IsDBNull(4) ? "" : reader.GetString(4),
                    IsCorpusRoot = reader.IsDBNull(5) ? false : true,
                    IsOk = reader.IsDBNull(6) ? false : true
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                rootLess.Add(new RootLess() {
                    Content = reader.GetString(0),
                    POS = reader.GetString(1),
                    Detail = reader.IsDBNull(2) ? "" : reader.GetString(2),
                    Occurence = reader.GetInt32(3)
                });
            }

            connection.Close();

            getSegments();
            onSegmentAdded();

            getCleanWords(internalWords);
        }

        void getCleanWords(List<Word> internalWords) {
            foreach (var item in internalWords) {
                var old = item.Minimal;
                if (item.Minimal.StartsWith("ال")) {
                    var s = item.Minimal.Substring(3, 2);
                    if (s.Equals("َّ") /*fatha*/ ||
                        s.Equals("ِّ") /*kesra*/ ||
                        s.Equals("ُّ") /*damma*/) {
                        item.Minimal = item.Minimal.Remove(3, 1);
                    }
                    else if (s[0].Equals('ّ'))
                        item.Minimal = item.Minimal.Remove(3, 1);
                }
                if (item.Minimal.StartsWith("وَال")) {
                    var s = item.Minimal.Substring(5, 2);
                    if (s.Equals("َّ") /*fatha*/ ||
                        s.Equals("ِّ") /*kesra*/ ||
                        s.Equals("ُّ") /*damma*/) {
                        item.Minimal = item.Minimal.Remove(5, 1);
                    }
                    else if (s[0].Equals('ّ'))
                        item.Minimal = item.Minimal.Remove(5, 1);
                }
                if (item.Minimal.StartsWith("فَال")) {
                    var s = item.Minimal.Substring(5, 2);
                    if (s.Equals("َّ") /*fatha*/ ||
                        s.Equals("ِّ") /*kesra*/ ||
                        s.Equals("ُّ") /*damma*/) {
                        item.Minimal = item.Minimal.Remove(5, 1);
                    }
                    else if (s[0].Equals('ّ'))
                        item.Minimal = item.Minimal.Remove(5, 1);
                }
                if (item.Minimal.Contains("ىٰ")) {
                    item.Minimal = item.Minimal.Replace("ىٰ", "ى");
                }
                if (item.Minimal.Contains("ٰ" /*dragger*/)) {
                    item.Minimal = item.Minimal.Replace('ٰ', 'َ') /*replace dragger with fatha*/;
                }
                if (item.Minimal.Contains("نَا")) {
                    item.Minimal = item.Minimal.Replace("نَا", "نا");
                }
                if (item.Minimal.Contains("هَا")) {
                    item.Minimal = item.Minimal.Replace("هَا", "ها");
                }
                if (!item.Minimal.Contains("أُ") &&
                    !item.Minimal.Contains("ُوَ") &&
                    !item.Minimal.Contains("ُوِ") &&
                    !item.Minimal.Contains("ُوّ") &&
                    item.Minimal.Contains("ُو")) {
                    item.Minimal = item.Minimal.Replace("ُو", "و");
                }
                if (item.Minimal.Contains("ِي")) {
                    if (!item.Minimal.Contains("ِيا") &&
                        !item.Minimal.Contains("ِيَ") &&
                        !item.Minimal.Contains("ِيّ"))
                        item.Minimal = item.Minimal.Replace("ِي", "ي");
                }
                if (item.Minimal.Contains("َا")) {
                    if (!item.Minimal.StartsWith("كَ") &&
                       !item.Minimal.StartsWith("فَ") &&
                       !item.Minimal.StartsWith("وَ"))

                        item.Minimal = item.Minimal.Replace("َا", "ا");
                }
                if (item.Minimal.Contains("َى")) {
                    item.Minimal = item.Minimal.Replace("َى", "ى");
                }
                if (item.Minimal.StartsWith("بِال")) {
                    var s = item.Minimal.Substring(5, 2);
                    if (s.Equals("َّ") /*fatha*/ ||
                         s.Equals("ِّ") /*kesra*/ ||
                         s.Equals("ُّ") /*damma*/) {
                        item.Minimal = item.Minimal.Remove(5, 1);
                    }
                    else if (s[0].Equals('ّ'))
                        item.Minimal = item.Minimal.Remove(5, 1);
                }
                if (item.Minimal.StartsWith("لِل")) {
                    var s = item.Minimal.Substring(4, 2);
                    var p = s[0];
                    if (s.Equals("َّ") /*fatha*/ ||
                        s.Equals("ِّ") /*kesra*/ ||
                        s.Equals("ُّ") /*damma*/) {
                        item.Minimal = item.Minimal.Remove(4, 1);
                    }
                    else if (s[0].Equals('ّ'))
                        item.Minimal = item.Minimal.Remove(4, 1);

                }

                if (!item.Minimal.Equals(item.Corpus)) {
                   
                        words.Add(item);
                }
            }
        }

        public static void getSegments() {
            segments = corpusData
                .Where(x => !x.IsOk)
                .Select(x => new { x.Content, x.Root, x.POS, x.Detail })
                .GroupBy(x => new { x.Content, x.Root, x.POS, x.Detail }, (g, l) => new Segment {
                    Content = g.Content,
                    Root = g.Root,
                    POS = g.POS,
                    Detail = g.Detail,
                    Occurence = l.Count()
                }).ToList();
        }

        bool filterDetails(object o) {
            if (string.IsNullOrWhiteSpace(detailsQuery)) return true;
            var pos = (Details)o;
            return pos.Description.ToLower().Contains(detailsQuery);
        }

        bool filterPOS(object o) {
            if (string.IsNullOrWhiteSpace(posQuery)) return true;
            var pos = (PartsOfSpeech)o;
            return pos.Description.ToLower().Contains(posQuery);
        }
    }
}
