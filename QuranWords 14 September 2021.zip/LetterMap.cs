﻿namespace QuranWords
{
    public class LetterMap
    {
        public char English { get; set; }
        public char Arabic { get; set; }
    }
}
