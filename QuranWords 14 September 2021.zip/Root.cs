﻿namespace QuranWords
{
    public class Root
    {
        public string English { get; set; }
        public string Arabic { get; set; }
    }
}
