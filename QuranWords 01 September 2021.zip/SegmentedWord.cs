﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuranWords
{
    public class SegmentedWord : INotifyPropertyChanged
    {
        public int Ayah { get; set; }
        public int WordNo { get; set; }
        public int SegmentNo { get; set; }
        public string Clean { get; set; }
        public string Minimal { get; set; }
        public string Full { get; set; }
        int pos;
        public int POS {
            get { return pos; }
            set { pos = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(POS))); }
        }
        string meaning;

        public string Meaning {
            get { return meaning; }
            set { meaning = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Meaning))); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

    }
}
