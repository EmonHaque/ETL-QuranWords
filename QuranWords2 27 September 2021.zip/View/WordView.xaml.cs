﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords2
{
    public partial class WordView : UserControl, INotifyPropertyChanged
    {
        string query;
        bool isOnEdit;
        //List<CorpusData> concatData;
        Word selectedWord;
        public Word SelectedWord {
            get { return selectedWord; }
            set { selectedWord = value; getCurrent(); }
        }
        Morph selectedMorph;
        public Morph SelectedMorph {
            get { return selectedMorph; }
            set { selectedMorph = value; resetCurrent(); }
        }
        bool verified;
        public bool Verified {
            get { return verified; }
            set { verified = value; Words.Refresh(); }
        }

        public ICollectionView Words { get; set; }
        public ObservableCollection<CorpusData> CurrentData { get; set; }
        public ObservableCollection<CorpusData> EditedData { get; set; }
        public ObservableCollection<Morph> Morphs { get; set; }
        public static event Action<List<Tuple<int, int>>> WordChanged;
        public static event Action SegmentsChanged;
        public event PropertyChangedEventHandler PropertyChanged;

        public WordView() {
            InitializeComponent();
            Words = new CollectionViewSource() { 
                Source = App.words,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = {"IsOk"}
            }.View;
            Words.Filter = filterGetAll;
            CurrentData = new();
            EditedData = new();
            Morphs = new();
            DataContext = this;
            SurahView.WordEdited += onWordEdited;
            App.WordsRenewed += onWordsRenewed;
        }

        void onWordsRenewed() {
            var oldSelected = SelectedWord;
            Words = new CollectionViewSource() {
                Source = App.words,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { "IsOk" }
            }.View;
            onFilterChanged(null, null);

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Words)));
            SelectedWord = App.words.FirstOrDefault(x => x.Corpus.Equals(oldSelected.Corpus) && x.Minimal.Equals(oldSelected.Minimal));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedWord)));
            wordList.ScrollIntoView(SelectedWord);
        }

        void onWordEdited(List<CorpusData> segments) {
            var first = segments.First();
            var data = App.concatData.First(x => x.Surah == first.Surah && x.Ayah == first.Ayah && x.Word == first.Word);
            data.POS = string.Join(',', segments.Select(x => x.POS));
            if (SelectedMorph.Word.Equals(data.Content)) {
                getMorphs();
                SelectedMorph = Morphs.First();
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMorph)));
            }
        }

        bool filterDifference(object o) {
            var word = (Word)o;
            if (string.IsNullOrWhiteSpace(query))
                return !word.IsSpellingOk && word.IsOk == Verified;
            return word.Corpus.Contains(query) && !word.IsSpellingOk && word.IsOk == Verified;
        }
        
        bool filterGetAll(object o) {
            var word = (Word)o;
            if (string.IsNullOrWhiteSpace(query)) return word.IsOk == Verified;
            return word.Corpus.Contains(query) && word.IsOk == Verified;
        }

        bool filterPatternStartsWith(object o) {
            var word = ((Word)o);
            if (string.IsNullOrWhiteSpace(query))
                return word.IsOk == Verified;

            bool match = word.Corpus.Length >= query.Length && word.IsOk == Verified;
            if (match) {
                for (int i = 0; i < query.Length; i++) {
                    if (query[i].Equals('ـ')) continue; // Shift + B
                    if (!query[i].Equals(word.Corpus[i])) {
                        match = false;
                        break;
                    }
                }
            }
            return match;
        }

        bool filterEndsWith(object o) {
            var word = (Word)o;
            if (string.IsNullOrWhiteSpace(query)) return word.IsOk == Verified;
            return word.Corpus.EndsWith(query) && word.IsOk == Verified;
        }

        bool filterPatternEquals(object o) {
            var word = ((Word)o);
            if (string.IsNullOrWhiteSpace(query))
                return word.IsOk == Verified;

            bool match = word.Corpus.Length == query.Length && word.IsOk == Verified;
            if (match) {
                for (int i = 0; i < query.Length; i++) {
                    if (query[i].Equals('ـ')) continue; // Shift + B
                    if (!query[i].Equals(word.Corpus[i])) {
                        match = false;
                        break;
                    }
                }
            }
            return match;
        }

        void getCurrent() {
            if (SelectedWord is null) return;
            getMorphs();
            SelectedMorph = Morphs.First();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMorph)));
        }

        void resetCurrent() {
            isOnEdit = false;
            CurrentData.Clear();
            EditedData.Clear();
            if (SelectedMorph is null) return;
            var o = App.concatData.First(x => x.Content.Equals(SelectedWord.Corpus) && x.POS.Equals(SelectedMorph.Tags));
            var first = App.corpusData.Where(x => x.Surah == o.Surah && x.Ayah == o.Ayah && x.Word == o.Word);
            foreach (var d in first) CurrentData.Add(d);
        }

        void getMorphs() {
            Morphs.Clear();
            var data = App.concatData
                .Where(x => x.Content.Equals(SelectedWord.Corpus))
                .GroupBy(x => x.POS)
                .Select(x => new {
                    Word = x.First().Word,
                    POS = x.Key,
                    Count = x.Count()
                });
            foreach (var d in data) {
                Morphs.Add(new Morph() {
                    Word = SelectedWord.Corpus,
                    Tags = d.POS,
                    Times = d.Count
                });
            }
            #region with sql
            //using var connection = new SqliteConnection("data source = quran.db");
            //connection.Open();
            //using var command = connection.CreateCommand();
            //command.CommandText = @"WITH T(Word, Description) AS(
            //                        	SELECT group_concat(Content, ''), group_concat(POS) FROM CorpusSegment
            //                        	GROUP BY Surah, Ayah, Word
            //                        )
            //                        SELECT Word, Description, count(*) Number FROM T
            //                        WHERE Word = @Word
            //                        GROUP BY Word, Description";
            //command.Parameters.AddWithValue("@Word", SelectedDiff.Corpus);
            //var reader = command.ExecuteReader();
            //while (reader.Read()) {
            //    Morphs.Add(new Morph() {
            //        Word = reader.GetString(0),
            //        Tags = reader.GetString(1),
            //        Times = reader.GetInt32(2)
            //    });
            //}
            //connection.Close();
            #endregion
        }

        void editSegments(object sender, RoutedEventArgs e) {
            if (isOnEdit) {
                MessageBox.Show("Update this one OR Select another Word", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            foreach (var segment in CurrentData) {
                EditedData.Add(new CorpusData() {
                    Segment = segment.Segment,
                    POS = segment.POS,
                    Content = segment.Content,
                    Detail = segment.Detail,
                    Root = segment.Root
                });
            }
            isOnEdit = true;
        }

        void updateSegments(object sender, RoutedEventArgs e) {
            if (EditedData.Count == 0) {
                MessageBox.Show("Edit a word", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var newWord = "";
            foreach (var segment in EditedData) {
                newWord += segment.Content;
            }
            if (!newWord.Equals(SelectedWord.Minimal)) {
                var confirmation = MessageBox.Show(
                    $"{newWord} doesn't match with minimal \n\nWant to continue?",
                    "Question",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (confirmation == MessageBoxResult.No) return;
            }

            var o = App.concatData.Where(x => x.Content.Equals(SelectedMorph.Word) && x.POS.Equals(SelectedMorph.Tags)).ToList();
            var o1 = App.occurenceList.Where(x => o.Any(y => y.Surah == x.Surah && y.Ayah == x.Ayah && y.Word == x.WordNo)).ToList();
            Debug.WriteLine(o.Count() + " | " + o1.Count());
            var words = App.corpusData
                .Where(x => o.Any(y => y.Surah == x.Surah && y.Ayah == x.Ayah && y.Word == x.Word))
                .GroupBy(x => new { x.Surah, x.Ayah, x.Word })
                .ToList();

            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;

            foreach (var word in words) {
                App.corpusData.RemoveAll(x => x.Surah == word.Key.Surah && x.Ayah == word.Key.Ayah && x.Word == word.Key.Word);
                command.CommandText = @$"DELETE FROM CorpusSegment WHERE Surah = {word.Key.Surah}
                                         AND Ayah = {word.Key.Ayah} AND Word = {word.Key.Word}";
                command.ExecuteNonQuery();
                foreach (var segment in EditedData) {
                    App.corpusData.Add(new CorpusData() {
                        Surah = word.Key.Surah,
                        Ayah = word.Key.Ayah,
                        Word = word.Key.Word,
                        Segment = segment.Segment,
                        Content = segment.Content,
                        POS = segment.POS,
                        Detail = segment.Detail,
                        Root = segment.Root,
                        IsOk = true
                    });
                    command.Parameters.Clear();
                    object root = string.IsNullOrWhiteSpace(segment.Root) ? DBNull.Value : segment.Root;
                    object detail = string.IsNullOrWhiteSpace(segment.Detail) ? DBNull.Value : segment.Detail;
                    command.CommandText = $@"INSERT INTO CorpusSegment VALUES ({word.Key.Surah}, {word.Key.Ayah},
                                            {word.Key.Word}, {segment.Segment}, '{segment.Content}', '{segment.POS}',
                                            @Detail, @Root, 1)";
                    command.Parameters.AddWithValue("@Detail", detail);
                    command.Parameters.AddWithValue("@Root", root);
                    command.ExecuteNonQuery();
                }
            }
            var posStr = string.Join(',', EditedData.Select(x => x.POS));
            for (int i = 0; i < o.Count; i++) {
                command.CommandText = @$"UPDATE Words SET Corpus = '{newWord}', IsOk = 1 WHERE Surah = {o1[i].Surah}
                                        AND Ayah = {o1[i].Ayah} AND WordNo = {o1[i].WordNo}";
                command.ExecuteNonQuery();
                o1[i].Corpus = newWord;
                o[i].Content = newWord;
                o[i].POS = posStr;
            }

            transaction.Commit();
            connection.Close();

            SelectedWord.Corpus = newWord;
            SelectedWord.IsOk = true;
            SelectedWord.OnPropertyChanged(nameof(Word.Corpus));
            SelectedWord.OnPropertyChanged(nameof(Word.IsOk));
            var refs = words.Select(x => new Tuple<int, int>(x.Key.Surah, x.Key.Ayah)).Distinct().ToList();
            WordChanged?.Invoke(refs);

            getMorphs();
            SelectedMorph = Morphs.First();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedMorph)));

            App.segments = App.corpusData
                .Where(x => !x.IsOk)
                .Select(x => new { x.Content, x.Root, x.POS, x.Detail })
                .GroupBy(x => new { x.Content, x.Root, x.POS, x.Detail }, (g, l) => new Segment {
                    Content = g.Content,
                    Root = g.Root,
                    POS = g.POS,
                    Detail = g.Detail,
                    Occurence = l.Count()
                }).ToList();

            SegmentsChanged?.Invoke();
        }

        void addSegmentAbove(object sender, RoutedEventArgs e) {
            var index = Convert.ToInt32(((Button)sender).Tag);
            EditedData.Insert(index - 1, new CorpusData());
            for (int i = 0; i < EditedData.Count; i++) {
                EditedData[i].Segment = i + 1;
                EditedData[i].onChanged(nameof(CorpusData.Segment));
            }
        }

        void addSegmentBelow(object sender, RoutedEventArgs e) {
            var index = Convert.ToInt32(((Button)sender).Tag);
            EditedData.Insert(index, new CorpusData());
            for (int i = 0; i < EditedData.Count; i++) {
                EditedData[i].Segment = i + 1;
                EditedData[i].onChanged(nameof(CorpusData.Segment));
            }
        }

        void removeSegment(object sender, RoutedEventArgs e) {
            var index = Convert.ToInt32(((Button)sender).Tag);
            if (EditedData.Count == 1) {
                MessageBox.Show("No option to remove the only one!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            EditedData.RemoveAt(index - 1);
            for (int i = 0; i < EditedData.Count; i++) {
                EditedData[i].Segment = i + 1;
                EditedData[i].onChanged(nameof(CorpusData.Segment));
            }
        }

        void onFilterChanged(object sender, SelectionChangedEventArgs e) {
            if (Words is null) return;
            var content = ((ComboBoxItem)filterCombo.SelectedItem).Content;
            switch (content) {
                case "All": Words.Filter = filterGetAll; break;
                case "Spelling Difference": Words.Filter = filterDifference; break;
                case "Pattern equals": Words.Filter = filterPatternEquals; break;
                case "Pattern starts with": Words.Filter = filterPatternStartsWith; break;
                case "Ends with": Words.Filter = filterEndsWith; break;
            }
        }

        void applyFilter(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            query = ((TextBox)sender).Text.Trim();
            Words.Refresh();
        }

        void markAsVerified(object sender, RoutedEventArgs e) {
            var o = wordList.Items.Cast<Word>().Where(x => x.IsOk).ToList();
            var occurences = App.occurenceList.Where(x => o.Any(y => y.Corpus.Equals(x.Corpus) && y.Minimal.Equals(x.Minimal))).ToList();
            if (occurences.Count == 0) return;

            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;

            foreach (var item in occurences) {
                command.CommandText = @$"UPDATE Words SET IsOk = 1 WHERE Surah = {item.Surah} AND Ayah = {item.Ayah} AND WordNo = {item.WordNo};
                                         UPDATE CorpusSegment SET IsOk = 1 WHERE Surah = {item.Surah} AND Ayah = {item.Ayah} AND Word = {item.WordNo}";
                command.ExecuteNonQuery();
            }

            transaction.Commit();
            connection.Close();
            var words = App.words.Where(x => o.Any(y => y.Corpus.Equals(x.Corpus) && y.Minimal.Equals(x.Minimal))).ToList();
            foreach (var word in words) {
                word.IsOk = true;
                word.OnPropertyChanged(nameof(Word.IsOk));
            }
            var segments = App.corpusData.Where(x => occurences.Any(y => y.Surah == x.Surah && y.Ayah == x.Ayah && y.WordNo == x.Word)).ToList();
            foreach (var segment in segments) {
                segment.IsOk = true;
            }

            App.segments = App.corpusData
                .Where(x => !x.IsOk)
                .Select(x => new { x.Content, x.Root, x.POS, x.Detail })
                .GroupBy(x => new { x.Content, x.Root, x.POS, x.Detail }, (g, l) => new Segment {
                    Content = g.Content,
                    Root = g.Root,
                    POS = g.POS,
                    Detail = g.Detail,
                    Occurence = l.Count()
                }).ToList();


            SegmentsChanged?.Invoke();
        }
    }
}
