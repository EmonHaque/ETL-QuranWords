﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuranWords
{
    public class Word
    {
        public int Occurence { get; set; }
        public string Minimal { get; set; }
        public string Original { get; set; }
        public string Edited { get; set; }
        public bool IsChecked { get; set; }
        public string Root { get; set; }
    }

    public class WordMeaning
    {
        public int Occurence { get; set; }
        public string Word { get; set; }
        public string Meaning { get; set; }
    }
}
