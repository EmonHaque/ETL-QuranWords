﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace QuranWords
{
    public class ColoredBlock : TextBlock
    {
        public ColoredBlock() {
            FontSize = 50;
            FontFamily = new FontFamily("Scheherazade");
            FlowDirection = FlowDirection.RightToLeft;
        }

        public IEnumerable<SegmentedWord> Words {
            get { return (IEnumerable<SegmentedWord>)GetValue(WordsProperty); }
            set { SetValue(WordsProperty, value); }
        }

        public static readonly DependencyProperty WordsProperty =
            DependencyProperty.Register("Words", typeof(IEnumerable<SegmentedWord>), typeof(ColoredBlock), new PropertyMetadata(null, onWordChanged));

        static void onWordChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            var o = (ColoredBlock)d;
            var grouped = o.Words.GroupBy(x => x.WordNo, (w, s) => new {
                Word = w,
                Segments = s
            });

            foreach (var word in grouped) {
                foreach (var segment in word.Segments) {
                    o.Inlines.Add(new Run() {
                        Text = segment.Minimal,
                        Foreground = new SolidColorBrush(App.POSs.First(x => x.Id == segment.POS).Color)
                    });
                }
                o.Inlines.Add(new Run(" "));
            }
            var no = o.Words.First().Ayah.ToString();
            for (int i = 0; i <= 9; i++) {
                no = no.Replace(i.ToString(), App.arabic.NumberFormat.NativeDigits[i]);
            }
            o.Inlines.Add(new Run("("));
            o.Inlines.Add(new Run(no));
            o.Inlines.Add(new Run(")"));
        }
    }
}
