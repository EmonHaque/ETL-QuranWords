﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords2
{
    public partial class EditRootView : UserControl, INotifyPropertyChanged
    {
        string query;
        public string Query {
            get { return query; }
            set { query = value; Roots.Refresh(); }
        }
        bool isVerified;
        public bool IsVerified {
            get { return isVerified; }
            set { isVerified = value; Roots.Refresh(); infoBlock.Text = ""; }
        }
        bool hasMeaning;
        public bool HasMeaning {
            get { return hasMeaning; }
            set { hasMeaning = value; Roots.Refresh(); infoBlock.Text = ""; }
        }

        Root selectedRoot;
        public Root SelectedRoot {
            get { return selectedRoot; }
            set { 
                selectedRoot = value; 
                infoBlock.Text = "";
                getForms();
            }
        }
        public ICollectionView Roots { get; set; }
        public List<string> Forms { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;

        public EditRootView() {
            InitializeComponent();
            Roots = new CollectionViewSource() { 
                Source = App.roots,
                IsLiveFilteringRequested = true,
                LiveFilteringProperties = { nameof(Root.IsOk) }
            }.View;
            Roots.Filter = filterRoots;
            DataContext = this;
        }

        bool filterRoots(object o) {
            var root = (Root)o;
            if (string.IsNullOrWhiteSpace(Query)) return root.IsOk == IsVerified && HasMeaning == !string.IsNullOrWhiteSpace(root.Meaning);
            return root.CorpusRoot.StartsWith(Query) && root.IsOk == IsVerified && HasMeaning == !string.IsNullOrWhiteSpace(root.Meaning);
        }

        void getForms() {
            if (SelectedRoot is null) return;
            Forms = App.corpusData
                .Where(x => !string.IsNullOrEmpty(x.Root) && x.Root.Equals(SelectedRoot.CorpusRoot))
                .Select(x => x.Content)
                .Distinct()
                .OrderBy(x => x)
                .ToList();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Forms)));
        }

        void update(object sender, RoutedEventArgs e) {
            if(rootList.SelectedItem is null) {
                MessageBox.Show("Select and Edit a root", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var root = (Root)rootList.SelectedItem;
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = @$"UPDATE Roots SET PRLKey = @Key, Meaning = @Meaning, Reference = @Reference, IsOk = 1 WHERE Id = {root.Id}";
            command.Parameters.AddWithValue("@Key", root.PRLKey);
            command.Parameters.AddWithValue("@Meaning", root.Meaning);
            command.Parameters.AddWithValue("@Reference", root.Reference);
            command.ExecuteNonQuery();
            connection.Close();

            infoBlock.Text = "Updated";

            root.IsOk = true;
        }
    }
}
