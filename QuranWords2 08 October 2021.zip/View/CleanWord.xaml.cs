﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords2
{
    public partial class CleanWord : UserControl
    {
        public ObservableCollection<CorpusData> Words { get; set; }
        public CleanWord() {
            InitializeComponent();
            Words = new ObservableCollection<CorpusData>(App.corpusData
                .Where(x => !string.IsNullOrWhiteSpace(x.Root) && !x.Root.EndsWith("ن") && string.IsNullOrWhiteSpace(x.CleanWord))
                .GroupBy(x => new { x.Root, x.Content })
                .Select(x => new CorpusData() {
                    Root = x.Key.Root,
                    Content = x.Key.Content
                })
                .OrderBy(x => x.Root)
                .ThenBy(x => x.Content));
            DataContext = this;
        }

        void clean(object sender, RoutedEventArgs e) {
            var selected = list.SelectedItems.Cast<CorpusData>().ToList();
            var occurence = App.corpusData.Where(x => selected.Any(y => y.Content.Equals(x.Content) && y.Root.Equals(x.Root))).ToList();
            foreach (var s in selected) {
                if (s.Content.EndsWith("ونَ") ||
                    s.Content.EndsWith("ينَ")) {
                    s.CleanWord = s.Content.Substring(0, s.Content.Length - 3);
                }
                else if (s.Content.EndsWith('ُ' /*damma*/) ||
                    s.Content.EndsWith('َ' /*fatha*/) ||
                    s.Content.EndsWith('ِ' /*kesra*/) ||
                    s.Content.EndsWith('ٌ' /*dammatan*/) ||
                    s.Content.EndsWith('ٍ' /*kesratan*/)) {
                    s.CleanWord = s.Content.Substring(0, s.Content.Length - 1);
                }
                else if (s.Content.EndsWith("ًا" /*fathatan alif*/)) {
                    s.CleanWord = s.Content.Substring(0, s.Content.Length - 2);
                }
                else s.CleanWord = s.Content;

                var match = occurence.Where(x => x.Content.Equals(s.Content) && x.Root.Equals(s.Root));
                foreach (var item in match) {
                    item.CleanWord = s.CleanWord;
                }
            }

            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;

            foreach (var o in occurence) {
                command.CommandText = @$"UPDATE CorpusSegment SET Clean = '{o.CleanWord}' WHERE Surah = {o.Surah}
                                        AND Ayah = {o.Ayah} AND Word = {o.Word} AND Segment = {o.Segment}";
                command.ExecuteNonQuery();
            }
            transaction.Commit();
            connection.Close();

            for (int i = 0; i < selected.Count; i++) {
                Words.Remove(selected[i]);
            }
        }
    }
}
