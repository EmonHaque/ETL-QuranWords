﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords2
{
    public partial class SurahView : UserControl, INotifyPropertyChanged
    {
        SolidColorBrush DET_Brush, V_Brush, N_PN_ADJ_Brush, DEM_REL_Brush, P_Brush, CONJ_Brush, INTG_Brush, NEG_Brush,
            PRON1_Brush, PRON2_Brush, PRON3_Brush, OTHER1_Brush, OTHER2_Brush, OTHER3_Brush;

        string[] definedBrush;

        Surah selectedSurah;
        public Surah SelectedSurah {
            get { return selectedSurah; }
            set {
                selectedSurah = value;
                makeDocument();
                SelectedWord = null;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedWord)));
            }
        }
        public string Translation { get; set; }
        public List<Surah> Surahs { get; set; }
        public List<CorpusData> SelectedWord { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;
        public static event Action<List<CorpusData>> WordEdited;

        public SurahView() {
            InitializeComponent();
            initializeBrushes();
            getSurah();
            SelectedSurah = Surahs.First();
            DataContext = this;
            WordView.WordChanged += onWordChanged;
        }

        void onWordChanged(List<Tuple<int, int>> wordRefs) {
            foreach (var @ref in wordRefs) {
                if (SelectedSurah.Id != @ref.Item1) continue;
                var words = App.corpusData
                    .Where(x => x.Surah == @ref.Item1 && x.Ayah == @ref.Item2)
                    .GroupBy(x => x.Word, (word, segments) => new {
                        Word = word,
                        Segments = segments
                    })
                    .OrderBy(x => x.Word).ToList();
                var para = doc.Blocks.OfType<Paragraph>().First(x => Convert.ToInt32(x.Tag) == @ref.Item2);
                var no = para.Inlines.First();
                para.Inlines.Clear();

                para.Inlines.Add(no);
                int pronCount, otherCount;
                string lastPos = "";

                foreach (var word in words) {
                    lastPos = "";
                    pronCount = 1;
                    otherCount = 1;
                    foreach (var segment in word.Segments) {
                        var text = new Run(segment.Content);
                        switch (segment.POS) {
                            case "DET": text.Foreground = DET_Brush; break;
                            case "V": text.Foreground = V_Brush; break;
                            case "N":
                            case "PN":
                            case "ADJ": text.Foreground = N_PN_ADJ_Brush; break;
                            case "REL":
                            case "DEM": text.Foreground = DEM_REL_Brush; break;
                            case "P": text.Foreground = P_Brush; break;
                            case "CONJ": text.Foreground = CONJ_Brush; break;
                            case "INTG": text.Foreground = INTG_Brush; break;
                            case "NEG": text.Foreground = NEG_Brush; break;
                            case "PRON":
                                if (lastPos.Equals("PRON")) pronCount++;
                                if (pronCount == 1) text.Foreground = PRON1_Brush;
                                else if (pronCount == 2) text.Foreground = PRON2_Brush;
                                else text.Foreground = PRON3_Brush;
                                break;
                            default:
                                if (!definedBrush.Contains(lastPos)) otherCount++;
                                if (otherCount == 1) text.Foreground = OTHER1_Brush;
                                else if (otherCount == 2) text.Foreground = OTHER2_Brush;
                                else text.Foreground = OTHER3_Brush;
                                break;
                        }
                        lastPos = segment.POS;

                        para.Inlines.Add(text);
                    }
                    para.Inlines.Add(" ");
                }
            }
        }

        void initializeBrushes() {
            DET_Brush = Brushes.LightGray;
            V_Brush = Brushes.CornflowerBlue;
            N_PN_ADJ_Brush = Brushes.Black;
            DEM_REL_Brush = Brushes.Green;
            P_Brush = Brushes.SkyBlue;
            CONJ_Brush = Brushes.Coral;
            INTG_Brush = Brushes.Red;
            NEG_Brush = Brushes.Crimson;

            PRON1_Brush = Brushes.Green;
            PRON2_Brush = Brushes.Navy;
            PRON3_Brush = Brushes.CadetBlue;
            OTHER1_Brush = Brushes.Gray;
            OTHER2_Brush = Brushes.Navy;
            OTHER3_Brush = Brushes.CadetBlue;
            definedBrush = new string[] { "", "DET", "V", "N", "PN", "ADJ", "REL", "DEM", "P", "PRON", "CONJ", "INTG", "NEG" };
        }

        void updateWord(object sender, RoutedEventArgs e) {
            if (SelectedWord is null) {
                MessageBox.Show("Click on a word and edit first", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var refs = SelectedWord.First();
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;

            command.CommandText = @$"DELETE FROM CorpusSegment WHERE Surah = {refs.Surah} AND Ayah = {refs.Ayah} AND Word = {refs.Word}";
            command.ExecuteNonQuery();
            foreach (var segment in SelectedWord) {
                command.Parameters.Clear();
                object root = string.IsNullOrWhiteSpace(segment.Root) ? DBNull.Value : segment.Root;
                object detail = string.IsNullOrWhiteSpace(segment.Detail) ? DBNull.Value : segment.Detail;
                command.CommandText = $@"INSERT INTO CorpusSegment VALUES ({segment.Surah}, {segment.Ayah},
                                            {segment.Word}, {segment.Segment}, '{segment.Content}', '{segment.POS}',
                                            @Detail, @Root)";
                command.Parameters.AddWithValue("@Detail", detail);
                command.Parameters.AddWithValue("@Root", root);
                command.ExecuteNonQuery();
            }

            transaction.Commit();
            connection.Close();

            onWordChanged(new List<Tuple<int, int>>() { new Tuple<int, int>(refs.Surah, refs.Ayah) });
            WordEdited?.Invoke(SelectedWord);
        }

        void makeDocument() {
            var surah = App.corpusData
                .Where(x => x.Surah == SelectedSurah.Id)
                .GroupBy(x => x.Ayah, (ayah, words) => new {
                    Ayah = ayah,
                    Words = words.GroupBy(x => x.Word, (word, segments) => new {
                        Word = word,
                        Segments = segments
                    }).OrderBy(x => x.Word)
                });
            doc.Blocks.Clear();

            int ayahNo, pronCount, otherCount;
            ayahNo = 1;
            string lastPos = "";
            foreach (var ayah in surah) {
                var para = new Paragraph() { Tag = ayahNo++ };
                para.Inlines.Add(ayah.Words.First().Segments.First().Ayah + ") ");
                foreach (var word in ayah.Words) {
                    lastPos = "";
                    pronCount = 1;
                    otherCount = 1;
                    foreach (var segment in word.Segments) {
                        var current = new Run(segment.Content);
                        switch (segment.POS) {
                            case "DET": current.Foreground = DET_Brush; break;
                            case "V": current.Foreground = V_Brush; break;
                            case "N":
                            case "PN":
                            case "ADJ": current.Foreground = N_PN_ADJ_Brush; break;
                            case "REL":
                            case "DEM": current.Foreground = DEM_REL_Brush; break;
                            case "P": current.Foreground = P_Brush; break;
                            case "CONJ": current.Foreground = CONJ_Brush; break;
                            case "INTG": current.Foreground = INTG_Brush; break;
                            case "NEG": current.Foreground = NEG_Brush; break;
                            case "PRON":
                                if (lastPos.Equals("PRON")) pronCount++;
                                if (pronCount == 1) current.Foreground = PRON1_Brush;
                                else if (pronCount == 2) current.Foreground = PRON2_Brush;
                                else current.Foreground = PRON3_Brush;
                                break;
                            default:
                                if (!definedBrush.Contains(lastPos)) otherCount++;
                                if (otherCount == 1) current.Foreground = OTHER1_Brush;
                                else if (otherCount == 2) current.Foreground = OTHER2_Brush;
                                else current.Foreground = OTHER3_Brush;
                                break;
                        }
                        lastPos = segment.POS;
      
                        if (current.Text.StartsWith("ن") ||
                            current.Text.StartsWith("نَ")) {

                            var last = (Run)para.Inlines.Last();
                            if (last.Text.EndsWith("ن")) {
                                if (segment.POS.Equals("NOON")) {
                                    last.Text += 'ّ' /*shadda*/;
                                    current.Text = "";
                                }
                                else if (current.Text.Equals("نَ")) {
                                    last.Text = last.Text.Remove(last.Text.Length - 1, 1);
                                    current.Text = current.Text.Insert(1, "ّ" /*shadda*/);
                                }
                                else if (current.Text.Equals("نا")) {
                                    last.Text += 'ّ' /*shadda*/;
                                    current.Text = "ا";
                                }
                            }
                        }
                        else if (current.Text.Equals("ما")) {
                            var last = (Run)para.Inlines.Last();
                            if (last.Text.EndsWith("ن") || last.Text.EndsWith("م")) {
                                last.Text = last.Text.Remove(last.Text.Length - 1, 1);
                                current.Text = "مّا";
                            }
                        }
                        else if (current.Text.Equals("مَن")) {
                            var last = (Run)para.Inlines.Last();
                            if (last.Text.EndsWith("ن") || last.Text.EndsWith("م")) {
                                last.Text = last.Text.Remove(last.Text.Length - 1, 1);
                                current.Text = "مَّن";
                            }
                        }
                        else if (current.Text.Equals("مَ")) {
                            var last = (Run)para.Inlines.Last();
                            if (last.Text.EndsWith("ن") || last.Text.EndsWith("م")) {
                                last.Text = last.Text.Remove(last.Text.Length - 1, 1);
                                current.Text = "مَّ";
                            }
                        }
                        else if (current.Text.StartsWith("تُ") ||
                            current.Text.StartsWith("تَ")) {
                            var last = (Run)para.Inlines.Last();
                            if (last.Text.EndsWith('ت')) {
                                last.Text = last.Text.Remove(last.Text.Length - 1, 1);
                                current.Text = current.Text.Replace("ت", "تّ");
                            }
                        }
                        else if (current.Text.StartsWith("ا")) {
                            var last = (Run)para.Inlines.Last();
                            if (current.Text.Equals("ال")) {
                                if (last.Text.Equals("لَ") || last.Text.Equals("لِ")) {
                                    current.Text = current.Text.Remove(0, 1);
                                }
                                else if (last.Text.EndsWith("أَ")) {
                                    last.Text = "آ";
                                    current.Text = current.Text.Remove(0, 1);
                                }
                            }
                        }
                        if (!string.IsNullOrEmpty(current.Text)) para.Inlines.Add(current);
                    }
                    para.Inlines.Add(" ");
                }
                doc.Blocks.Add(para);
            }
        }

        void getSurah() {
            Surahs = new List<Surah>();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT No, Arabic, English, Bangla FROM Surah";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    Surahs.Add(new Surah() {
                        Id = reader.GetInt32(0),
                        Arabic = reader.GetString(1),
                        English = reader.GetString(2),
                        Bangla = reader.GetString(3),
                    });
                }
                connection.Close();
            }
        }

        void onSelectionChanged(object sender, RoutedEventArgs e) {
            var para = rtb.Selection.Start.Paragraph;
            var range = new TextRange(para.ContentStart, rtb.Selection.Start);
            var wordNo = range.Text.Split(" ").Length - 1;
            if (wordNo != 0) {
                int ayah = Convert.ToInt32(rtb.Selection.Start.Paragraph.Tag);
                SelectedWord = App.corpusData.Where(x => x.Surah == SelectedSurah.Id && x.Ayah == ayah && x.Word == wordNo).ToList();
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedWord)));
            }
        }

        void onRightClick(object sender, MouseButtonEventArgs e) {
            var caret = rtb.GetPositionFromPoint(e.GetPosition(rtb), true);
            var ayah = Convert.ToInt32(caret.Paragraph.Tag);
            Translation = App.translation.First(x => x.Surah == SelectedSurah.Id && x.Ayah == ayah).Bangla;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Translation)));
            translationBox.IsOpen = true;
        }

    }
}
