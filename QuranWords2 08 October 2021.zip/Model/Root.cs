﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuranWords2
{
    public class Root : INotifyPropertyChanged
    {
        public int Id { get; set; }
        public string CorpusRoot { get; set; }
        public string PRLKey { get; set; }
        public string Meaning { get; set; }
        public string Reference { get; set; }
        public bool IsCorpusRoot { get; set; }
        bool isOk;
        public bool IsOk {
            get { return isOk; }
            set { isOk = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsOk))); }
        }


        public event PropertyChangedEventHandler PropertyChanged;
    }
}
