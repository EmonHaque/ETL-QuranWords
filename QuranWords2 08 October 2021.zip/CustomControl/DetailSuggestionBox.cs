﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace QuranWords2.CustomControl
{
    public class DetailSuggestionBox : SuggestionBoxBase
    {
        protected override ICollectionView source => App.Details;
        protected override void setQueryAndRefresh() {
            if (Text.Contains('|')) 
                App.detailsQuery = Text.Split('|').Last().ToLower();
            
            else App.detailsQuery = Text.ToLower();
            App.Details.Refresh();
        }
        protected override void setText() {
            var selectedDetail = ((Details)listSuggestion.SelectedItem).Tag;
            if (Text.Contains('|')) {
                var subs = Text.Substring(0, Text.LastIndexOf('|') + 1);
                Text = subs + selectedDetail;
            }
            else Text = selectedDetail;
        }
    }
}
