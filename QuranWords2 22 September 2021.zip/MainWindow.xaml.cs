﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords2
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public UserControl SelectedContent { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;
        public MainWindow() {
            InitializeComponent();
            SelectedContent = new SurahView();
            DataContext = this;
        }

        void go2Classify(object sender, RoutedEventArgs e) {
            SelectedContent = new Classify();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedContent)));
        }

        void go2Surah(object sender, RoutedEventArgs e) {
            SelectedContent = new SurahView();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedContent)));
        }
    }
}
