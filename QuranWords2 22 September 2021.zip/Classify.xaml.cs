﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords2
{
    public partial class Classify : UserControl
    {
        bool isOnEdit;
        TextBox boxOnEdit;
        string posQuery, detailsQuery;
        string wordQuery;
        public string WordQuery {
            get { return wordQuery; }
            set { wordQuery = value.Trim(); Words.Refresh(); }
        }
        DiffData selectedDiff;
        public DiffData SelectedDiff {
            get { return selectedDiff; }
            set { selectedDiff = value; getCurrent(); }
        }

        public ICollectionView Words { get; set; }
        public ICollectionView POS { get; set; }
        public ICollectionView Details { get; set; }
        public ObservableCollection<CorpusData> CurrentData { get; set; }
        public ObservableCollection<CorpusData> EditedData { get; set; }

        public Classify() {
            InitializeComponent();
            Words = new CollectionViewSource() { Source = App.okDiffs }.View;
            Words.Filter = filterGetAll;
            POS = new CollectionViewSource() { Source = App.poss }.View;
            Details = new CollectionViewSource() { Source = App.details }.View;
            POS.Filter = filterPOS;
            Details.Filter = filterDetails;
            CurrentData = new();
            EditedData = new();
            DataContext = this;
        }

        bool filterDifference(object o) {
            if (string.IsNullOrWhiteSpace(wordQuery))
                return !((DiffData)o).IsSpellingOk;
            var word = (DiffData)o;
            return word.Corpus.Contains(wordQuery) && word.IsSpellingOk;
        }
        bool filterGetAll(object o) {
            if (string.IsNullOrWhiteSpace(wordQuery)) return true;
            return ((DiffData)o).Corpus.Contains(wordQuery);
        }

        bool filterDetails(object o) {
            if (string.IsNullOrWhiteSpace(detailsQuery)) return true;
            var pos = (Details)o;
            return pos.Description.ToLower().Contains(detailsQuery);
        }

        bool filterPOS(object o) {
            if (string.IsNullOrWhiteSpace(posQuery)) return true;
            var pos = (PartsOfSpeech)o;
            return pos.Description.ToLower().Contains(posQuery);
        }

        void getCurrent() {
            CurrentData.Clear();
            EditedData.Clear();
            if (selectedDiff is null) return;
            var o = App.occurenceList.First(x => x.Minimal.Equals(SelectedDiff.Minimal) && x.Corpus.Equals(SelectedDiff.Corpus));
            var first = App.corpusData.Where(x => x.Surah == o.Surah && x.Ayah == o.Ayah && x.Word == o.WordNo);
            foreach (var d in first) CurrentData.Add(d);
        }

        void editSegments(object sender, RoutedEventArgs e) {
            if (isOnEdit) {
                MessageBox.Show("Update this one OR Select another Word", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            foreach (var segment in CurrentData) {
                EditedData.Add(new CorpusData() {
                    Surah = segment.Surah,
                    Ayah = segment.Ayah,
                    Word = segment.Word,
                    Segment = segment.Segment,
                    POS = segment.POS,
                    Content = segment.Content,
                    Detail = segment.Detail,
                    Root = segment.Root
                });
            }
            isOnEdit = true;
        }

        void updateSegments(object sender, RoutedEventArgs e) {
            if (EditedData.Count == 0) {
                MessageBox.Show("Edit a word", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var newWord = "";
            foreach (var segment in EditedData) {
                newWord += segment.Content;
            }
            if (!newWord.Equals(SelectedDiff.Minimal)) {
                var confirmation = MessageBox.Show(
                    $"{newWord} doesn't match with minimal \n\nWant to continue?",
                    "Question",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (confirmation == MessageBoxResult.No) return;
            }

            var o = App.occurenceList.Where(x => x.Minimal.Equals(SelectedDiff.Minimal) && x.Corpus.Equals(SelectedDiff.Corpus)).ToList();
            var words = App.corpusData
                .Where(x => o.Any(y => y.Surah == x.Surah && y.Ayah == x.Ayah && y.WordNo == x.Word))
                .GroupBy(x => new { x.Surah, x.Ayah, x.Word })
                .ToList();

            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;

            foreach (var word in words) {
                command.CommandText = @$"DELETE FROM CorpusSegment WHERE Surah = {word.Key.Surah}
                                         AND Ayah = {word.Key.Ayah} AND Word = {word.Key.Word}";
                command.ExecuteNonQuery();
                foreach (var segment in EditedData) {
                    command.Parameters.Clear();
                    object root = string.IsNullOrWhiteSpace(segment.Root) ? DBNull.Value : segment.Root;
                    object detail = string.IsNullOrWhiteSpace(segment.Detail) ? DBNull.Value : segment.Detail;
                    command.CommandText = $@"INSERT INTO CorpusSegment VALUES ({word.Key.Surah}, {word.Key.Ayah},
                                            {word.Key.Word}, {segment.Segment}, '{segment.Content}', '{segment.POS}',
                                            @Detail, @Root)";
                    command.Parameters.AddWithValue("@Detail", detail);
                    command.Parameters.AddWithValue("@Root", root);
                    command.ExecuteNonQuery();
                }
            }
            foreach (var occurence in o) {
                command.CommandText = @$"UPDATE Words SET Corpus = '{newWord}', IsSpellingOk = 1, IsSegmentationOk = 1 WHERE Surah = {occurence.Surah}
                                        AND Ayah = {occurence.Ayah} AND WordNo = {occurence.WordNo}";
                command.ExecuteNonQuery();
            }
            transaction.Commit();
            connection.Close();
            EditedData.Clear();
            isOnEdit = false;
        }

        void addSegmentAbove(object sender, RoutedEventArgs e) {
            var index = Convert.ToInt32(((Button)sender).Tag);
            EditedData.Insert(index - 1, new CorpusData());
            for (int i = 0; i < EditedData.Count; i++) {
                EditedData[i].Segment = i + 1;
                EditedData[i].onChanged(nameof(CorpusData.Segment));
            }
        }

        void addSegmentBelow(object sender, RoutedEventArgs e) {
            var index = Convert.ToInt32(((Button)sender).Tag);
            EditedData.Insert(index, new CorpusData());
            for (int i = 0; i < EditedData.Count; i++) {
                EditedData[i].Segment = i + 1;
                EditedData[i].onChanged(nameof(CorpusData.Segment));
            }
        }

        void removeSegment(object sender, RoutedEventArgs e) {
            var index = Convert.ToInt32(((Button)sender).Tag);
            if (EditedData.Count == 1) {
                MessageBox.Show("No option to remove the only one!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            EditedData.RemoveAt(index - 1);
            for (int i = 0; i < EditedData.Count; i++) {
                EditedData[i].Segment = i + 1;
                EditedData[i].onChanged(nameof(CorpusData.Segment));
            }
        }

        void onPosTextChanged(object sender, TextChangedEventArgs e) {
            boxOnEdit = (TextBox)sender;
            posQuery = boxOnEdit.Text.ToLower();
            POS.Refresh();
            posSuggestionBox.PlacementTarget = boxOnEdit;
            posSuggestionBox.PlacementRectangle = boxOnEdit.GetRectFromCharacterIndex(boxOnEdit.CaretIndex);
            posSuggestionBox.IsOpen = true;
        }

        void focusPOSSuggestion(object sender, KeyEventArgs e) {
            if (e.Key != Key.Down) return;
            if (posSuggestionBox.IsOpen) {
                posSuggestionList.SelectedIndex = 0;
                Keyboard.Focus((ListBoxItem)posSuggestionList.ItemContainerGenerator.ContainerFromItem(posSuggestionList.SelectedItem));
            }
        }

        void setPartsOfSpeech(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            boxOnEdit.Text = ((PartsOfSpeech)posSuggestionList.SelectedItem).Tag;
            boxOnEdit.CaretIndex = boxOnEdit.Text.Length;
            posSuggestionBox.IsOpen = false;
            Keyboard.Focus(boxOnEdit);
        }

        void focusDetailSuggestion(object sender, KeyEventArgs e) {
            if (e.Key != Key.Down) return;
            if (detailSuggestionBox.IsOpen) {
                detailSuggestionList.SelectedIndex = 0;
                Keyboard.Focus((ListBoxItem)detailSuggestionList.ItemContainerGenerator.ContainerFromItem(detailSuggestionList.SelectedItem));
            }
        }

        void onDetailTextChanged(object sender, TextChangedEventArgs e) {
            boxOnEdit = (TextBox)sender;
            if (boxOnEdit.Text.Contains('|')) {
                detailsQuery = boxOnEdit.Text.Split('|').Last().ToLower();
            }
            else detailsQuery = boxOnEdit.Text.ToLower();

            Details.Refresh();
            detailSuggestionBox.PlacementTarget = boxOnEdit;
            detailSuggestionBox.PlacementRectangle = boxOnEdit.GetRectFromCharacterIndex(boxOnEdit.CaretIndex);
            detailSuggestionBox.IsOpen = true;
        }

        void setDetailOnClick(object sender, MouseButtonEventArgs e) {
            var selectedDetail = ((Details)detailSuggestionList.SelectedItem).Tag;
            if (boxOnEdit.Text.Contains('|')) {
                var subs = boxOnEdit.Text.Substring(0, boxOnEdit.Text.LastIndexOf('|') + 1);
                boxOnEdit.Text = subs + selectedDetail;
            }
            else boxOnEdit.Text = selectedDetail;
            boxOnEdit.CaretIndex = boxOnEdit.Text.Length;
            detailSuggestionBox.IsOpen = false;
            Keyboard.Focus(boxOnEdit);
        }

        void setDetail(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            var selectedDetail = ((Details)detailSuggestionList.SelectedItem).Tag;
            if (boxOnEdit.Text.Contains('|')) {
                var subs = boxOnEdit.Text.Substring(0, boxOnEdit.Text.LastIndexOf('|') + 1);
                boxOnEdit.Text = subs + selectedDetail;
            }
            else boxOnEdit.Text = selectedDetail;
            boxOnEdit.CaretIndex = boxOnEdit.Text.Length;
            detailSuggestionBox.IsOpen = false;
            Keyboard.Focus(boxOnEdit);
        }

        void onFilterChanged(object sender, SelectionChangedEventArgs e) {
            if (Words is null) return;
            var content = ((ComboBoxItem)e.AddedItems[0]).Content;
            switch (content) {
                case "All": Words.Filter = filterGetAll; break;
                case "Spelling Difference": Words.Filter = filterDifference; break;
            }
        }

        void setPartsOfSpeechOnClick(object sender, MouseButtonEventArgs e) {
            boxOnEdit.Text = ((PartsOfSpeech)posSuggestionList.SelectedItem).Tag;
            boxOnEdit.CaretIndex = boxOnEdit.Text.Length;
            posSuggestionBox.IsOpen = false;
            Keyboard.Focus(boxOnEdit);
        }
    }
}
