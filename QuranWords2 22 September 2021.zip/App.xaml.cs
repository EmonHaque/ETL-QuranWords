﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace QuranWords2
{

    public partial class App : Application
    {
        public static object Key;
        public static List<Occurence> occurenceList;
        public static List<CorpusData> corpusData;
        public static List<DiffData> okDiffs;
        public static List<PartsOfSpeech> poss;
        public static List<Details> details;

        protected override void OnStartup(StartupEventArgs e) {
            Key = new object();
            base.OnStartup(e);
            getData();
        }

        void getData() {
            occurenceList = new List<Occurence>();
            corpusData = new List<CorpusData>();
            okDiffs = new List<DiffData>();
            poss = new List<PartsOfSpeech>();
            details = new List<Details>();

            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = @"SELECT * FROM Words;
                                    WITH T (Surah, Ayah, Word, Segments) AS(
                                    	SELECT Surah, Ayah, Word, Count(Segment) 
                                    	FROM CorpusSegment
                                    	GROUP BY Surah, Ayah, Word
                                    )
                                    SELECT Minimal, Corpus,
                                    CASE WHEN IsSpellingOk IS NULL THEN Minimal = Corpus ELSE IsSpellingOk END IsSpellingOk,
                                    CASE WHEN IsSegmentationOk IS NULL THEN 0 ELSE 1 END IsSegmentationOk,
                                    Segments, count(*) Occurence FROM Words w
                                    LEFT JOIN T t ON (t.Surah = w.Surah AND t.Ayah = w.Ayah AND t.Word = WordNo)
                                    GROUP BY Minimal, Corpus
                                    ORDER BY Segments DESC;
                                    SELECT * FROM CorpusSegment ORDER BY Surah, Ayah, Word, Segment;
                                    SELECT * FROM PartsOfSpeech;
                                    SELECT * FROM Details";
            var reader = command.ExecuteReader();
            while (reader.Read()) {
                occurenceList.Add(new Occurence() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    WordNo = reader.GetInt32(2),
                    Minimal = reader.GetString(3),
                    Corpus = reader.IsDBNull(4) ? null : reader.GetString(4)
                });
            }
                       
            reader.NextResult();
            while (reader.Read()) {
                okDiffs.Add(new DiffData() {
                    Minimal = reader.GetString(0),
                    Corpus = reader.GetString(1),
                    IsSpellingOk = reader.GetBoolean(2),
                    IsSegmentationOk = reader.GetBoolean(3),
                    Segments = reader.GetInt32(4),
                    Occurence = reader.GetInt32(5)
                });
            }
            
            reader.NextResult();
            while (reader.Read()) {
                corpusData.Add(new CorpusData() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    Word = reader.GetInt32(2),
                    Segment = reader.GetInt32(3),
                    Content = reader.GetString(4),
                    POS = reader.GetString(5),
                    Detail = reader.IsDBNull(6) ? null : reader.GetString(6),
                    Root = reader.IsDBNull(7) ? null : reader.GetString(7)
                });
            }
            
            reader.NextResult();
            while (reader.Read()) {
                poss.Add(new PartsOfSpeech() {
                    Id = reader.GetInt32(0),
                    Name = reader.IsDBNull(1) ? "" : reader.GetString(1),
                    Tag = reader.GetString(2),
                    Description = reader.GetString(3)
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                details.Add(new Details() {
                    Id = reader.GetInt32(0),
                    Tag = reader.GetString(1),
                    Name = reader.IsDBNull(2) ? "" : reader.GetString(2),
                    Description = reader.GetString(3)
                });
            }

            connection.Close();
        }
    }
}
