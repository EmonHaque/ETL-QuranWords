﻿using System.ComponentModel;

namespace QuranWords2
{
    public class CorpusData : INotifyPropertyChanged
    {
        public int Surah { get; set; }
        public int Ayah { get; set; }
        public int Word { get; set; }
        public int Segment { get; set; }
        public string Content { get; set; }
        public string Root { get; set; }
        public string POS { get; set; }
        public string Detail { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;
        public void onChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
