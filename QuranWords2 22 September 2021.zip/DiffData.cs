﻿namespace QuranWords2
{
    public class DiffData
    {
        public string Minimal { get; set; }
        public string Corpus { get; set; }
        public bool IsSpellingOk { get; set; }
        public bool IsSegmentationOk { get; set; }
        public int Segments { get; set; }
        public int Occurence { get; set; }
    }
}
