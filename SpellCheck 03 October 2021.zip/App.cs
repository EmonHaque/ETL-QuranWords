﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace SpellCheck
{
    class App : Application
    {
        [STAThread]
        static void Main() => new App().Run();
        protected override void OnStartup(StartupEventArgs e) {
            Current.MainWindow = new MainWindow();
            Current.MainWindow.Show();
            Current.MainWindow.Activate();
        }
    }
}
