﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SpellCheck
{
    public partial class WordView : UserControl
    {
        List<Word> primaryList;
        List<Occurence> occurenceList;
        List<CorpusData> corpusData, matched;

        Word selectedWord;
        public Word SelectedWord {
            get { return selectedWord; }
            set { selectedWord = value; getCurrent(); }
        }
        
        public ObservableCollection<Word> Words { get; set; }
        public ObservableCollection<CorpusData> CurrentData { get; set; }

        public WordView() {
            InitializeComponent();
            getWords();
            CurrentData = new();
            DataContext = this;
        }

        void getWords() {
            primaryList = new List<Word>();
            Words = new ObservableCollection<Word>();
            occurenceList = new List<Occurence>();
            corpusData = new List<CorpusData>();
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var command = connection.CreateCommand();

            command.CommandText = @"SELECT * FROM Words;
                                    SELECT * From CorpusSegment;
                                    SELECT Minimal, Corpus FROM Words WHERE Minimal != Corpus GROUP BY Minimal, Corpus";
            var reader = command.ExecuteReader();
            while (reader.Read()) {
                occurenceList.Add(new Occurence() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    WordNo = reader.GetInt32(2),
                    Minimal = reader.GetString(3),
                    Corpus = reader.GetString(4)
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                corpusData.Add(new CorpusData() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    Word = reader.GetInt32(2),
                    Segment = reader.GetInt32(3),
                    Content = reader.GetString(4),
                    POS = reader.GetString(5),
                    Detail = reader.IsDBNull(6) ? null : reader.GetString(6),
                    Root = reader.IsDBNull(7) ? null : reader.GetString(7)
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                primaryList.Add(new Word() {
                    Minimal = reader.GetString(0),
                    Corpus = reader.GetString(1)
                });
            }

            connection.Close();

            foreach (var item in primaryList) {
                var old = item.Minimal;
                if (item.Minimal.StartsWith("ال")) {
                    var s = item.Minimal.Substring(3, 2);
                    if (s.Equals("َّ") /*shadda + fatha*/ ||
                        s.Equals("ِّ") /*shadda + kesra*/ ||
                        s.Equals("ُّ") /*shadda + damma*/) {
                        item.Minimal = item.Minimal.Remove(3, 1);
                    }
                    else if (s[0].Equals('ّ') /*shadda*/)
                        item.Minimal = item.Minimal.Remove(3, 1);
                }
                if (item.Minimal.StartsWith("وَال")) {
                    var s = item.Minimal.Substring(5, 2);
                    if (s.Equals("َّ") /*shadda + fatha*/ ||
                        s.Equals("ِّ") /*shadda + kesra*/ ||
                        s.Equals("ُّ") /*shadda + damma*/) {
                        item.Minimal = item.Minimal.Remove(5, 1);
                    }
                    else if (s[0].Equals('ّ') /*shadda*/)
                        item.Minimal = item.Minimal.Remove(5, 1);
                }
                if (item.Minimal.StartsWith("فَال")) {
                    var s = item.Minimal.Substring(5, 2);
                    if (s.Equals("َّ") /*shadda + fatha*/ ||
                        s.Equals("ِّ") /*shadda + kesra*/ ||
                        s.Equals("ُّ") /*shadda + damma*/) {
                        item.Minimal = item.Minimal.Remove(5, 1);
                    }
                    else if (s[0].Equals('ّ') /*shadda*/)
                        item.Minimal = item.Minimal.Remove(5, 1);
                }
                if (item.Minimal.StartsWith("بِال")) {
                    var s = item.Minimal.Substring(5, 2);
                    if (s.Equals("َّ") /*shadda + fatha*/ ||
                        s.Equals("ِّ") /*shadda + kesra*/ ||
                        s.Equals("ُّ") /*shadda + damma*/) {
                        item.Minimal = item.Minimal.Remove(5, 1);
                    }
                    else if (s[0].Equals('ّ') /*shadda*/)
                        item.Minimal = item.Minimal.Remove(5, 1);
                }
                if (item.Minimal.StartsWith("لِل")) {
                    var s = item.Minimal.Substring(4, 2);
                    if (s.Equals("َّ") /*shadda + fatha*/ ||
                        s.Equals("ِّ") /*shadda + kesra*/ ||
                        s.Equals("ُّ") /*shadda + damma*/) {
                        item.Minimal = item.Minimal.Remove(4, 1);
                    }
                    else if (s[0].Equals('ّ') /*shadda*/)
                        item.Minimal = item.Minimal.Remove(4, 1);
                }
                if (item.Minimal.StartsWith("كَال")) {
                    var s = item.Minimal.Substring(5, 2);
                    if (s.Equals("َّ") /*shadda + fatha*/ ||
                        s.Equals("ِّ") /*shadda + kesra*/ ||
                        s.Equals("ُّ") /*shadda + damma*/) {
                        item.Minimal = item.Minimal.Remove(5, 1);
                    }
                    else if (s[0].Equals('ّ') /*shadda*/)
                        item.Minimal = item.Minimal.Remove(5, 1);
                }
                if (item.Minimal.StartsWith("وَلِل")) {
                    var s = item.Minimal.Substring(6, 2);
                    if (s.Equals("َّ") /*shadda + fatha*/ ||
                        s.Equals("ِّ") /*shadda + kesra*/ ||
                        s.Equals("ُّ") /*shadda + damma*/) {
                        item.Minimal = item.Minimal.Remove(6, 1);
                    }
                    else if (s[0].Equals('ّ') /*shadda*/)
                        item.Minimal = item.Minimal.Remove(6, 1);
                }
                if (item.Minimal.StartsWith("وَلَل")) {
                    var s = item.Minimal.Substring(6, 2);
                    if (s.Equals("َّ") /*shadda + fatha*/ ||
                        s.Equals("ِّ") /*shadda + kesra*/ ||
                        s.Equals("ُّ") /*shadda + damma*/) {
                        item.Minimal = item.Minimal.Remove(6, 1);
                    }
                    else if (s[0].Equals('ّ') /*shadda*/)
                        item.Minimal = item.Minimal.Remove(6, 1);
                }
                if (item.Minimal.StartsWith("وَبِال")) {
                    var s = item.Minimal.Substring(7, 2);
                    if (s.Equals("َّ") /*shadda + fatha*/ ||
                        s.Equals("ِّ") /*shadda + kesra*/ ||
                        s.Equals("ُّ") /*shadda + damma*/) {
                        item.Minimal = item.Minimal.Remove(7, 1);
                    }
                    else if (s[0].Equals('ّ') /*shadda*/)
                        item.Minimal = item.Minimal.Remove(7, 1);
                }
                if (item.Minimal.Contains("ىٰ")) {
                    item.Minimal = item.Minimal.Replace("ىٰ", "ى") /*replace alif maksura with dragger alif with alif maksura*/;
                }
                if (item.Minimal.Contains("ٰ" /*dragger alif*/)) {
                    item.Minimal = item.Minimal.Replace('ٰ', 'َ') /*replace dragger alif with fatha*/;
                }
                if (item.Minimal.Contains("نَا")) {
                    item.Minimal = item.Minimal.Replace("نَا", "نا");
                }
                if (item.Minimal.Contains("هَا")) {
                    item.Minimal = item.Minimal.Replace("هَا", "ها");
                }
                if (!item.Minimal.Contains("أُ") &&
                    !item.Minimal.Contains("ُوَ") &&
                    !item.Minimal.Contains("ُوِ") &&
                    !item.Minimal.Contains("ُوّ") &&
                    item.Minimal.Contains("ُو")) {
                    item.Minimal = item.Minimal.Replace("ُو", "و"); /*replace damma followed by waw without short vowel with waw*/;
                }
                if (item.Minimal.Contains("ِي")) {
                    if (!item.Minimal.Contains("ِيا") &&
                        !item.Minimal.Contains("ِيَ") &&
                        !item.Minimal.Contains("ِيّ"))
                        item.Minimal = item.Minimal.Replace("ِي", "ي") /*replace kesra followed by ya without short vowel with ya*/;
                }
                if (item.Minimal.Contains("َا")) {
                    if (!item.Minimal.StartsWith("كَ") &&
                       !item.Minimal.StartsWith("فَ") &&
                       !item.Minimal.StartsWith("وَ"))

                        item.Minimal = item.Minimal.Replace("َا", "ا") /*replace fatha followed by alif with alif*/;
                }
                if (item.Minimal.Contains("َى")) {
                    item.Minimal = item.Minimal.Replace("َى", "ى") /*replace fatha followed by alif maksura with alif maksura*/;
                }

                if (item.Minimal.Contains("مَا")) item.Minimal = item.Minimal.Replace("مَا", "ما");
                if (item.Minimal.Contains("مَّا")) item.Minimal = item.Minimal.Replace("مَّا", "مّا");
                if (item.Minimal.Contains("نَّا")) item.Minimal = item.Minimal.Replace("نَّا", "نّا");
                if (item.Minimal.Contains("قَا")) item.Minimal = item.Minimal.Replace("قَا", "قا");

                if (!item.Minimal.Equals(item.Corpus)) {
                    item.Minimal = old;
                    Words.Add(item);
                }
            }
        }

        void getCurrent() {
            if (SelectedWord is null) return;
            var x = occurenceList.Where(x => x.Minimal.Equals(SelectedWord.Minimal) && x.Corpus.Equals(SelectedWord.Corpus)).ToList();
            CurrentData.Clear();
            var first = x.First();
            var list = corpusData.Where(x => x.Surah == first.Surah && x.Ayah == first.Ayah && x.Word == first.WordNo);
            foreach (var item in list) {
                CurrentData.Add(item);
            }
            matched = corpusData.Where(a => x.Any(b => a.Surah == b.Surah && a.Ayah == b.Ayah && a.Word == b.WordNo)).ToList();
        }

        void updateSegments(object sender, RoutedEventArgs e) {
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;


            transaction.Commit();
            connection.Close();

        }

        void save(object sender, RoutedEventArgs e) {
            var grouped = matched.GroupBy(x => new { x.Surah, x.Ayah, x.Word }).ToList();
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;
            foreach (var group in grouped) {
                foreach (var data in CurrentData) {
                    command.CommandText = @$"UPDATE CorpusSegment SET Content = '{data.Content}' WHERE Surah = {group.Key.Surah}
                                            AND Ayah = {group.Key.Ayah} AND Word = {group.Key.Word} AND Segment = {data.Segment}";
                    command.ExecuteNonQuery();
                }
            }
            transaction.Commit();
            connection.Close();
            Words.Remove(SelectedWord);
        }

        void remove(object sender, RoutedEventArgs e) {
            var selected = wordList.SelectedItems.Cast<Word>().ToList();
            for (int i = 0; i < selected.Count; i++) {
                Words.Remove(selected[i]);
            }
        }
    }
}
