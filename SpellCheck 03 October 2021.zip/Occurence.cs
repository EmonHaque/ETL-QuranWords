﻿namespace SpellCheck
{
    public class Occurence
    {
        public int Surah { get; set; }
        public int Ayah { get; set; }
        public int WordNo { get; set; }
        public string Minimal { get; set; }
        public string Corpus { get; set; }
        public bool IsOk { get; set; }
    }
}
