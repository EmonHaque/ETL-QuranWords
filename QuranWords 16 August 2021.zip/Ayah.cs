﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuranWords
{
    public class Ayah
    {
        public int No { get; set; }
        public List<SegmentedWord> Words { get; set; }
    }
}
