﻿using Microsoft.Data.Sqlite;
using System.Diagnostics;
using System.IO;
using System.Windows;

namespace QuranWords
{
    public partial class MainWindow : Window
    {
        public MainWindow() {
            InitializeComponent();
        }
    }
}
