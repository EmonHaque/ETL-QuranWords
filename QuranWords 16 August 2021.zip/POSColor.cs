﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace QuranWords
{
    public class POSColor
    {
        public int Id { get; set; }
        public Color Color { get; set; }
    }
}
