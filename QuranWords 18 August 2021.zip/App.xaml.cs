﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace QuranWords
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static object Key;
        public static List<POSColor> POSs;
        protected override void OnStartup(StartupEventArgs e) {
            base.OnStartup(e);
            Key = new object();

            POSs = new List<POSColor>();
            var rand = new Random();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT * From PartsOfSpeech";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    POSs.Add(new POSColor() { 
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1)
                    });
                }
                connection.Close();
            }

            foreach (var pos in POSs) {
                switch (pos.Name) {
                    case "Noun": pos.Color = Colors.Black; break;
                    case "Pronoun": pos.Color = Colors.Green; break;
                    case "Adjective": pos.Color = Colors.Blue; break;
                    case "Verb": pos.Color = Colors.Coral; break;
                    //case "Adverb": pos.Color = Colors.Black; break;
                    case "Preposition": pos.Color = Colors.Red; break;
                    case "Conjunction": pos.Color = Colors.Bisque; break;
                    //case "Interjection": pos.Color = Colors.Black; break;
                    case "Article": pos.Color = Colors.Gray; break;
                    case "Negation": pos.Color = Colors.LightBlue; break;
                    //case "Initial": pos.Color = Colors.Black; break;
                }
            }
        }
    }
}
