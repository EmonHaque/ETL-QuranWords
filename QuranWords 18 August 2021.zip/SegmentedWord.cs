﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuranWords
{
    public class SegmentedWord
    {
        public int Ayah { get; set; }
        public int WordNo { get; set; }
        public int SegmentNo { get; set; }
        public string Clean { get; set; }
        public string Minimal { get; set; }
        public string Full { get; set; }
        public int POS { get; set; }
    }
}
