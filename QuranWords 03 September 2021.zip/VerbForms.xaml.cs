﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    public partial class VerbForms : UserControl
    {
        public List<VerbDef> VerbDefs { get; set; }
        public VerbForms() {
            InitializeComponent();
            getVerbs();
        }

        void getVerbs() {
            VerbDefs = new List<VerbDef>();
            var patterns = new List<VerbPattern>();

            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = @"SELECT * FROM VerbDef;
                                        SELECT * FROM VerbForms";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    VerbDefs.Add(new VerbDef() {
                        Id = reader.GetInt32(0),
                        Arabic = reader.GetString(1),
                        English = reader.GetString(2)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    patterns.Add(new VerbPattern() {
                        PatternNo = reader.GetInt32(0),
                        DefId = reader.GetInt32(1),
                        SubPatternNo = reader.GetInt32(2),
                        Pattern = reader.GetString(3)
                    });
                }
                connection.Close();
            }

            var groups = patterns.GroupBy(x => x.PatternNo, (k, v) => new { No = k, Values = v });
            var grid = new Grid() { Margin = new Thickness(10), ShowGridLines = true };

            for (int i = 0; i < 10; i++) {
                grid.RowDefinitions.Add(new RowDefinition());
                grid.ColumnDefinitions.Add(new ColumnDefinition());
            }
            for (int i = 0; i < 10; i++)
                grid.ColumnDefinitions.Add(new ColumnDefinition());

            for (int i = 2; i < 10; i++) {
                var sideHead = new TextBlock() {
                    Inlines = {
                        new Run() {
                            Text = VerbDefs[i - 2].Arabic,
                            Foreground = Brushes.Green,
                            FontSize = 40,
                            FontFamily = new FontFamily("Scheherazade")
                        },
                        new LineBreak(),
                        new Run(){ Text = VerbDefs[i - 2].English, Foreground = Brushes.LightBlue, FontSize = 20 }
                        },
                    Margin = new Thickness(0, 0, 20, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetRow(sideHead, i);
                grid.Children.Add(sideHead);
            }

            var topLeftBlock = new TextBlock() {
                Text = "Forms",
                FontSize = 40,
                Margin = new Thickness(0, 0, 20, 0),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Green,
                FontWeight = FontWeights.Bold
            };
            Grid.SetRowSpan(topLeftBlock, 2);
            grid.Children.Add(topLeftBlock);

            int colIndex = 1;
            foreach (var group in groups) {
                if (group.No == 1 || group.No == 14) {
                    var subGroups = group.Values.GroupBy(x => x.SubPatternNo, (k, v) => new { No = k, Values = v });
                    var headBlock = new TextBlock() {
                        Text = "Form " + group.No,
                        FontSize = 20,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    Grid.SetColumn(headBlock, colIndex);
                    Grid.SetColumnSpan(headBlock, subGroups.Count());
                    grid.Children.Add(headBlock);

                    foreach (var subGroup in subGroups) {
                        var subHeadBlock = new TextBlock() {
                            Text = "Pattern " + subGroup.No,
                            FontSize = 15,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        };
                        Grid.SetColumn(subHeadBlock, colIndex);
                        Grid.SetRow(subHeadBlock, 1);
                        grid.Children.Add(subHeadBlock);

                        int rowIndex = 2;
                        foreach (var pattern in subGroup.Values) {
                            var content = new TextBlock() {
                                Text = pattern.Pattern,
                                FlowDirection = FlowDirection.RightToLeft,
                                FontFamily = new FontFamily("Scheherazade"),
                                FontSize = 50,
                                HorizontalAlignment = HorizontalAlignment.Center,
                                Margin = new Thickness(10, 0, 10, 0)
                            };
                            Grid.SetColumn(content, colIndex);
                            Grid.SetRow(content, rowIndex++);
                            grid.Children.Add(content);
                        }
                        colIndex++;
                    }
                }
                else {
                    var headBlock = new TextBlock() {
                        Text = "Form " + group.No,
                        FontSize = 20,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    Grid.SetColumn(headBlock, colIndex);
                    Grid.SetRowSpan(headBlock, 2);
                    grid.Children.Add(headBlock);

                    int rowIndex = 2;
                    foreach (var pattern in group.Values) {
                        var content = new TextBlock() {
                            Text = pattern.Pattern,
                            FlowDirection = FlowDirection.RightToLeft,
                            FontFamily = new FontFamily("Scheherazade"),
                            FontSize = 50,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            Margin = new Thickness(10, 0, 10, 0)
                        };
                        Grid.SetColumn(content, colIndex);
                        Grid.SetRow(content, rowIndex++);
                        grid.Children.Add(content);
                    }
                    colIndex++;
                }
            }
            scr.Content = grid;

        }
    }
}
