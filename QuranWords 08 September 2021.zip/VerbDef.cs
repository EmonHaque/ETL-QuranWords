﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuranWords
{
    public class VerbDef
    {
        public int Id { get; set; }
        public string Arabic { get; set; }
        public string English { get; set; }
    }

    public class VerbPattern
    {
        public int PatternNo { get; set; }
        public int DefId { get; set; }
        public int SubPatternNo { get; set; }
        public string Pattern { get; set; }
    }
}
