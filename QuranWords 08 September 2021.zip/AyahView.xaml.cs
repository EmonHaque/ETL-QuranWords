﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    /// <summary>
    /// Interaction logic for AyahView.xaml
    /// </summary>
    public partial class AyahView : UserControl
    {
        List<AyahUnedited> ayahs;
        string query;
        public string Query {
            get { return query; }
            set { query = value; Ayahs.Refresh(); }
        }
        public ICollectionView Ayahs { get; set; }

        public AyahView() {
            InitializeComponent();
            getAyahs();
            Ayahs = new CollectionViewSource() { Source = ayahs }.View;
            Ayahs.Filter = filter;
            DataContext = this;
        }

        bool filter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((AyahUnedited)o).Arabic.Contains(Query);
        }

        void getAyahs() {
            ayahs = new List<AyahUnedited>();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT Surah, Ayah, Minimal, Bangla FROM Ayah";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    ayahs.Add(new AyahUnedited() {
                        Surah = reader.GetInt32(0),
                        Ayah = reader.GetInt32(1),
                        Arabic = reader.GetString(2),
                        Bangla = reader.GetString(3)
                    });
                }
                connection.Close();
            }
        }

        void showTranslation(object sender, MouseButtonEventArgs e) {
            if(popTranslation.IsOpen) popTranslation.IsOpen = false;
            popTranslation.IsOpen = true;
        }

        void closeTranslation(object sender, MouseButtonEventArgs e) {
            popTranslation.IsOpen = false;
        }
    }
}
