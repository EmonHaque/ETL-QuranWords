﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    /// <summary>
    /// Interaction logic for SurahView.xaml
    /// </summary>
    public partial class SurahView : UserControl
    {
        public List<Ayah> Surah { get; set; }
        public SurahView() {
            InitializeComponent();

            var list = new List<SegmentedWord>();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT Ayah, WordNo, SegmentNo, Minimal, PartsOfSpeech FROM Segments WHERE Surah = 1 ORDER BY Ayah, WordNo, SegmentNo";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    list.Add(new SegmentedWord() {
                        Ayah = reader.GetInt32(0),
                        WordNo = reader.GetInt32(1),
                        SegmentNo = reader.GetInt32(2),
                        Minimal = reader.GetString(3),
                        POS = reader.GetInt32(4)
                    });
                }
                connection.Close();
            }
            Surah = list.GroupBy(x => x.Ayah, (a, w) => new Ayah() {
                No = a,
                Words = w.ToList()
            }).ToList();

            DataContext = this;
        }
    }
}
