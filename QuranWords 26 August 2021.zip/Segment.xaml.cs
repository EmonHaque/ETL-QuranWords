﻿using HtmlAgilityPack;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    public partial class Segment : UserControl
    {
        string[] queryParts;
        string posQuery;
        Occurence lookupOccurence;
        string query;
        public string Query {
            get { return query; }
            set {
                query = value.Trim();
                if (((ComboBoxItem)filterCombo.SelectedItem).Content.Equals("Starts and Ends with"))
                    queryParts = query.Split(' ');
                MinimalWords.Refresh();
            }
        }
        Word selectedCleanWord;
        public Word SelectedCleanWord {
            get { return selectedCleanWord; }
            set { selectedCleanWord = value; getCleanOccurences(); }
        }
        Word selectedMinimalWord;
        public Word SelectedMinimalWord {
            get { return selectedMinimalWord; }
            set {
                selectedMinimalWord = value;
                getOccurences();
                CleanWords.Refresh();
                FullWords.Refresh();
            }
        }
        Word selectedFullWord;
        public Word SelectedFullWord {
            get { return selectedFullWord; }
            set { selectedFullWord = value; getFullOccurences(); }
        }

        List<Occurence> occurenceList;
        ObservableCollection<Word> minimalWords, cleanWords, fullWords;
        public static ObservableCollection<PartsOfSpeech> pos;
        CollectionViewSource posSource;
        public ICollectionView MinimalWords { get; set; }
        public ICollectionView CleanWords { get; set; }
        public ICollectionView FullWords { get; set; }
        public ICollectionView POS { get; set; }

        public ObservableCollection<Occurence> Occurences { get; set; }
        public ObservableCollection<Occurence> CleanOccurences { get; set; }
        public ObservableCollection<Occurence> FullOccurences { get; set; }

        public Occurence SelectedMinimalOccurence { get; set; }
        public Occurence SelectedFullOccurence { get; set; }

        public Segment() {
            InitializeComponent();
            getWords();
            getPOS();
            MinimalWords = new CollectionViewSource() { Source = minimalWords }.View;
            CleanWords = new CollectionViewSource() { Source = cleanWords }.View;
            FullWords = new CollectionViewSource() { Source = fullWords }.View;
            MinimalWords.Filter = startWithFilter;
            CleanWords.Filter = filterWords;
            FullWords.Filter = filterWords;
            Occurences = new ObservableCollection<Occurence>();
            CleanOccurences = new ObservableCollection<Occurence>();
            FullOccurences = new ObservableCollection<Occurence>();
            DataContext = this;
        }

        bool filterWords(object o) {
            if (SelectedMinimalWord is null) return false;
            return ((Word)o).Minimal.Equals(SelectedMinimalWord.Original);
        }
        void getPOS() {
            pos = new ObservableCollection<PartsOfSpeech>();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM PartsOfSpeech";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    pos.Add(new PartsOfSpeech() {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Description = reader.GetString(2)
                    });
                }
                connection.Close();
            }
            posSource = new CollectionViewSource() {
                Source = pos,
                IsLiveSortingRequested = true,
                LiveSortingProperties = { "Name", "Description" }
            };
            POS = posSource.View;
            POS.Filter = filterPOS;
            POS.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
            POS.SortDescriptions.Add(new SortDescription("Description", ListSortDirection.Ascending));
        }
        bool filterPOS(object o) {
            if (string.IsNullOrWhiteSpace(posQuery)) return true;
            return ((PartsOfSpeech)o).Name.ToLower().StartsWith(posQuery);
        }
        bool startWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.StartsWith(Query);
        }
        bool endWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.EndsWith(Query);
        }
        bool startAndEndWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var word = (Word)o;
            if (queryParts.Length > 1)
                return word.Original.StartsWith(queryParts[0]) && word.Original.EndsWith(queryParts[1]);
            return word.Original.StartsWith(queryParts[0]);
        }
        bool containFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.Contains(Query);
        }
        bool equalFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.Equals(Query);
        }
        bool patternStartWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var word = ((Word)o).Original;
            bool match = word.Length >= Query.Length;
            if (match) {
                for (int i = 0; i < Query.Length; i++) {
                    if (Query[i].Equals('ـ')) continue; // SHIFT + B
                    if (!Query[i].Equals(word[i])) {
                        match = false;
                        break;
                    }
                }
            }
            return match;
        }
        bool patternEqualsFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var word = ((Word)o).Original;
            bool match = word.Length == Query.Length;
            if (match) {
                for (int i = 0; i < Query.Length; i++) {
                    if (Query[i].Equals('ـ')) continue; // SHIFT + B
                    if (!Query[i].Equals(word[i])) {
                        match = false;
                        break;
                    }
                }
            }
            return match;
        }
        void getWords() {
            minimalWords = new ObservableCollection<Word>();
            cleanWords = new ObservableCollection<Word>();
            fullWords = new ObservableCollection<Word>();
            occurenceList = new List<Occurence>();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = @"SELECT Minimal, Count(*) Number FROM Words WHERE IsSegregated ISNULL GROUP BY Minimal ORDER BY Number DESC;
                                        SELECT Minimal, Clean, COUNT(*) Number FROM Words WHERE IsSegregated ISNULL GROUP BY Minimal ORDER BY Number DESC;
                                        SELECT Minimal, Full, COUNT(*) Number FROM Words WHERE IsSegregated ISNULL GROUP BY Minimal, Full ORDER BY Number DESC;
                                        SELECT * FROM Words";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    minimalWords.Add(new Word() {
                        Original = reader.GetString(0),
                        Edited = reader.GetString(0),
                        Occurence = reader.GetInt32(1)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    cleanWords.Add(new Word() {
                        Minimal = reader.GetString(0),
                        Original = reader.GetString(1),
                        Edited = reader.GetString(1),
                        Occurence = reader.GetInt32(2)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    fullWords.Add(new Word() {
                        Minimal = reader.GetString(0),
                        Original = reader.GetString(1),
                        Edited = reader.GetString(1),
                        Occurence = reader.GetInt32(2)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    occurenceList.Add(new Occurence() {
                        Surah = reader.GetInt32(0),
                        Ayah = reader.GetInt32(1),
                        WordNo = reader.GetInt32(2),
                        Clean = reader.GetString(3),
                        Minimal = reader.GetString(4),
                        Full = reader.GetString(5)
                    });
                }
                connection.Close();
            }
        }
        void getOccurences() {
            Occurences.Clear();
            if (SelectedMinimalWord is null) return;
            for (int i = 0; i < occurenceList.Count; i++) {
                if (occurenceList[i].Minimal.Equals(SelectedMinimalWord.Original))
                    Occurences.Add(occurenceList[i]);
            }
        }
        void getCleanOccurences() {
            CleanOccurences.Clear();
            if (SelectedCleanWord is null) return;
            foreach (var word in Occurences) {
                if (word.Clean.Equals(SelectedCleanWord.Original))
                    CleanOccurences.Add(word);
            }
        }
        void getFullOccurences() {
            FullOccurences.Clear();
            if (SelectedFullWord is null) return;
            foreach (var word in Occurences) {
                if (word.Full.Equals(SelectedFullWord.Original))
                    FullOccurences.Add(word);
            }
        }
        void SetFilter(object sender, SelectionChangedEventArgs e) {
            if (MinimalWords is null) return;
            var content = ((ComboBoxItem)e.AddedItems[0]).Content;
            switch (content) {
                case "Starts with": MinimalWords.Filter = startWithFilter; break;
                case "Ends with": MinimalWords.Filter = endWithFilter; break;
                case "Starts and Ends with":
                    if (Query is not null) queryParts = Query.Split(' ');
                    MinimalWords.Filter = startAndEndWithFilter;
                    break;
                case "Contains": MinimalWords.Filter = containFilter; break;
                case "Equals": MinimalWords.Filter = equalFilter; break;
                case "Pattern starts with": MinimalWords.Filter = patternStartWithFilter; break;
                case "Pattern equals": MinimalWords.Filter = patternEqualsFilter; break;
            }
        }
        void Sort(object sender, RoutedEventArgs e) {
            var button = (Button)sender;
            MinimalWords.SortDescriptions.Clear();
            if (button.Content.ToString().Contains("DESC")) {
                button.Content = "Sort ASC";
                MinimalWords.SortDescriptions.Add(new SortDescription("Occurence", ListSortDirection.Ascending));
            }
            else {
                button.Content = "Sort DESC";
                MinimalWords.SortDescriptions.Add(new SortDescription("Occurence", ListSortDirection.Descending));
            }
        }
        void Suggest(object sender, TextChangedEventArgs e) {
            posQuery = posBox.Text.Split("\r\n").Last().ToLower();
            if (!string.IsNullOrWhiteSpace(posQuery)) {
                POS.Refresh();
                suggestionBox.PlacementRectangle = posBox.GetRectFromCharacterIndex(posBox.CaretIndex);
                suggestionBox.IsOpen = true;
            }
            else suggestionBox.IsOpen = false;
        }
        void FocusSuggestion(object sender, KeyEventArgs e) {
            if (e.Key != Key.Down) return;
            if (suggestionBox.IsOpen) {
                suggestionList.SelectedIndex = 0;
                Keyboard.Focus((ListBoxItem)suggestionList.ItemContainerGenerator.ContainerFromItem(suggestionList.SelectedItem));
            }
        }
        void SetPartsOfSpeech(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            if (posBox.Text.Contains("\r\n")) {
                posBox.Text = posBox.Text.Remove(posBox.Text.LastIndexOf("\r\n") + 2);
                posBox.Text += suggestionList.SelectedItem.ToString();
            }
            else posBox.Text = suggestionList.SelectedItem.ToString();
            posBox.CaretIndex = posBox.Text.Length;
            suggestionBox.IsOpen = false;
            Keyboard.Focus(posBox);
        }
        void SetPartsOfSpeechOnClick(object sender, MouseButtonEventArgs e) {
            if (posBox.Text.Contains("\r\n")) {
                posBox.Text = posBox.Text.Remove(posBox.Text.LastIndexOf("\r\n") + 2);
                posBox.Text += suggestionList.SelectedItem.ToString();
            }
            else posBox.Text = suggestionList.SelectedItem.ToString();
            posBox.CaretIndex = posBox.Text.Length;
            suggestionBox.IsOpen = false;
            Keyboard.Focus(posBox);
        }
        void Update(object sender, RoutedEventArgs e) {
            try {
                foreach (var item in Occurences) {
                    item.Minimal = SelectedMinimalWord.Edited;
                    item.Clean = cleanWords.First(x => x.Original.Equals(item.Clean)).Edited;
                    item.Full = fullWords.First(x => x.Original.Equals(item.Full)).Edited;
                }
                var partsOfSpeech = posBox.Text.Split("\r\n");
                var posIDs = new List<int>();

                lock (App.Key) {
                    using var connection = new SqliteConnection("data source = quran.db");
                    connection.Open();
                    using var transaction = connection.BeginTransaction();
                    using var command = connection.CreateCommand();
                    command.Transaction = transaction;

                    foreach (var segment in partsOfSpeech) {
                        if (int.TryParse(segment.Substring(0, segment.IndexOf(' ')), out int id))
                            posIDs.Add(id);
                        else {
                            int newId = pos.Count == 0 ? 1 : pos.Max(x => x.Id) + 1;
                            var parts = segment.Split(" - ");
                            var newPOS = new PartsOfSpeech() {
                                Id = newId,
                                Name = parts[0],
                                Description = parts[1]
                            };
                            posIDs.Add(newId);
                            pos.Add(newPOS);
                            command.CommandText = $"INSERT INTO PartsOfSpeech VALUES({newPOS.Id}, '{newPOS.Name}', '{newPOS.Description}')";
                            command.ExecuteNonQuery();
                        }
                    }

                    foreach (var word in Occurences) {
                        var minParts = word.Minimal.Split(' ');
                        var cleanParts = word.Clean.Split(' ');
                        var fullParts = word.Full.Split(' ');
                        var segmentNo = 1;
                        for (int i = 0; i < minParts.Length; i++) {
                            command.CommandText = $"INSERT INTO Segments VALUES({word.Surah}, {word.Ayah}, {word.WordNo}, {segmentNo++}, '{cleanParts[i]}', '{minParts[i]}', '{fullParts[i]}', {posIDs[i]}, null, null)";
                            command.ExecuteNonQuery();
                        }
                    }
                    command.CommandText = $"UPDATE Words Set IsSegregated = 1 WHERE Minimal = '{SelectedMinimalWord.Original}'";
                    command.ExecuteNonQuery();
                    transaction.Commit();
                    connection.Close();
                }
                minimalWords.Remove(SelectedMinimalWord);
            }
            catch (Exception) {
                MessageBox.Show("Some Error", "Error");
            }
        }
        void UpdateBulk(object sender, RoutedEventArgs e) {
            if (minimalBox.SelectedItems.Count < 2) {
                MessageBox.Show("Select multiple words", "Error");
                return;
            }
            try {
                var partsOfSpeech = posBox.Text.Split("\r\n");
                var posIDs = new List<int>();

                lock (App.Key) {
                    using var connection = new SqliteConnection("data source = quran.db");
                    connection.Open();
                    using var transaction = connection.BeginTransaction();
                    using var command = connection.CreateCommand();
                    command.Transaction = transaction;

                    foreach (var segment in partsOfSpeech) {
                        if (int.TryParse(segment.Substring(0, segment.IndexOf(' ')), out int id))
                            posIDs.Add(id);
                        else {
                            int newId = pos.Count == 0 ? 1 : pos.Max(x => x.Id) + 1;
                            var parts = segment.Split(" - ");
                            var newPOS = new PartsOfSpeech() {
                                Id = newId,
                                Name = parts[0],
                                Description = parts[1]
                            };
                            posIDs.Add(newId);
                            pos.Add(newPOS);
                            command.CommandText = $"INSERT INTO PartsOfSpeech VALUES({newPOS.Id}, '{newPOS.Name}', '{newPOS.Description}')";
                            command.ExecuteNonQuery();
                        }
                    }

                    foreach (Word w in minimalBox.SelectedItems) {
                        var occurences = occurenceList.Where(x => x.Minimal.Equals(w.Original)).ToList();
                        foreach (var word in occurences) {
                            var minParts = w.Edited.Split(' ');
                            var cleanParts = cleanWords.First(x => x.Original.Equals(word.Clean)).Edited.Split(' ');
                            var fullParts = fullWords.First(x => x.Original.Equals(word.Full)).Edited.Split(' ');
                            var segmentNo = 1;
                            for (int i = 0; i < minParts.Length; i++) {
                                command.CommandText = $"INSERT INTO Segments VALUES({word.Surah}, {word.Ayah}, {word.WordNo}, {segmentNo++}, '{cleanParts[i]}', '{minParts[i]}', '{fullParts[i]}', {posIDs[i]}, null, null)";
                                command.ExecuteNonQuery();
                            }
                            command.CommandText = $"UPDATE Words Set IsSegregated = 1 WHERE Minimal = '{w.Original}'";
                            command.ExecuteNonQuery();
                        }
                    }
                    transaction.Commit();
                    connection.Close();
                }
                int count = minimalBox.SelectedItems.Count;
                for (int i = 0; i < count; i++) {
                    minimalWords.Remove((Word)minimalBox.SelectedItems[0]);
                }
            }
            catch (Exception) {

                MessageBox.Show("Some Error", "Error");
            }
        }

        async void onCorpusOpened(object sender, EventArgs e) {
            var url = $"https://corpus.quran.com/wordbyword.jsp?chapter={lookupOccurence.Surah}&verse={lookupOccurence.Ayah}";
            var html = new HtmlWeb();
            HtmlDocument doc = null;
            try { doc = html.Load(url); }
            catch (Exception) {
                popCorpus.IsOpen = false;
                MessageBox.Show("Some network error", "Error");
                return;
            }
            var table = doc.DocumentNode.SelectSingleNode("//table[@class='morphologyTable']");
            var rows = table.SelectNodes(".//tr");
            table.RemoveChildren(rows);
            table.AppendChild(rows.First(x => x.HasClass("head")));
            rows.RemoveAt(0);

            var refPattern = lookupOccurence.Surah + ":" + lookupOccurence.Ayah + ":";
            foreach (var row in rows) {
                var segment = row.SelectSingleNode(".//span[@class='location']").InnerText.Remove(0,1);
                if (segment.StartsWith(refPattern)) {
                    var image = row.SelectSingleNode(".//td[@class='ic']/a/img");
                    var id = image.Attributes["src"].Value;
                    image.Attributes["src"].Value = "https://corpus.quran.com/" + id;
                    table.AppendChild(row);
                }
            }

            await web.EnsureCoreWebView2Async();
            web.CoreWebView2.NavigateToString(table.OuterHtml);
        }
        void showCorpus(object sender, MouseButtonEventArgs e) {
            if (popCorpus.IsOpen) popCorpus.IsOpen = false;
            if (minimalBox.SelectedItem is null) return;
            var word = (Word)minimalBox.SelectedItem;
            lookupOccurence = Occurences.First(x => x.Minimal.Equals(word.Original));
            popCorpus.IsOpen = true;
        }
        void onFullOccurenceRightClick(object sender, MouseButtonEventArgs e) {
            if (popCorpus.IsOpen) popCorpus.IsOpen = false;
            if (SelectedFullOccurence is null) return;
            lookupOccurence = SelectedFullOccurence;
            popCorpus.IsOpen = true;
        }
        void onMinimalOccurenceRightClick(object sender, MouseButtonEventArgs e) {
            if (popCorpus.IsOpen) popCorpus.IsOpen = false;
            if (SelectedMinimalOccurence is null) return;
            lookupOccurence = SelectedMinimalOccurence;
            popCorpus.IsOpen = true;
        }
        void closeCorpus(object sender, MouseButtonEventArgs e) {
            if (popCorpus.IsOpen)
                popCorpus.IsOpen = false;
        }
    }
}
