﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords2
{
    public partial class SpellingDiffs : UserControl
    {
        List<Occurence> occurenceList;
        List<CorpusData> data;
        DiffData selectedDiff;
        public DiffData SelectedDiff {
            get { return selectedDiff; }
            set { selectedDiff = value; getCurrent(); }
        }

        public ObservableCollection<DiffData> Diffs { get; set; }
        public ObservableCollection<CorpusData> CurrentData { get; set; }

        public SpellingDiffs() {
            InitializeComponent();
            getData();
            CurrentData = new ObservableCollection<CorpusData>();
            DataContext = this;
        }

        void getData() {
            Diffs = new ObservableCollection<DiffData>();
            data = new List<CorpusData>();
            occurenceList = new List<Occurence>();

            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = @"SELECT * FROM Words;
                                        SELECT Minimal, Corpus, count(*) Number, IsOk FROM Words
                                        WHERE Minimal <> Corpus AND IsOk IS NULL
                                        GROUP BY Minimal, Corpus;
                                        SELECT * FROM CorpusSegment";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    occurenceList.Add(new Occurence() {
                        Surah = reader.GetInt32(0),
                        Ayah = reader.GetInt32(1),
                        WordNo = reader.GetInt32(2),
                        Minimal = reader.GetString(3),
                        Corpus = reader.GetString(4)
                    });
                }

                reader.NextResult();
                while (reader.Read()) {
                    Diffs.Add(new DiffData() {
                        Minimal = reader.GetString(0),
                        Corpus = reader.GetString(1),
                        Count = reader.GetInt32(2),
                        IsOk = reader.IsDBNull(3) ? false : true
                    });
                }

                reader.NextResult();
                while (reader.Read()) {
                    data.Add(new CorpusData() {
                        Surah = reader.GetInt32(0),
                        Ayah = reader.GetInt32(1),
                        Word = reader.GetInt32(2),
                        Segment = reader.GetInt32(3),
                        Content = reader.GetString(4),
                        POS = reader.GetInt32(5),
                        Detail = reader.IsDBNull(6) ? null : reader.GetString(6),
                        Root = reader.IsDBNull(7) ? null : reader.GetString(7)
                    });
                }
                connection.Close();
            }
        }

        void getCurrent() {
            CurrentData.Clear();
            if (SelectedDiff is null) return;
            var o = occurenceList.First(x => x.Minimal.Equals(SelectedDiff.Minimal) && x.Corpus.Equals(SelectedDiff.Corpus));
            var first = data.Where(x => x.Surah == o.Surah && x.Ayah == o.Ayah && x.Word == o.WordNo);
            foreach (var d in first) {
                CurrentData.Add(d);
            }
        }

        void setOK(object sender, RoutedEventArgs e) {
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;

            List<DiffData> toBeRemoved = new();
            foreach (DiffData word in diffList.Items) {
                if (!word.IsOk) continue;
                command.CommandText = $"UPDATE Words SET IsOk = 1 WHERE Minimal = '{word.Minimal}' AND Corpus = '{word.Corpus}'";
                command.ExecuteNonQuery();
                toBeRemoved.Add(word);
            }
            transaction.Commit();
            connection.Close();
            foreach (var diff in toBeRemoved) {
                Diffs.Remove(diff);
            }
        }

        void updateSegments(object sender, RoutedEventArgs e) {
            if(SelectedDiff is null) {
                MessageBox.Show("Select an item", "Error");
                return;
            }
            var newWord = "";
            foreach (var segment in CurrentData) {
                newWord += segment.Content;
            }
            if (!newWord.Equals(SelectedDiff.Minimal)) {
                var confirmation = MessageBox.Show(
                    $"{newWord} doesn't match with Minimal\n\nWant to continue?",
                    "Question",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question
                    );
                if (confirmation == MessageBoxResult.No) return;
            }
            var o = occurenceList.Where(x => x.Minimal.Equals(SelectedDiff.Minimal) && x.Corpus.Equals(SelectedDiff.Corpus)).ToList();
            var words = data
                .Where(x => o.Any(y => y.Surah == x.Surah && y.Ayah == x.Ayah && y.WordNo == x.Word))
                .GroupBy(x => new { x.Surah, x.Ayah, x.Word }).ToList();

            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;

            string content = "";
            foreach (var word in words) {
                foreach (var segment in word) {
                    content = CurrentData.First(x => x.Segment == segment.Segment).Content;
                    command.CommandText = @$"UPDATE CorpusSegment SET Content = '{content}', Updated = 1 WHERE Surah = {segment.Surah}
                                        AND Ayah = {segment.Ayah} AND Word = {segment.Word} AND Segment = {segment.Segment}";
                    command.ExecuteNonQuery();
                }
            }
            foreach (var occurence in o) {
                command.CommandText = @$"UPDATE Words SET Corpus = '{newWord}', IsOk = 1 WHERE Surah = {occurence.Surah}
                                        AND Ayah = {occurence.Ayah} AND WordNo = {occurence.WordNo}";
                command.ExecuteNonQuery();
            }
            transaction.Commit();
            connection.Close();
            Diffs.Remove(SelectedDiff);
        }
    }
}
