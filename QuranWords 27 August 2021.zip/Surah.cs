﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuranWords
{
    public class Surah
    {
        public int No { get; set; }
        public string Arabic { get; set; }
        public string Bangla { get; set; }
    }
}
