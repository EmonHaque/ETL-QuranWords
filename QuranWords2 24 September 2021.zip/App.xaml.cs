﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
/*
 WITH T(Surah, Ayah, Word, Segment, Content, POS, Detail, Root) AS(
	SELECT Surah, Ayah, Word, Segment, substr(Content, 1,1), POS, Detail, Root
	FROM CorpusSegment WHERE Content = 'وا'
	UNION ALL
	SELECT Surah, Ayah, Word, Segment, substr(Content, 2,1), 'ALIF', '', Root
	FROM CorpusSegment WHERE Content = 'وا'
)
INSERT INTO CorpusSegment
SELECT * FROM T ORDER BY Surah, Ayah, Word, Segment;
DELETE FROM CorpusSegment WHERE Content = 'وا'
 */
namespace QuranWords2
{
    public partial class App : Application
    {
        public static object Key;
        public static List<Occurence> occurenceList;
        public static List<CorpusData> corpusData;
        public static List<DiffData> okDiffs;
        public static List<PartsOfSpeech> poss;
        public static List<Details> details;
        public static List<Translation> translation;

        protected override void OnStartup(StartupEventArgs e) {
            Key = new object();
            base.OnStartup(e);
            getData();
        }

        void getData() {
            occurenceList = new List<Occurence>();
            corpusData = new List<CorpusData>();
            okDiffs = new List<DiffData>();
            poss = new List<PartsOfSpeech>();
            details = new List<Details>();
            translation = new List<Translation>();

            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = @"SELECT * FROM Words;
                                    WITH T (Surah, Ayah, Word, Segments) AS(
                                    	SELECT Surah, Ayah, Word, Count(Segment) 
                                    	FROM CorpusSegment
                                    	GROUP BY Surah, Ayah, Word
                                    )
                                    SELECT Minimal, Corpus, IsOk, Minimal = Corpus IsSpellingOk,
                                    Segments, count(*) Occurence FROM Words w
                                    LEFT JOIN T t ON (t.Surah = w.Surah AND t.Ayah = w.Ayah AND t.Word = WordNo)
                                    GROUP BY Minimal, Corpus
                                    ORDER BY Segments DESC;
                                    SELECT * FROM CorpusSegment;
                                    SELECT * FROM PartsOfSpeech;
                                    SELECT * FROM Details;
                                    SELECT * FROM Translation";

            var reader = command.ExecuteReader();
            while (reader.Read()) {
                occurenceList.Add(new Occurence() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    WordNo = reader.GetInt32(2),
                    Minimal = reader.GetString(3),
                    Corpus = reader.IsDBNull(4) ? null : reader.GetString(4)
                });
            }
                       
            reader.NextResult();
            while (reader.Read()) {
                okDiffs.Add(new DiffData() {
                    Minimal = reader.GetString(0),
                    Corpus = reader.GetString(1),
                    IsOk = reader.IsDBNull(2) ? false : true,
                    IsSpellingOk = reader.GetBoolean(3),
                    Segments = reader.GetInt32(4),
                    Occurence = reader.GetInt32(5)
                });
            }
            
            reader.NextResult();
            while (reader.Read()) {
                corpusData.Add(new CorpusData() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    Word = reader.GetInt32(2),
                    Segment = reader.GetInt32(3),
                    Content = reader.GetString(4),
                    POS = reader.GetString(5),
                    Detail = reader.IsDBNull(6) ? null : reader.GetString(6),
                    Root = reader.IsDBNull(7) ? null : reader.GetString(7)
                });
            }
            
            reader.NextResult();
            while (reader.Read()) {
                poss.Add(new PartsOfSpeech() {
                    Id = reader.GetInt32(0),
                    Name = reader.IsDBNull(1) ? "" : reader.GetString(1),
                    Tag = reader.GetString(2),
                    Description = reader.GetString(3)
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                details.Add(new Details() {
                    Id = reader.GetInt32(0),
                    Tag = reader.GetString(1),
                    Name = reader.IsDBNull(2) ? "" : reader.GetString(2),
                    Description = reader.GetString(3)
                });
            }

            reader.NextResult();
            while (reader.Read()) {
                translation.Add(new Translation() {
                    Surah = reader.GetInt32(0),
                    Ayah = reader.GetInt32(1),
                    Bangla = reader.GetString(2),
                    English = reader.GetString(3)
                });
            }

            connection.Close();
        }
    }
}
