﻿using HtmlAgilityPack;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    public class WordForm
    {
        public string Word { get; set; }
        public List<WordReference> References { get; set; }
    }
    public class WordReference
    {
        public int Surah { get; set; }
        public int Ayah { get; set; }
        public int WordNo { get; set; }
    }

    public partial class CorpusRoot : UserControl, INotifyPropertyChanged
    {
        string corpusFile = "modified-corpus.txt";

        Root selectedRoot;
        public Root SelectedRoot {
            get { return selectedRoot; }
            set { selectedRoot = value; getForms(); }
        }
        WordForm selectedForm;

        public event PropertyChangedEventHandler PropertyChanged;

        public WordForm SelectedForm {
            get { return selectedForm; }
            set { selectedForm = value; getAyahs(); }
        }

        public ObservableCollection<Root> Roots { get; set; }
        public List<WordForm> Forms { get; set; }
        public List<AyahReference> Ayahs { get; set; }
        
        public CorpusRoot() {
            InitializeComponent();
            getRoots();
            if (AyahView.ayahs is null) AyahView.getAyahs();
            DataContext = this;
        }

        void getRoots() {
            Roots = new ObservableCollection<Root>();
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = @"SELECT RootId, Root, count(*) Number From Words
                                    LEFT JOIN Roots ON Id = RootId
                                    GROUP BY RootId
                                    HAVING RootId IS NOT NULL
                                    ORDER BY Number DESC";
            var reader = command.ExecuteReader();
            while (reader.Read()) {
                Roots.Add(new Root() {
                    Id = reader.GetInt32(0),
                    Arabic = reader.GetString(1),
                    Number = reader.GetInt32(2)
                });
            }
            connection.Close();
        }

        void getForms() {
            Forms = Segment.occurenceList
                .Where(x => x.RootId == SelectedRoot.Id)
                .GroupBy(x => x.Minimal, (w, l) => new WordForm() {
                    Word = w,
                    References = l.Select(x => new WordReference() {
                        Surah = x.Surah,
                        Ayah = x.Ayah,
                        WordNo = x.WordNo
                    }).ToList()
                })
                .OrderByDescending(x => x.References.Count)
                .ToList();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Forms)));
        }

        void getAyahs() {
            Ayahs = AyahView.ayahs.Where(x => SelectedForm.References.Any(y => x.Surah == y.Surah && x.Ayah == y.Ayah)).ToList();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Ayahs)));
        }

        void process() {
            var strings = new ConcurrentBag<string>();
            //modified to account for the segmentation faults
            var lines = File.ReadAllLines("modified-corpus.txt");
            using var writer = new StreamWriter("verbs.txt");

            #region FileOp
            //Parallel.ForEach(lines, line => {
            //    if (!line.Contains("ROOT")) return;

            //    int surah, ayah, wordNo;
            //    var splits = line.Split('\t');
            //    var wordRef = splits[0].Substring(1, splits[0].LastIndexOf(':') - 1);
            //    var refs = wordRef.Split(':');
            //    surah = Convert.ToInt32(refs[0]);
            //    ayah = Convert.ToInt32(refs[1]);
            //    wordNo = Convert.ToInt32(refs[2]);

            //    var word = Segment.occurenceList.First(x => x.Surah == surah && x.Ayah == ayah && x.WordNo == wordNo).Minimal;

            //    foreach (var root in Roots) {
            //        if (!line.Contains("ROOT:" + root.English)) continue;
            //        #region Structure Verbs
            //        if (!splits[2].Equals("V")) continue;
            //        string text = wordRef + '\t' + root.Arabic + '\t';

            //        var desc = splits[3].Split('|');
            //        string detail = "";
            //        foreach (var d in desc) {
            //            if (d.Contains("STEM") || d.Contains("POS") || d.Contains("LEM") || d.Contains("ROOT") || d.Contains("SP")) continue;
            //            detail += d + "|";
            //        }
            //        detail = detail.Substring(0, detail.Length - 1);
            //        /* assumption
            //            1) if there's no PASS, it's Active
            //            2) if there is no MOOD it's Indicative
            //            3) if there's no form/"(" it's either Form I or XIV
            //        */
            //        desc = detail.Split('|');
            //        if (!detail.Contains("PASS")) desc[0] += "|ACT"; // Active
            //        else desc[0] += "|PASS";

            //        if (!detail.Contains("MOOD")) desc[desc.Length - 1] += "|IND"; // Indicative
            //        else desc[desc.Length - 1] = desc[desc.Length - 2] + "|" + desc[desc.Length - 1].Split(':')[1];

            //        if (!detail.Contains("(")) desc[0] += root.Arabic.Length > 3 ? "|XIV" : "|I"; // Form I / XIV
            //        else desc[0] += "|" + desc.First(x => x.Contains("(")).Replace("(", "").Replace(")", "");

            //        detail = desc[0] + "|" + desc[desc.Length - 1];
            //        text += detail;

            //        strings.Add(text);
            //        #endregion
            //        break;
            //    }

            //});
            //writer.Write(string.Join('\n', strings));
            #endregion

            #region DBOp
            //using var connection = new SqliteConnection("data source = quran.db");
            //connection.Open();
            //using var transaction = connection.BeginTransaction();
            //using var command = connection.CreateCommand();
            //command.Transaction = transaction;

            //int id = 1;
            //foreach (var root in Roots) {
            //    command.CommandText = @$"INSERT INTO Roots (Root) VALUES ('{root.Arabic}');
            //                             UPDATE Words SET RootId = {id++} WHERE Root = '{root.Arabic}'";
            //    command.ExecuteNonQuery();
            //}
            //transaction.Commit();
            //connection.Close();
            #endregion
        }

        async void analyze(object sender, RoutedEventArgs e) {
            Stopwatch watch = new();
            watch.Start();
            hint.Text = "processing ...";
            await Task.Run(process);
            hint.Text = "done in " + watch.ElapsedMilliseconds.ToString("N0") + " ms";
        }
    }
}
