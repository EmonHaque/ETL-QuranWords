﻿namespace QuranWords
{
    public class Root
    {
        public int Id { get; set; }
        public string English { get; set; }
        public string Arabic { get; set; }
        public int Number { get; set; }
    }
}
