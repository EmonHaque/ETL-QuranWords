﻿using Microsoft.Data.Sqlite;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Xml;

namespace QuranWords
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public UserControl SelectedView { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;
        public MainWindow() {
            InitializeComponent();
            SelectedView = new Segment();
            DataContext = this;
        }

        void goToSurahView(object sender, RoutedEventArgs e) {
            SelectedView = new SurahView();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedView)));
        }

        void goToEditSegment(object sender, RoutedEventArgs e) {
            SelectedView = new EditSegment();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedView)));
        }

        void goToSegment(object sender, RoutedEventArgs e) {
            SelectedView = new Segment();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedView)));
        }

        void goToMeaning(object sender, RoutedEventArgs e) {
            SelectedView = new AddMeningView();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedView)));
        }

        void goToVerbs(object sender, RoutedEventArgs e) {
            SelectedView = new VerbForms();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedView)));
        }

        void goToAyahView(object sender, RoutedEventArgs e) {
            SelectedView = new AyahView();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedView)));
        }
    }
}
