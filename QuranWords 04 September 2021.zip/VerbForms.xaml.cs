﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    public partial class VerbForms : UserControl
    {
        Grid grid;
        SolidColorBrush brush;
        ColorAnimation anim;

        bool gender;
        public bool Gender {
            get { return gender; }
            set { gender = value; conjugate(); }
        }
        bool? person;
        public bool? Person {
            get { return person; }
            set { person = value; conjugate(); }
        }
        bool? number;
        public bool? Number {
            get { return number; }
            set { number = value; conjugate(); }
        }

        public List<VerbDef> VerbDefs { get; set; }
        public VerbForms() {
            Gender = true;
            Person = Number = true;
            InitializeComponent();
            brush = new SolidColorBrush(Colors.Black);
            getVerbs();
            anim = new ColorAnimation() {
                From = Colors.Red,
                Duration = TimeSpan.FromSeconds(2)
            };
            DataContext = this;
        }

        void getVerbs() {
            VerbDefs = new List<VerbDef>();
            var patterns = new List<VerbPattern>();

            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = @"SELECT * FROM VerbDef;
                                        SELECT * FROM VerbForms";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    VerbDefs.Add(new VerbDef() {
                        Id = reader.GetInt32(0),
                        Arabic = reader.GetString(1),
                        English = reader.GetString(2)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    patterns.Add(new VerbPattern() {
                        PatternNo = reader.GetInt32(0),
                        DefId = reader.GetInt32(1),
                        SubPatternNo = reader.GetInt32(2),
                        Pattern = reader.GetString(3)
                    });
                }
                connection.Close();
            }

            var groups = patterns.GroupBy(x => x.PatternNo, (k, v) => new { No = k, Values = v });
            grid = new Grid() { Margin = new Thickness(10), ShowGridLines = true };

            for (int i = 0; i < 10; i++) {
                grid.RowDefinitions.Add(new RowDefinition());
                grid.ColumnDefinitions.Add(new ColumnDefinition());
            }
            for (int i = 0; i < 10; i++)
                grid.ColumnDefinitions.Add(new ColumnDefinition());

            for (int i = 2; i < 10; i++) {
                var sideHead = new TextBlock() {
                    Inlines = {
                        new Run() {
                            Text = VerbDefs[i - 2].Arabic,
                            Foreground = Brushes.Green,
                            FontSize = 40,
                            FontFamily = new FontFamily("Scheherazade")
                        },
                        new LineBreak(),
                        new Run(){ Text = VerbDefs[i - 2].English, Foreground = Brushes.LightBlue, FontSize = 20 }
                        },
                    Margin = new Thickness(0, 0, 20, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetRow(sideHead, i);
                grid.Children.Add(sideHead);
            }

            var topLeftBlock = new TextBlock() {
                Text = "Forms",
                FontSize = 40,
                Margin = new Thickness(0, 0, 20, 0),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Green,
                FontWeight = FontWeights.Bold
            };
            Grid.SetRowSpan(topLeftBlock, 2);
            grid.Children.Add(topLeftBlock);

            int colIndex = 1;
            foreach (var group in groups) {
                if (group.No == 1 || group.No == 14) {
                    var subGroups = group.Values.GroupBy(x => x.SubPatternNo, (k, v) => new { No = k, Values = v });
                    var headBlock = new TextBlock() {
                        Text = "Form " + group.No,
                        FontSize = 20,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    Grid.SetColumn(headBlock, colIndex);
                    Grid.SetColumnSpan(headBlock, subGroups.Count());
                    grid.Children.Add(headBlock);

                    foreach (var subGroup in subGroups) {
                        var subHeadBlock = new TextBlock() {
                            Text = "Pattern " + subGroup.No,
                            FontSize = 15,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        };
                        Grid.SetColumn(subHeadBlock, colIndex);
                        Grid.SetRow(subHeadBlock, 1);
                        grid.Children.Add(subHeadBlock);

                        int rowIndex = 2;
                        foreach (var pattern in subGroup.Values) {
                            var content = new TextBlock() {
                                Text = pattern.Pattern,
                                FlowDirection = FlowDirection.RightToLeft,
                                FontFamily = new FontFamily("Scheherazade"),
                                FontSize = 50,
                                HorizontalAlignment = HorizontalAlignment.Center,
                                Margin = new Thickness(10, 0, 10, 0)
                            };
                            if(rowIndex > 1 && rowIndex < 6) {
                                content.Foreground = brush;
                                content.Tag = pattern.Pattern.Substring(0, pattern.Pattern.Length - 1);
                            }
                            Grid.SetColumn(content, colIndex);
                            Grid.SetRow(content, rowIndex++);
                            grid.Children.Add(content);
                        }
                        colIndex++;
                    }
                }
                else {
                    var headBlock = new TextBlock() {
                        Text = "Form " + group.No,
                        FontSize = 20,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    Grid.SetColumn(headBlock, colIndex);
                    Grid.SetRowSpan(headBlock, 2);
                    grid.Children.Add(headBlock);

                    int rowIndex = 2;
                    foreach (var pattern in group.Values) {
                        var content = new TextBlock() {
                            Text = pattern.Pattern,
                            FlowDirection = FlowDirection.RightToLeft,
                            FontFamily = new FontFamily("Scheherazade"),
                            FontSize = 50,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            Margin = new Thickness(10, 0, 10, 0)
                        };
                        if (rowIndex > 1 && rowIndex < 6) {
                            content.Foreground = brush;
                            content.Tag = pattern.Pattern.Substring(0, pattern.Pattern.Length - 1);
                        }
                        Grid.SetColumn(content, colIndex);
                        Grid.SetRow(content, rowIndex++);
                        grid.Children.Add(content);
                    }
                    colIndex++;
                }
            }
            scr.Content = grid;

        }

        void conjugate() {
            if (grid is null) return;
            string pastBeginning = "";
            string pastEnding = "";
            string presentBeginning = "";
            string presentEnding = "";
            string x = "";
            if (Gender) {
                //Masculine
                switch (Person) {
                    case true: // third
                        if (Number is null) x = "3MD"; // third person masculine dual
                        else if (Number.Value) x = "3MS"; // singular
                        else x = "3MP"; // plural
                        break;
                    case false: // first
                        if (Number is null) x = "1MD"; // first person masculine dual
                        else if (Number.Value) x = "1MS"; // singular
                        else x = "1MP"; // plural
                        break;
                    default: // second
                        if (Number is null) x = "2MD"; // second person masculine dual
                        else if (Number.Value) x = "2MS"; // singular
                        else x = "2MP"; // plural
                        break;
                }
            }
            else {
                switch (Person) {
                    case true: // third
                        if (Number is null) x = "3FD"; // third person masculine dual
                        else if (Number.Value) x = "3FS"; // singular
                        else x = "3FP"; // plural
                        break;
                    case false: // first
                        if (Number is null) x = "1FD"; // first person masculine dual
                        else if (Number.Value) x = "1FS"; // singular
                        else x = "1FP"; // plural
                        break;
                    default: // second
                        if (Number is null) x = "2FD"; // second person masculine dual
                        else if (Number.Value) x = "2FS"; // singular
                        else x = "2FP"; // plural
                        break;
                }
            }

            switch (x) {
                case "3MS":
                    pastEnding = "َ"; // fatha
                    presentEnding = "ُ"; // damma
                    break;
                case "3FS":
                    pastEnding = "َت"; // fatha
                    presentBeginning = "ت";
                    presentEnding = "ُ"; // damma
                    break;
                case "3MD":
                    pastEnding = "َا"; // fatha
                    presentEnding = "انِ";
                    break;
                case "3FD":
                    pastEnding = "َتا"; // fatha
                    presentBeginning = "ت";
                    presentEnding = "انِ";
                    break;
                case "3MP":
                    pastEnding = "وا";
                    presentEnding = "ونَ";
                    break;
                case "3FP":
                    pastEnding = presentEnding = "نَ";
                    break;
                case "2MS":
                    pastEnding = "تَ";
                    presentBeginning = "ت";
                    presentEnding = "ُ"; // damma
                    break;
                case "2FS":
                    pastEnding = "تِ";
                    presentBeginning = "ت";
                    presentEnding = "ينَ";
                    break;
                case "2MD":
                case "2FD":
                    pastEnding = "تُما";
                    presentBeginning = "ت";
                    presentEnding = "انِ";
                    break;
                case "2MP":
                    pastEnding = "تُم";
                    presentBeginning = "ت";
                    presentEnding = "ونَ";
                    break;
                case "2FP":
                    pastEnding = "تُنَّ";
                    presentBeginning = "ت";
                    presentEnding = "نَ";
                    break;
                case "1MS":
                case "1FS":
                    pastEnding = "تُ";
                    presentBeginning = "ا";
                    presentEnding = "ُ"; // damma
                    break;
                case "1MD":
                case "1FD":
                case "1MP":
                case "1FP":
                    pastEnding = "نا";
                    presentBeginning = "ن";
                    presentEnding = "ُ"; // damma
                    break;
            }

            foreach (UIElement child in grid.Children) {
                if (Grid.GetColumn(child) == 0) continue;
                var row = Grid.GetRow(child);
                if(row == 2 || row == 3) {
                    var block = (TextBlock)child;
                    block.Text = pastBeginning + block.Tag + pastEnding;
                }
                else if(row == 4 || row == 5) {
                    var block = (TextBlock)child;
                    var tag = block.Tag;
                    if (!string.Equals(presentBeginning, ""))
                        tag = tag.ToString().Substring(1, tag.ToString().Length - 1);
                    block.Text = presentBeginning + tag + presentEnding;
                }
            }
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }
    }
}
