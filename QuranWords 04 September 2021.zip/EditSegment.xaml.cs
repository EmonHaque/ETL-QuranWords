﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace QuranWords
{
    public partial class EditSegment : UserControl, INotifyPropertyChanged
    {
        bool isSelectedByUser;
        string posQuery;
        SegmentedWord selectedSegment;
        public SegmentedWord SelectedSegment {
            get { return selectedSegment; }
            set { 
                selectedSegment = value;
                if (selectedSegment != null)
                    posBox.Text = Segment.pos.First(x => x.Id == selectedSegment.POS).ToString();
            }
        }
        CollectionViewSource posSource;
        public ICollectionView POS { get; set; }
        public Surah Surah { get; set; }
        public AyahUnedited Ayah { get; set; }
        public ObservableCollection<SegmentedWord> Segments { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;

        public EditSegment() {
            InitializeComponent();
            Segments = new ObservableCollection<SegmentedWord>();

            posSource = new CollectionViewSource() {
                Source = Segment.pos,
                IsLiveSortingRequested = true,
                LiveSortingProperties = { "Name", "Description" }
            };
            POS = posSource.View;
            POS.Filter = filterPOS;
            POS.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
            POS.SortDescriptions.Add(new SortDescription("Description", ListSortDirection.Ascending));

            DataContext = this;
        }

        void getAyah(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            var parts = ((TextBox)sender).Text.Split(':');
            if (parts.Length < 2) return;

            try {
                Surah = new Surah();
                Ayah = new AyahUnedited();
                Segments.Clear();
                lock (App.Key) {
                    using var connection = new SqliteConnection("data source = quran.db");
                    connection.Open();
                    using var command = connection.CreateCommand();
                    command.CommandText = @"SELECT Surah, Ayah, Minimal, Bangla FROM Ayah WHERE Surah = @Surah AND Ayah = @Ayah;
                                        SELECT WordNo, SegmentNo, Minimal, PartsOfSpeech, Meaning FROM Segments WHERE Surah = @Surah AND Ayah = @Ayah ORDER BY WordNo, SegmentNo;
                                        SELECT No, Arabic, Bangla FROM Surah WHERE No = @Surah";
                    command.Parameters.AddWithValue("@Surah", parts[0]);
                    command.Parameters.AddWithValue("@Ayah", parts[1]);
                    var reader = command.ExecuteReader();
                    reader.Read();

                    Ayah.Surah = reader.GetInt32(0);
                    Ayah.Ayah = reader.GetInt32(1);
                    Ayah.Arabic = reader.GetString(2);
                    Ayah.Bangla = reader.GetString(3);

                    reader.NextResult();
                    while (reader.Read()) {
                        Segments.Add(new SegmentedWord() {
                            WordNo = reader.GetInt32(0),
                            SegmentNo = reader.GetInt32(1),
                            Minimal = reader.GetString(2),
                            POS = reader.GetInt32(3),
                            Meaning = reader.IsDBNull(4) ? "" : reader.GetString(4)
                        });
                    }
                    reader.NextResult();
                    reader.Read();

                    Surah.No = reader.GetInt32(0);
                    Surah.Arabic = reader.GetString(1);
                    Surah.Bangla = reader.GetString(2);

                    connection.Close();
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Ayah)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Surah)));
        }
            catch (Exception) {
                MessageBox.Show("Some error", "Error");
            }
}

        void onWordSelected(object sender, MouseButtonEventArgs e) {
            if (string.IsNullOrWhiteSpace(ayahBox.SelectedText)) return;
            isSelectedByUser = true;

            var wordNo = ayahBox.Text.Substring(0, ayahBox.SelectionStart).Split(' ').Count();
            segmentList.SelectedItems.Clear();

            foreach (SegmentedWord word in segmentList.Items) {
                if (word.WordNo > wordNo) break;
                if (word.WordNo < wordNo) continue;
                if (ayahBox.SelectedText.Contains(word.Minimal))
                    segmentList.SelectedItems.Add(word);
            }
            if (segmentList.SelectedItems.Count > 0)
                segmentList.ScrollIntoView(segmentList.SelectedItems[0]);

            isSelectedByUser = false;
        }

        void onSelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (isSelectedByUser) return;
            if (segmentList.SelectedItems.Count == 0) return;
            var word = (SegmentedWord)segmentList.SelectedItems[0];
            int position = -1;
            if(word.WordNo == 1) {
                position = ayahBox.Text.IndexOf(word.Minimal, position + 1);
            }
            else {
                for (int i = 0; i < word.WordNo - 1; i++) {
                    position = ayahBox.Text.IndexOf(' ', position + 1);
                }
                position = ayahBox.Text.IndexOf(word.Minimal, position);
            }
            if(position == -1) {
                ayahBox.Select(0, 0);
                return;
            }
            ayahBox.Focus();
            ayahBox.Select(position, word.Minimal.Length);
        }

        bool filterPOS(object o) {
            if (string.IsNullOrWhiteSpace(posQuery)) return true;
            return ((PartsOfSpeech)o).Name.ToLower().StartsWith(posQuery);
        }
        void Suggest(object sender, TextChangedEventArgs e) {
            posQuery = posBox.Text;
            if (posBox.Text.Length == 0) {
                POS.Refresh();
                return;
            }
            var indexOfSpace = posBox.Text.IndexOf(' ');
            if(indexOfSpace != -1) {
                var id = posBox.Text.Substring(0, indexOfSpace);
                if (int.TryParse(id, out int x)) return;
            }
            if (!string.IsNullOrWhiteSpace(posQuery)) {
                POS.Refresh();
                suggestionBox.PlacementRectangle = posBox.GetRectFromCharacterIndex(posBox.CaretIndex);
                suggestionBox.IsOpen = true;
            }
            else suggestionBox.IsOpen = false;
        }
        void FocusSuggestion(object sender, KeyEventArgs e) {
            if (e.Key != Key.Down) return;
            if (suggestionBox.IsOpen) {
                suggestionList.SelectedIndex = 0;
                Keyboard.Focus((ListBoxItem)suggestionList.ItemContainerGenerator.ContainerFromItem(suggestionList.SelectedItem));
            }
        }
        void SetPartsOfSpeech(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            posBox.Text = suggestionList.SelectedItem.ToString();
            posBox.CaretIndex = posBox.Text.Length;
            suggestionBox.IsOpen = false;
            Keyboard.Focus(posBox);
        }
        void SetPartsOfSpeechOnClick(object sender, MouseButtonEventArgs e) {
            posBox.Text = suggestionList.SelectedItem.ToString();
            posBox.CaretIndex = posBox.Text.Length;
            suggestionBox.IsOpen = false;
            Keyboard.Focus(posBox);
        }
        void updateSelectedPOS() {
            if (!int.TryParse(posBox.Text.Substring(0, posBox.Text.IndexOf(' ')), out int id)) {
                int newId = Segment.pos.Count == 0 ? 1 : Segment.pos.Max(x => x.Id) + 1;
                id = newId;
                var parts = posBox.Text.Split(" - ");
                var newPOS = new PartsOfSpeech() {
                    Id = newId,
                    Name = parts[0],
                    Description = parts[1]
                };
                Segment.pos.Add(newPOS);
                lock (App.Key) {
                    using var connection = new SqliteConnection("data source = quran.db");
                    connection.Open();
                    using var command = connection.CreateCommand();

                    command.CommandText = $"INSERT INTO PartsOfSpeech VALUES({newPOS.Id}, '{newPOS.Name}', '{newPOS.Description}')";
                    command.ExecuteNonQuery();
                    connection.Close();
                }

            }
            SelectedSegment.POS = id;
        }
        void updateSegment(object sender, RoutedEventArgs e) {
            updateSelectedPOS();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();

                command.CommandText = @$"UPDATE Segments SET PartsOfSpeech = {SelectedSegment.POS}, Meaning = '{SelectedSegment.Meaning}'
                                        WHERE Surah = {Ayah.Surah} AND Ayah = {Ayah.Ayah} AND WordNo = {SelectedSegment.WordNo} AND SegmentNo = {SelectedSegment.SegmentNo}";
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}
