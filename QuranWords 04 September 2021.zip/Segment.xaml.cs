﻿using HtmlAgilityPack;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    public partial class Segment : UserControl
    {
        string[] queryParts;
        string posQuery;
        Occurence lookupOccurence;
        List<Tuple<int, int>> segmentationFaults;
        string query;
        public string Query {
            get { return query; }
            set {
                query = value.Trim();
                if (((ComboBoxItem)filterCombo.SelectedItem).Content.Equals("Starts and Ends with"))
                    queryParts = query.Split(' ');
                MinimalWords.Refresh();
            }
        }
        Word selectedMinimalWord;
        public Word SelectedMinimalWord {
            get { return selectedMinimalWord; }
            set {
                selectedMinimalWord = value;
                getOccurences();
                CleanWords.Refresh();
                FullWords.Refresh();
                cleanBox.SelectedIndex = 0;
                fullBox.SelectedIndex = 0;
            }
        }
        List<Occurence> occurenceList;
        ObservableCollection<Word> minimalWords, cleanWords, fullWords;
        public static ObservableCollection<PartsOfSpeech> pos;
        CollectionViewSource posSource;
        public ICollectionView MinimalWords { get; set; }
        public ICollectionView CleanWords { get; set; }
        public ICollectionView FullWords { get; set; }
        public ICollectionView POS { get; set; }

        public ObservableCollection<Occurence> Occurences { get; set; }

        public Occurence SelectedMinimalOccurence { get; set; }

        public Segment() {
            InitializeComponent();
            getWords();
            getPOS();
            MinimalWords = new CollectionViewSource() { Source = minimalWords }.View;
            CleanWords = new CollectionViewSource() { Source = cleanWords }.View;
            FullWords = new CollectionViewSource() { Source = fullWords }.View;
            MinimalWords.Filter = startWithFilter;
            CleanWords.Filter = filterWords;
            FullWords.Filter = filterWords;
            Occurences = new ObservableCollection<Occurence>();
            //CleanOccurences = new ObservableCollection<Occurence>();
            //FullOccurences = new ObservableCollection<Occurence>();

            segmentationFaults = new List<Tuple<int, int>>();
            var faultyLines = File.ReadAllLines("segmentationFault.txt");
            foreach (var line in faultyLines) {
                var s = line.Split('\t');
                segmentationFaults.Add(new Tuple<int, int>(Convert.ToInt32(s[0]), Convert.ToInt32(s[1])));
            }
            DataContext = this;
        }

        bool filterWords(object o) {
            if (SelectedMinimalWord is null) return false;
            return ((Word)o).Minimal.Equals(SelectedMinimalWord.Original);
        }
        void getPOS() {
            pos = new ObservableCollection<PartsOfSpeech>();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM PartsOfSpeech";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    pos.Add(new PartsOfSpeech() {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Description = reader.GetString(2)
                    });
                }
                connection.Close();
            }
            posSource = new CollectionViewSource() {
                Source = pos,
                IsLiveSortingRequested = true,
                LiveSortingProperties = { "Name", "Description" }
            };
            POS = posSource.View;
            POS.Filter = filterPOS;
            POS.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
            POS.SortDescriptions.Add(new SortDescription("Description", ListSortDirection.Ascending));
        }
        bool filterPOS(object o){
            if (string.IsNullOrWhiteSpace(posQuery)) return true;
            var pos = (PartsOfSpeech)o;
            var str = pos.Name + " - " + pos.Description;
            return str.StartsWith(posQuery);
            //return ((PartsOfSpeech)o).Name.ToLower().StartsWith(posQuery);
        }
        bool startWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.StartsWith(Query);
        }
        bool endWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.EndsWith(Query);
        }
        bool startAndEndWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var word = (Word)o;
            if (queryParts.Length > 1)
                return word.Original.StartsWith(queryParts[0]) && word.Original.EndsWith(queryParts[1]);
            return word.Original.StartsWith(queryParts[0]);
        }
        bool containFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.Contains(Query);
        }
        bool equalFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.Equals(Query);
        }
        bool patternStartWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var word = ((Word)o).Original;
            bool match = word.Length >= Query.Length;
            if (match) {
                for (int i = 0; i < Query.Length; i++) {
                    if (Query[i].Equals('ـ')) continue; // SHIFT + B
                    if (!Query[i].Equals(word[i])) {
                        match = false;
                        break;
                    }
                }
            }
            return match;
        }
        bool patternEqualsFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var word = ((Word)o).Original;
            bool match = word.Length == Query.Length;
            if (match) {
                for (int i = 0; i < Query.Length; i++) {
                    if (Query[i].Equals('ـ')) continue; // SHIFT + B
                    if (!Query[i].Equals(word[i])) {
                        match = false;
                        break;
                    }
                }
            }
            return match;
        }
        void getWords() {
            if(minimalWords == null) {
                minimalWords = new ObservableCollection<Word>();
                cleanWords = new ObservableCollection<Word>();
                fullWords = new ObservableCollection<Word>();
                occurenceList = new List<Occurence>();
            }
            else {
                minimalWords.Clear();
                cleanWords.Clear();
                fullWords.Clear();
                occurenceList.Clear();
            }
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = @"SELECT Minimal, Count(*) Number FROM Words WHERE IsSegregated ISNULL GROUP BY Minimal ORDER BY Number DESC;
                                        SELECT Minimal, Clean, COUNT(*) Number FROM Words WHERE IsSegregated ISNULL GROUP BY Minimal ORDER BY Number DESC;
                                        SELECT Minimal, Full, COUNT(*) Number FROM Words WHERE IsSegregated ISNULL GROUP BY Minimal, Full ORDER BY Number DESC;
                                        SELECT * FROM Words WHERE IsSegregated ISNULL";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    minimalWords.Add(new Word() {
                        Original = reader.GetString(0),
                        Edited = reader.GetString(0),
                        Occurence = reader.GetInt32(1)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    cleanWords.Add(new Word() {
                        Minimal = reader.GetString(0),
                        Original = reader.GetString(1),
                        Edited = reader.GetString(1),
                        Occurence = reader.GetInt32(2)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    fullWords.Add(new Word() {
                        Minimal = reader.GetString(0),
                        Original = reader.GetString(1),
                        Edited = reader.GetString(1),
                        Occurence = reader.GetInt32(2)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    occurenceList.Add(new Occurence() {
                        Surah = reader.GetInt32(0),
                        Ayah = reader.GetInt32(1),
                        WordNo = reader.GetInt32(2),
                        Clean = reader.GetString(3),
                        Minimal = reader.GetString(4),
                        Full = reader.GetString(5)
                    });
                }
                connection.Close();
            }
        }
        void getOccurences() {
            Occurences.Clear();
            if (SelectedMinimalWord is null) return;
            for (int i = 0; i < occurenceList.Count; i++) {
                if (occurenceList[i].Minimal.Equals(SelectedMinimalWord.Original))
                    Occurences.Add(occurenceList[i]);
            }
        }
        void SetFilter(object sender, SelectionChangedEventArgs e) {
            if (MinimalWords is null) return;
            var content = ((ComboBoxItem)e.AddedItems[0]).Content;
            switch (content) {
                case "Starts with": MinimalWords.Filter = startWithFilter; break;
                case "Ends with": MinimalWords.Filter = endWithFilter; break;
                case "Starts and Ends with":
                    if (Query is not null) queryParts = Query.Split(' ');
                    MinimalWords.Filter = startAndEndWithFilter;
                    break;
                case "Contains": MinimalWords.Filter = containFilter; break;
                case "Equals": MinimalWords.Filter = equalFilter; break;
                case "Pattern starts with": MinimalWords.Filter = patternStartWithFilter; break;
                case "Pattern equals": MinimalWords.Filter = patternEqualsFilter; break;
            }
        }
        void Sort(object sender, RoutedEventArgs e) {
            var button = (Button)sender;
            MinimalWords.SortDescriptions.Clear();
            if (button.Content.ToString().Contains("DESC")) {
                button.Content = "Sort ASC";
                MinimalWords.SortDescriptions.Add(new SortDescription("Occurence", ListSortDirection.Ascending));
            }
            else {
                button.Content = "Sort DESC";
                MinimalWords.SortDescriptions.Add(new SortDescription("Occurence", ListSortDirection.Descending));
            }
        }
        void Suggest(object sender, TextChangedEventArgs e) {
            posQuery = posBox.Text.Split("\r\n").Last().ToLower();
            if (!string.IsNullOrWhiteSpace(posQuery)) {
                POS.Refresh();
                suggestionBox.PlacementRectangle = posBox.GetRectFromCharacterIndex(posBox.CaretIndex);
                suggestionBox.IsOpen = true;
            }
            else suggestionBox.IsOpen = false;
        }
        void FocusSuggestion(object sender, KeyEventArgs e) {
            if (e.Key != Key.Down) return;
            if (suggestionBox.IsOpen) {
                suggestionList.SelectedIndex = 0;
                Keyboard.Focus((ListBoxItem)suggestionList.ItemContainerGenerator.ContainerFromItem(suggestionList.SelectedItem));
            }
        }
        void SetPartsOfSpeech(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            if (posBox.Text.Contains("\r\n")) {
                posBox.Text = posBox.Text.Remove(posBox.Text.LastIndexOf("\r\n") + 2);
                posBox.Text += suggestionList.SelectedItem.ToString();
            }
            else posBox.Text = suggestionList.SelectedItem.ToString();
            posBox.CaretIndex = posBox.Text.Length;
            suggestionBox.IsOpen = false;
            Keyboard.Focus(posBox);
        }
        void SetPartsOfSpeechOnClick(object sender, MouseButtonEventArgs e) {
            if (posBox.Text.Contains("\r\n")) {
                posBox.Text = posBox.Text.Remove(posBox.Text.LastIndexOf("\r\n") + 2);
                posBox.Text += suggestionList.SelectedItem.ToString();
            }
            else posBox.Text = suggestionList.SelectedItem.ToString();
            posBox.CaretIndex = posBox.Text.Length;
            suggestionBox.IsOpen = false;
            Keyboard.Focus(posBox);
        }
        void Update(object sender, RoutedEventArgs e) {
            try {
                foreach (var item in Occurences) {
                    item.Clean = cleanWords.First(x => x.Minimal.Equals(item.Minimal)).Edited;
                    item.Minimal = SelectedMinimalWord.Edited;
                    item.Full = fullWords.First(x => x.Original.Equals(item.Full)).Edited;
                }
                string pText = posBox.Text;
                bool hasNewPOS = false;
                var partsOfSpeech = posBox.Text.Split("\r\n");
                var posIDs = new List<int>();

                lock (App.Key) {
                    using var connection = new SqliteConnection("data source = quran.db");
                    connection.Open();
                    using var transaction = connection.BeginTransaction();
                    using var command = connection.CreateCommand();
                    command.Transaction = transaction;

                    foreach (var segment in partsOfSpeech) {
                        if (int.TryParse(segment.Substring(0, segment.IndexOf(' ')), out int id))
                            posIDs.Add(id);
                        else {
                            int newId = pos.Count == 0 ? 1 : pos.Max(x => x.Id) + 1;
                            var parts = segment.Split(" - ");
                            var newPOS = new PartsOfSpeech() {
                                Id = newId,
                                Name = parts[0],
                                Description = parts[1]
                            };
                            posIDs.Add(newId);
                            pos.Add(newPOS);
                            command.CommandText = $"INSERT INTO PartsOfSpeech VALUES({newPOS.Id}, '{newPOS.Name}', '{newPOS.Description}')";
                            command.ExecuteNonQuery();
                            hasNewPOS = true;
                            pText = pText.Replace(segment, $"{newPOS.Id} {newPOS.Name} - {newPOS.Description}");
                        }
                    }
                    if (hasNewPOS) posBox.Text = pText;

                    foreach (var word in Occurences) {
                        var minParts = word.Minimal.Split(' ');
                        var cleanParts = word.Clean.Split(' ');
                        var fullParts = word.Full.Split(' ');
                        var segmentNo = 1;
                        for (int i = 0; i < minParts.Length; i++) {
                            command.CommandText = $"INSERT INTO Segments VALUES({word.Surah}, {word.Ayah}, {word.WordNo}, {segmentNo++}, '{cleanParts[i]}', '{minParts[i]}', '{fullParts[i]}', {posIDs[i]}, null, null)";
                            command.ExecuteNonQuery();
                        }
                    }
                    command.CommandText = $"UPDATE Words Set IsSegregated = 1 WHERE Minimal = '{SelectedMinimalWord.Original}'";
                    command.ExecuteNonQuery();
                    transaction.Commit();
                    connection.Close();
                }
                minimalWords.Remove(SelectedMinimalWord);
            }
            catch (Exception) {
                MessageBox.Show("Some Error", "Error");
            }
        }
        void UpdateBulk(object sender, RoutedEventArgs e) {            
            try {
                string pText = posBox.Text;
                bool hasNewPOS = false;
                var partsOfSpeech = posBox.Text.Split("\r\n");
                var posIDs = new List<int>();
                List<Word> removeList = new();
                lock (App.Key) {
                    using var connection = new SqliteConnection("data source = quran.db");
                    connection.Open();
                    using var transaction = connection.BeginTransaction();
                    using var command = connection.CreateCommand();
                    command.Transaction = transaction;

                    foreach (var segment in partsOfSpeech) {
                        if (int.TryParse(segment.Substring(0, segment.IndexOf(' ')), out int id))
                            posIDs.Add(id);
                        else {
                            int newId = pos.Count == 0 ? 1 : pos.Max(x => x.Id) + 1;
                            var parts = segment.Split(" - ");
                            var newPOS = new PartsOfSpeech() {
                                Id = newId,
                                Name = parts[0],
                                Description = parts[1]
                            };
                            posIDs.Add(newId);
                            pos.Add(newPOS);
                            command.CommandText = $"INSERT INTO PartsOfSpeech VALUES({newPOS.Id}, '{newPOS.Name}', '{newPOS.Description}')";
                            command.ExecuteNonQuery();
                            hasNewPOS = true;
                            pText = pText.Replace(segment, $"{newPOS.Id} {newPOS.Name} - {newPOS.Description}");
                        }
                    }
                    if (hasNewPOS) posBox.Text = pText;

                    if ((bool)autoCheck.IsChecked) {
                        int wordCount = 1;
                        foreach (Word w in minimalBox.Items) {
                            if (!w.IsChecked) continue;
                            removeList.Add(w);
                            Debug.WriteLine(wordCount++);
                            var occurences = occurenceList.Where(x => x.Minimal.Equals(w.Original)).ToList();
                            foreach (var word in occurences) {
                                var minParts = new string[2];
                                var cleanParts = new string[2];
                                var fullParts = new string[2];
                                var cleanWord = cleanWords.First(x => x.Minimal.Equals(word.Minimal)).Edited;
                                var fullWord = fullWords.First(x => x.Original.Equals(word.Full)).Edited;
                                //manually split
                                minParts[0] = cleanParts[0] = "ال";
                                minParts[1] = w.Edited.Substring(2, w.Edited.Length - 2);
                                cleanParts[1] = cleanWord.Substring(2, cleanWord.Length - 2);

                                if (fullWord.Contains("الْ")) {
                                    fullParts[0] = "الْ";
                                    fullParts[1] = fullWord.Substring(3, fullWord.Length - 3);
                                }
                                else {
                                    fullParts[0] = "ال";
                                    fullParts[1] = fullWord.Substring(2, fullWord.Length - 2);
                                }
                                var segmentNo = 1;
                                for (int i = 0; i < minParts.Length; i++) {
                                    command.CommandText = $"INSERT INTO Segments VALUES({word.Surah}, {word.Ayah}, {word.WordNo}, {segmentNo++}, '{cleanParts[i]}', '{minParts[i]}', '{fullParts[i]}', {posIDs[i]}, null, null)";
                                    command.ExecuteNonQuery();
                                }
                                command.CommandText = $"UPDATE Words Set IsSegregated = 1 WHERE Minimal = '{w.Original}'";
                                command.ExecuteNonQuery();
                            }
                        }
                    }
                    else {
                        foreach (Word w in minimalBox.Items) {
                            if (!w.IsChecked) continue;
                            removeList.Add(w);
                            var occurences = occurenceList.Where(x => x.Minimal.Equals(w.Original)).ToList();
                            foreach (var word in occurences) {
                                var minParts = w.Edited.Split(' ');
                                var cleanParts = cleanWords.First(x => x.Minimal.Equals(word.Minimal)).Edited.Split(' ');
                                var fullParts = fullWords.First(x => x.Original.Equals(word.Full)).Edited.Split(' ');
                                var segmentNo = 1;
                                for (int i = 0; i < minParts.Length; i++) {
                                    command.CommandText = $"INSERT INTO Segments VALUES({word.Surah}, {word.Ayah}, {word.WordNo}, {segmentNo++}, '{cleanParts[i]}', '{minParts[i]}', '{fullParts[i]}', {posIDs[i]}, null, null)";
                                    command.ExecuteNonQuery();
                                }
                                command.CommandText = $"UPDATE Words Set IsSegregated = 1 WHERE Minimal = '{w.Original}'";
                                command.ExecuteNonQuery();
                            }
                        }
                    }
                    transaction.Commit();
                    connection.Close();
                }
                foreach (var item in removeList) {
                    minimalWords.Remove(item);
                }
            }
            catch (Exception) {

                MessageBox.Show("Some Error", "Error");
            }
        }
        void UpdatePartial(object sender, RoutedEventArgs e) {
            try {
                foreach (var item in Occurences) {
                    if (!item.IsChecked) continue;
                    item.Clean = cleanWords.First(x => x.Minimal.Equals(item.Minimal)).Edited;
                    item.Minimal = SelectedMinimalWord.Edited;
                    item.Full = fullWords.First(x => x.Original.Equals(item.Full)).Edited;
                }
                string pText = posBox.Text;
                bool hasNewPOS = false;
                var partsOfSpeech = posBox.Text.Split("\r\n");
                var posIDs = new List<int>();

                lock (App.Key) {
                    using var connection = new SqliteConnection("data source = quran.db");
                    connection.Open();
                    using var transaction = connection.BeginTransaction();
                    using var command = connection.CreateCommand();
                    command.Transaction = transaction;

                    foreach (var segment in partsOfSpeech) {
                        if (int.TryParse(segment.Substring(0, segment.IndexOf(' ')), out int id))
                            posIDs.Add(id);
                        else {
                            int newId = pos.Count == 0 ? 1 : pos.Max(x => x.Id) + 1;
                            var parts = segment.Split(" - ");
                            var newPOS = new PartsOfSpeech() {
                                Id = newId,
                                Name = parts[0],
                                Description = parts[1]
                            };
                            posIDs.Add(newId);
                            pos.Add(newPOS);
                            command.CommandText = $"INSERT INTO PartsOfSpeech VALUES({newPOS.Id}, '{newPOS.Name}', '{newPOS.Description}')";
                            command.ExecuteNonQuery();
                            hasNewPOS = true;
                            pText = pText.Replace(segment, $"{newPOS.Id} {newPOS.Name} - {newPOS.Description}");
                        }
                    }
                    if (hasNewPOS) posBox.Text = pText;

                    foreach (var word in Occurences) {
                        if (!word.IsChecked) continue;
                        var minParts = word.Minimal.Split(' ');
                        var cleanParts = word.Clean.Split(' ');
                        var fullParts = word.Full.Split(' ');
                        var segmentNo = 1;
                        for (int i = 0; i < minParts.Length; i++) {
                            command.CommandText = $"INSERT INTO Segments VALUES({word.Surah}, {word.Ayah}, {word.WordNo}, {segmentNo++}, '{cleanParts[i]}', '{minParts[i]}', '{fullParts[i]}', {posIDs[i]}, null, null)";
                            command.ExecuteNonQuery();
                        }
                        command.CommandText = $"UPDATE Words Set IsSegregated = 1 WHERE Surah = {word.Surah} AND Ayah = {word.Ayah} AND WordNo = {word.WordNo}";
                        command.ExecuteNonQuery();
                    }
                   
                    transaction.Commit();
                    connection.Close();

                    var selected = SelectedMinimalWord;
                    getWords();
                    var s = minimalWords.FirstOrDefault(x => x.Original.Equals(selected.Original));
                    if(s != null) {
                        s.Edited = selected.Edited;
                        minimalBox.SelectedItem = s;
                    }
                }
            }
            catch (Exception) {
                MessageBox.Show("Some Error", "Error");
            }
        }

        async void onCorpusOpened(object sender, EventArgs e) {
            var url = $"https://corpus.quran.com/wordbyword.jsp?chapter={lookupOccurence.Surah}&verse={lookupOccurence.Ayah}";
            var html = new HtmlWeb();
            HtmlDocument doc = null;
            try { doc = html.Load(url); }
            catch (Exception) {
                popCorpus.IsOpen = false;
                MessageBox.Show("Some network error", "Error");
                return;
            }

            var table = doc.DocumentNode.SelectSingleNode("//table[@class='morphologyTable']");
            var rows = table.SelectNodes(".//tr");
            table.RemoveChildren(rows);
            table.AppendChild(rows.First(x => x.HasClass("head")));
            rows.RemoveAt(0);

            popCorpus.Height = 250;
            bool hasSegmentationFault = false;
            foreach (var fault in segmentationFaults) {
                if (lookupOccurence.Surah == fault.Item1 && lookupOccurence.Ayah == fault.Item2) {
                    hasSegmentationFault = true;
                    popCorpus.Height = 500;
                    break;
                }
            }
            string refPattern = "";
            if (hasSegmentationFault) refPattern = lookupOccurence.Surah + ":" + lookupOccurence.Ayah + ":";
            else refPattern = lookupOccurence.Surah + ":" + lookupOccurence.Ayah + ":" + lookupOccurence.WordNo + ")";

            foreach (var row in rows) {
                var segment = row.SelectSingleNode(".//span[@class='location']").InnerText.Remove(0, 1);
                if (segment.StartsWith(refPattern)) {
                    var image = row.SelectSingleNode(".//td[@class='ic']/a/img");
                    var id = image.Attributes["src"].Value;
                    image.Attributes["src"].Value = "https://corpus.quran.com/" + id;
                    table.AppendChild(row);
                }
            }

            await web.EnsureCoreWebView2Async();
            web.CoreWebView2.NavigateToString(table.OuterHtml);
        }
        void showCorpus(object sender, MouseButtonEventArgs e) {
            if (popCorpus.IsOpen) popCorpus.IsOpen = false;
            if (minimalBox.SelectedItem is null) return;
            var word = (Word)minimalBox.SelectedItem;
            lookupOccurence = Occurences.First(x => x.Minimal.Equals(word.Original));
            popCorpus.IsOpen = true;
        }
        void onMinimalOccurenceRightClick(object sender, MouseButtonEventArgs e) {
            if (popCorpus.IsOpen) popCorpus.IsOpen = false;
            if (SelectedMinimalOccurence is null) return;
            lookupOccurence = SelectedMinimalOccurence;
            popCorpus.IsOpen = true;
        }
        void closeCorpus(object sender, MouseButtonEventArgs e) {
            if (popCorpus.IsOpen)
                popCorpus.IsOpen = false;
        }
    }
}
