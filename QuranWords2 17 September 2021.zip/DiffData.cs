﻿namespace QuranWords2
{
    public class DiffData
    {
        public int Count { get; set; }
        public string Minimal { get; set; }
        public string Corpus { get; set; }
        public bool IsOk { get; set; }
    }
}
