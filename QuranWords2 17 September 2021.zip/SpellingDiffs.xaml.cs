﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords2
{
    public partial class SpellingDiffs : UserControl
    {
        List<Occurence> occurenceList;
        List<CorpusData> data;
        DiffData selectedDiff;
        public DiffData SelectedDiff {
            get { return selectedDiff; }
            set { selectedDiff = value; getCurrent(); }
        }

        public ObservableCollection<DiffData> Diffs { get; set; }
        public ObservableCollection<CorpusData> CurrentData { get; set; }

        public SpellingDiffs() {
            InitializeComponent();
            getData();
            CurrentData = new ObservableCollection<CorpusData>();
            DataContext = this;
        }

        void getData() {
            Diffs = new ObservableCollection<DiffData>();
            data = new List<CorpusData>();
            occurenceList = new List<Occurence>();

            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = @"SELECT * FROM Words;
                                        SELECT Minimal, Corpus, count(*) Number, IsOk FROM Words
                                        WHERE Minimal <> Corpus AND IsOk IS NULL
                                        GROUP BY Minimal, Corpus;
                                        SELECT * FROM CorpusSegment";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    occurenceList.Add(new Occurence() {
                        Surah = reader.GetInt32(0),
                        Ayah = reader.GetInt32(1),
                        WordNo = reader.GetInt32(2),
                        Minimal = reader.GetString(3)
                    });
                }

                reader.NextResult();
                while (reader.Read()) {
                    Diffs.Add(new DiffData() {
                        Minimal = reader.GetString(0),
                        Corpus = reader.GetString(1),
                        Count = reader.GetInt32(2),
                        IsOk = reader.IsDBNull(3) ? false : true
                    });
                }

                reader.NextResult();
                while (reader.Read()) {
                    data.Add(new CorpusData() {
                        Surah = reader.GetInt32(0),
                        Ayah = reader.GetInt32(1),
                        Word = reader.GetInt32(2),
                        Segment = reader.GetInt32(3),
                        Content = reader.GetString(4),
                        POS = reader.GetString(5),
                        Detail = reader.IsDBNull(6) ? null : reader.GetString(6),
                        Root = reader.IsDBNull(7) ? null : reader.GetString(7)
                    });
                }
                connection.Close();
            }
        }

        void getCurrent() {
            CurrentData.Clear();
            var o = occurenceList.First(x => x.Minimal.Equals(SelectedDiff.Minimal));
            var first = data.Where(x => x.Surah == o.Surah && x.Ayah == o.Ayah && x.Word == o.WordNo);
            foreach (var d in first) {
                CurrentData.Add(d);
            }
        }
    }
}
