﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace QuranWords2
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static object Key;
        protected override void OnStartup(StartupEventArgs e) {
            Key = new object();
            base.OnStartup(e);
        }
    }
}
