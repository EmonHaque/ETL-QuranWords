﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    public partial class Segment : UserControl
    {
        string[] queryParts;
        string posQuery;
        string query;
        public string Query {
            get { return query; }
            set { 
                query = value?.Trim();
                if (((ComboBoxItem)filterCombo.SelectedItem).Content.Equals("Starts and Ends with"))
                    queryParts = query.Split(' ');
                CleanWords.Refresh(); 
            }
        }
        Word selectedCleanWord;
        public Word SelectedCleanWord {
            get { return selectedCleanWord; }
            set { selectedCleanWord = value; getWordList(); }
        }
        Word selectedMinimalWord;
        public Word SelectedMinimalWord {
            get { return selectedMinimalWord; }
            set { selectedMinimalWord = value; getMinimalOccurences(); }
        }
        Word selectedFullWord;
        public Word SelectedFullWord {
            get { return selectedFullWord; }
            set { selectedFullWord = value; getFullOccurences(); }
        }

        ObservableCollection<Word> cleanWords;
        ObservableCollection<PartsOfSpeech> pos;
        CollectionViewSource posSource;
        public ICollectionView CleanWords { get; set; }
        public ICollectionView POS { get; set; }
        public ObservableCollection<Word> MinimalWords { get; set; }
        public ObservableCollection<Word> FullWords { get; set; }
        public ObservableCollection<Occurence> Occurences { get; set; }
        public ObservableCollection<Occurence> MinimalOccurences { get; set; }
        public ObservableCollection<Occurence> FullOccurences { get; set; }

        public Segment() {
            InitializeComponent();
            getWords();
            getPOS();
            CleanWords = new CollectionViewSource() { Source = cleanWords }.View;
            CleanWords.Filter = startWithFilter;
            MinimalWords = new ObservableCollection<Word>();
            FullWords = new ObservableCollection<Word>();
            Occurences = new ObservableCollection<Occurence>();
            MinimalOccurences = new ObservableCollection<Occurence>();
            FullOccurences = new ObservableCollection<Occurence>();
            DataContext = this;
        }

        void getPOS() {
            pos = new ObservableCollection<PartsOfSpeech>();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM PartsOfSpeech";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    pos.Add(new PartsOfSpeech() {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Description = reader.GetString(2)
                    });
                }
                connection.Close();
            }
            posSource = new CollectionViewSource() { 
                Source = pos,
                IsLiveSortingRequested = true,
                LiveSortingProperties = { "Name", "Description" }
            };
            POS = posSource.View;
            POS.Filter = filterPOS;
            POS.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
            POS.SortDescriptions.Add(new SortDescription("Description", ListSortDirection.Ascending));
        }
        bool filterPOS(object o) {
            if (string.IsNullOrWhiteSpace(posQuery)) return true;
            return ((PartsOfSpeech)o).Name.ToLower().StartsWith(posQuery);
        }
        bool startWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.StartsWith(Query);
        }
        bool endWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.EndsWith(Query);
        }
        bool startAndEndWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var word = (Word)o;
            if (queryParts.Length > 1)
                return word.Original.StartsWith(queryParts[0]) && word.Original.EndsWith(queryParts[1]);
             return word.Original.StartsWith(queryParts[0]);
        }
        bool containFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.Contains(Query);
        }
        bool equalFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((Word)o).Original.Equals(Query);
        }
        void getWords() {
            cleanWords = new ObservableCollection<Word>();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT Clean, Count(*) Number FROM Words WHERE IsSegregated ISNULL GROUP BY Clean ORDER BY Number DESC";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    cleanWords.Add(new Word() {
                        Original = reader.GetString(0),
                        Edited = reader.GetString(0),
                        Occurence = reader.GetInt32(1)
                    });
                }
                connection.Close();
            }
        }
        void getWordList() {
            MinimalWords.Clear();
            FullWords.Clear();
            Occurences.Clear();
            if (SelectedCleanWord is null) return;
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = @"SELECT Minimal, COUNT(*) Number FROM Words WHERE Clean = @Word GROUP BY Minimal;
                                        SELECT Full, COUNT(*) Number FROM Words WHERE Clean = @Word GROUP BY Full;
                                        SELECT * FROM Words WHERE Clean = @Word";
                command.Parameters.AddWithValue("@Word", SelectedCleanWord.Original);
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    MinimalWords.Add(new Word() {
                        Original = reader.GetString(0),
                        Edited = reader.GetString(0),
                        Occurence = reader.GetInt32(1)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    FullWords.Add(new Word() {
                        Original = reader.GetString(0),
                        Edited = reader.GetString(0),
                        Occurence = reader.GetInt32(1)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    Occurences.Add(new Occurence() {
                        Surah = reader.GetInt32(0),
                        Ayah = reader.GetInt32(1),
                        WordNo = reader.GetInt32(2),
                        Clean = reader.GetString(3),
                        Minimal = reader.GetString(4),
                        Full = reader.GetString(5)
                    });
                }
                connection.Close();
            }
        }
        void getMinimalOccurences() {
            MinimalOccurences.Clear();
            if (SelectedMinimalWord is null) return;
            foreach (var word in Occurences) {
                if (word.Minimal.Equals(SelectedMinimalWord.Original))
                    MinimalOccurences.Add(word);
            }
        }
        void getFullOccurences() {
            FullOccurences.Clear();
            if (SelectedFullWord is null) return;
            foreach (var word in Occurences) {
                if (word.Full.Equals(SelectedFullWord.Original))
                    FullOccurences.Add(word);
            }
        }       
        void SetFilter(object sender, SelectionChangedEventArgs e) {
            if (CleanWords is null) return;
            var content = ((ComboBoxItem)e.AddedItems[0]).Content;
            switch (content) {
                case "Starts with": CleanWords.Filter = startWithFilter; break;
                case "Ends with": CleanWords.Filter = endWithFilter; break;
                case "Starts and Ends with":
                    if (Query is not null) queryParts = Query.Split(' ');
                    CleanWords.Filter = startAndEndWithFilter; 
                    break;
                case "Contains": CleanWords.Filter = containFilter; break;
                case "Equals": CleanWords.Filter = equalFilter; break;
            }
        }
        void Sort(object sender, RoutedEventArgs e) {
            var button = (Button)sender;
            CleanWords.SortDescriptions.Clear();
            if (button.Content.ToString().Contains("DESC")) {
                button.Content = "Sort ASC";
                CleanWords.SortDescriptions.Add(new SortDescription("Occurence", ListSortDirection.Ascending));
            }
            else {
                button.Content = "Sort DESC";
                CleanWords.SortDescriptions.Add(new SortDescription("Occurence", ListSortDirection.Descending));
            }
        }
        void Suggest(object sender, TextChangedEventArgs e) {
            posQuery = posBox.Text.Split("\r\n").Last().ToLower();
            if (!string.IsNullOrWhiteSpace(posQuery)) {
                POS.Refresh();
                suggestionBox.PlacementRectangle = posBox.GetRectFromCharacterIndex(posBox.CaretIndex);
                suggestionBox.IsOpen = true;
            }
            else suggestionBox.IsOpen = false;
        }
        void FocusSuggestion(object sender, KeyEventArgs e) {
            if (e.Key != Key.Down) return;
            if (suggestionBox.IsOpen) {
                suggestionList.SelectedIndex = 0;
                Keyboard.Focus((ListBoxItem)suggestionList.ItemContainerGenerator.ContainerFromItem(suggestionList.SelectedItem));
            }
        }
        void SetPartsOfSpeech(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            if (posBox.Text.Contains("\r\n")) {
                posBox.Text = posBox.Text.Remove(posBox.Text.LastIndexOf("\r\n") + 2);
                posBox.Text += suggestionList.SelectedItem.ToString();
            }
            else posBox.Text = suggestionList.SelectedItem.ToString();
            posBox.CaretIndex = posBox.Text.Length;
            suggestionBox.IsOpen = false;
            Keyboard.Focus(posBox);
        }
        void SetPartsOfSpeechOnClick(object sender, MouseButtonEventArgs e) {
            if (posBox.Text.Contains("\r\n")) {
                posBox.Text = posBox.Text.Remove(posBox.Text.LastIndexOf("\r\n") + 2);
                posBox.Text += suggestionList.SelectedItem.ToString();
            }
            else posBox.Text = suggestionList.SelectedItem.ToString();
            posBox.CaretIndex = posBox.Text.Length;
            suggestionBox.IsOpen = false;
            Keyboard.Focus(posBox);
        }
        void Update(object sender, RoutedEventArgs e) {
            try {
                foreach (var item in Occurences) {
                    item.Clean = SelectedCleanWord.Edited;
                    item.Minimal = MinimalWords.First(x => x.Original.Equals(item.Minimal)).Edited;
                    item.Full = FullWords.First(x => x.Original.Equals(item.Full)).Edited;
                }
                var partsOfSpeech = posBox.Text.Split("\r\n");
                var posIDs = new List<int>();

                lock (App.Key) {
                    using var connection = new SqliteConnection("data source = quran.db");
                    connection.Open();
                    using var transaction = connection.BeginTransaction();
                    using var command = connection.CreateCommand();

                    foreach (var segment in partsOfSpeech) {
                        if (int.TryParse(segment.Substring(0, segment.IndexOf(' ')), out int id))
                            posIDs.Add(id);
                        else {
                            int newId = pos.Count == 0 ? 1 : pos.Max(x => x.Id) + 1;
                            var parts = segment.Split(" - ");
                            var newPOS = new PartsOfSpeech() {
                                Id = newId,
                                Name = parts[0],
                                Description = parts[1]
                            };
                            posIDs.Add(newId);
                            pos.Add(newPOS);
                            command.CommandText = $"INSERT INTO PartsOfSpeech VALUES({newPOS.Id}, '{newPOS.Name}', '{newPOS.Description}')";
                            command.ExecuteNonQuery();
                        }
                    }

                    foreach (var word in Occurences) {
                        var cleanParts = word.Clean.Split(' ');
                        var minParts = word.Minimal.Split(' ');
                        var fullParts = word.Full.Split(' ');
                        var segmentNo = 1;
                        for (int i = 0; i < cleanParts.Length; i++) {
                            command.CommandText = $"INSERT INTO Segments VALUES({word.Surah}, {word.Ayah}, {word.WordNo}, {segmentNo++}, '{cleanParts[i]}', '{minParts[i]}', '{fullParts[i]}', {posIDs[i]}, null, null)";
                            command.ExecuteNonQuery();
                        }
                    }
                    command.CommandText = $"UPDATE Words Set IsSegregated = 1 WHERE Clean = '{SelectedCleanWord.Original}'";
                    command.ExecuteNonQuery();
                    transaction.Commit();
                    connection.Close();
                }
                cleanWords.Remove(SelectedCleanWord);
            }
            catch (Exception) {
                MessageBox.Show("Some Error", "Error");
            }
        }
    }
}
