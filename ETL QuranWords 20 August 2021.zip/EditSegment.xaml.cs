﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    /// <summary>
    /// Interaction logic for EditSegment.xaml
    /// </summary>
    public partial class EditSegment : UserControl, INotifyPropertyChanged
    {
        public Surah Surah { get; set; }
        public AyahUnedited Ayah { get; set; }
        public ObservableCollection<SegmentedWord> Segments { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;

        public EditSegment() {
            InitializeComponent();
            Segments = new ObservableCollection<SegmentedWord>();
            DataContext = this;
        }

        void getAyah(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            var parts = ((TextBox)sender).Text.Split(':');
            if (parts.Length < 2) return;

            try {
                Surah = new Surah();
                Ayah = new AyahUnedited();
                Segments.Clear();
                lock (App.Key) {
                    using var connection = new SqliteConnection("data source = quran.db");
                    connection.Open();
                    using var command = connection.CreateCommand();
                    command.CommandText = @"SELECT Surah, Ayah, Minimal, Bangla FROM Ayah WHERE Surah = @Surah AND Ayah = @Ayah;
                                        SELECT WordNo, SegmentNo, Minimal, PartsOfSpeech, Meaning FROM Segments WHERE Surah = @Surah AND Ayah = @Ayah;
                                        SELECT No, Arabic, Bangla FROM Surah WHERE No = 1";
                    command.Parameters.AddWithValue("@Surah", parts[0]);
                    command.Parameters.AddWithValue("@Ayah", parts[1]);
                    var reader = command.ExecuteReader();
                    reader.Read();

                    Ayah.Surah = reader.GetInt32(0);
                    Ayah.Ayah = reader.GetInt32(1);
                    Ayah.Arabic = reader.GetString(2);
                    Ayah.Bangla = reader.GetString(3);

                    reader.NextResult();
                    while (reader.Read()) {
                        Segments.Add(new SegmentedWord() {
                            WordNo = reader.GetInt32(0),
                            SegmentNo = reader.GetInt32(1),
                            Minimal = reader.GetString(2),
                            POS = reader.GetInt32(3),
                            Meaning = reader.IsDBNull(4) ? "" : reader.GetString(4)
                        });
                    }
                    reader.NextResult();
                    reader.Read();

                    Surah.No = reader.GetInt32(0);
                    Surah.Arabic = reader.GetString(1);
                    Surah.Bangla = reader.GetString(2);

                    connection.Close();
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Ayah)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Surah)));
        }
            catch (Exception) {
                MessageBox.Show("Some error", "Error");
            }
}
    }
}
