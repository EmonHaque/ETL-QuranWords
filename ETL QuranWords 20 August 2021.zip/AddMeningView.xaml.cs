﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    public partial class AddMeningView : UserControl
    {
        string query;
        public string Query {
            get { return query; }
            set {
                query = value?.Trim();
                CleanWords.Refresh();
            }
        }
        WordMeaning selectedCleanWord;
        public WordMeaning SelectedCleanWord {
            get { return selectedCleanWord; }
            set { selectedCleanWord = value; getWordList(); }
        }
        WordMeaning selectedMinimalWord;
        public WordMeaning SelectedMinimalWord {
            get { return selectedMinimalWord; }
            set { selectedMinimalWord = value; getMinimalOccurences(); }
        }
        WordMeaning selectedFullWord;
        public WordMeaning SelectedFullWord {
            get { return selectedFullWord; }
            set { selectedFullWord = value; getFullOccurences(); }
        }
        ObservableCollection<WordMeaning> cleanWords;
        public ICollectionView CleanWords { get; set; }
        public ObservableCollection<WordMeaning> MinimalWords { get; set; }
        public ObservableCollection<WordMeaning> FullWords { get; set; }
        public ObservableCollection<Occurence> Occurences { get; set; }
        public ObservableCollection<Occurence> MinimalOccurences { get; set; }
        public ObservableCollection<Occurence> FullOccurences { get; set; }

        public AddMeningView() {
            InitializeComponent();
            getWords();
            CleanWords = new CollectionViewSource() { Source = cleanWords }.View;
            CleanWords.Filter = startWithFilter;
            MinimalWords = new ObservableCollection<WordMeaning>();
            FullWords = new ObservableCollection<WordMeaning>();
            Occurences = new ObservableCollection<Occurence>();
            MinimalOccurences = new ObservableCollection<Occurence>();
            FullOccurences = new ObservableCollection<Occurence>();
            DataContext = this;
        }
        void getWords() {
            cleanWords = new ObservableCollection<WordMeaning>();
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = "SELECT Clean, Count(*) Number FROM Segments WHERE IsComplete ISNULL GROUP BY Clean ORDER BY Number DESC";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    cleanWords.Add(new WordMeaning() {
                        Word = reader.GetString(0),
                        Occurence = reader.GetInt32(1)
                    });
                }
                connection.Close();
            }
        }
        void getWordList() {
            MinimalWords.Clear();
            FullWords.Clear();
            Occurences.Clear();
            if (SelectedCleanWord is null) return;
            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = @"SELECT Minimal, COUNT(*) Number FROM Segments WHERE Clean = @Word GROUP BY Minimal;
                                        SELECT Full, COUNT(*) Number FROM Segments WHERE Clean = @Word GROUP BY Full;
                                        SELECT * FROM Segments WHERE Clean = @Word";
                command.Parameters.AddWithValue("@Word", SelectedCleanWord.Word);
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    MinimalWords.Add(new WordMeaning() {
                        Word = reader.GetString(0),
                        Occurence = reader.GetInt32(1)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    FullWords.Add(new WordMeaning() {
                        Word = reader.GetString(0),
                        Occurence = reader.GetInt32(1)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    Occurences.Add(new Occurence() {
                        Surah = reader.GetInt32(0),
                        Ayah = reader.GetInt32(1),
                        WordNo = reader.GetInt32(2),
                        Clean = reader.GetString(4),
                        Minimal = reader.GetString(5),
                        Full = reader.GetString(6)
                    });
                }
                connection.Close();
            }
        }

        bool startWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((WordMeaning)o).Word.StartsWith(Query);
        }
        bool endWithFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((WordMeaning)o).Word.EndsWith(Query);
        }
        bool containFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((WordMeaning)o).Word.Contains(Query);
        }
        bool equalFilter(object o) {
            if (string.IsNullOrWhiteSpace(Query)) return true;
            return ((WordMeaning)o).Word.Equals(Query);
        }

        void getMinimalOccurences() {
            MinimalOccurences.Clear();
            if (SelectedMinimalWord is null) return;
            foreach (var word in Occurences) {
                if (word.Minimal.Equals(SelectedMinimalWord.Word))
                    MinimalOccurences.Add(word);
            }
        }
        void getFullOccurences() {
            FullOccurences.Clear();
            if (SelectedFullWord is null) return;
            foreach (var word in Occurences) {
                if (word.Full.Equals(SelectedFullWord.Word))
                    FullOccurences.Add(word);
            }
        }
        void SetFilter(object sender, SelectionChangedEventArgs e) {
            if (CleanWords is null) return;
            var content = ((ComboBoxItem)e.AddedItems[0]).Content;
            switch (content) {
                case "Starts with": CleanWords.Filter = startWithFilter; break;
                case "Ends with": CleanWords.Filter = endWithFilter; break;
                case "Contains": CleanWords.Filter = containFilter; break;
                case "Equals": CleanWords.Filter = equalFilter; break;
            }
        }
        void Sort(object sender, RoutedEventArgs e) {
            var button = (Button)sender;
            CleanWords.SortDescriptions.Clear();
            if (button.Content.ToString().Contains("DESC")) {
                button.Content = "Sort ASC";
                CleanWords.SortDescriptions.Add(new SortDescription("Occurence", ListSortDirection.Ascending));
            }
            else {
                button.Content = "Sort DESC";
                CleanWords.SortDescriptions.Add(new SortDescription("Occurence", ListSortDirection.Descending));
            }
        }
    }
}
