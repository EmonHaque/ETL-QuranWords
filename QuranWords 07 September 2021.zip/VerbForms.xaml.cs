﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace QuranWords
{
    public partial class VerbForms : UserControl
    {
        Grid topGrid, sideGrid, mainGrid;
        SolidColorBrush brush;
        ColorAnimation anim;

        bool gender;
        public bool Gender {
            get { return gender; }
            set { gender = value; conjugate(); }
        }
        bool? person;
        public bool? Person {
            get { return person; }
            set { person = value; conjugate(); }
        }
        bool? number;
        public bool? Number {
            get { return number; }
            set { number = value; conjugate(); }
        }

        public List<VerbDef> VerbDefs { get; set; }
       
        public VerbForms() {
            Gender = true;
            Person = Number = true;
            InitializeComponent();
            brush = new SolidColorBrush(Colors.Black);
            getVerbs();
            anim = new ColorAnimation() {
                From = Colors.Red,
                Duration = TimeSpan.FromSeconds(2)
            };
            var topLeftBlock = new TextBlock() {
                Text = "Forms",
                FontSize = 40,
                Margin = new Thickness(0, 0, 20, 0),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Green,
                FontWeight = FontWeights.Bold
            };
            var topLeftBorder = new Border() {
                BorderThickness = new Thickness(0, 1, 1, 1),
                BorderBrush = Brushes.Black,
                Child = topLeftBlock
            };
            contentGrid.Children.Add(topLeftBorder);
            DataContext = this;
        }

        void getVerbs() {
            VerbDefs = new List<VerbDef>();
            var patterns = new List<VerbPattern>();

            lock (App.Key) {
                using var connection = new SqliteConnection("data source = quran.db");
                connection.Open();
                using var command = connection.CreateCommand();
                command.CommandText = @"SELECT * FROM VerbDef;
                                        SELECT * FROM VerbForms";
                var reader = command.ExecuteReader();
                while (reader.Read()) {
                    VerbDefs.Add(new VerbDef() {
                        Id = reader.GetInt32(0),
                        Arabic = reader.GetString(1),
                        English = reader.GetString(2)
                    });
                }
                reader.NextResult();
                while (reader.Read()) {
                    patterns.Add(new VerbPattern() {
                        PatternNo = reader.GetInt32(0),
                        DefId = reader.GetInt32(1),
                        SubPatternNo = reader.GetInt32(2),
                        Pattern = reader.GetString(3)
                    });
                }
                connection.Close();
            }

            var groups = patterns.GroupBy(x => x.PatternNo, (k, v) => new { No = k, Values = v });
            mainGrid = new Grid() { ShowGridLines = true };
            sideGrid = new Grid() { ShowGridLines = true };
            topGrid = new Grid() { ShowGridLines = true };

            for (int i = 0; i < 8; i++) {
                mainGrid.RowDefinitions.Add(new RowDefinition() { SharedSizeGroup = "row" + i });
                sideGrid.RowDefinitions.Add(new RowDefinition() { SharedSizeGroup = "row" + i });
                mainGrid.ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col" + i });
                if (i > 2) topGrid.ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col" + i });
            }
            for (int i = 0; i < 11; i++) {
                mainGrid.ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col" + (i + 8) });
                if(i < 7 || i > 9)
                    topGrid.ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col" + (i + 8) });
            }
            topGrid.ColumnDefinitions.Insert(0, new ColumnDefinition()); // for form 1    
            topGrid.ColumnDefinitions.Insert(13, new ColumnDefinition()); // for form 14    

            var sideBorder = new Border() {
                BorderThickness = new Thickness(0, 0, 1, 0),
                BorderBrush = Brushes.Black
            };
            var topBorder = new Border() {
                BorderThickness = new Thickness(0, 1, 0, 1),
                BorderBrush = Brushes.Black
            };
            Grid.SetRowSpan(sideBorder, sideGrid.RowDefinitions.Count);
            Grid.SetColumnSpan(topBorder, topGrid.ColumnDefinitions.Count);
            sideGrid.Children.Add(sideBorder);
            topGrid.Children.Add(topBorder);

            for (int i = 0; i < 8; i++) {
                var sideHead = new TextBlock() {
                    Inlines = {
                        new Run() {
                            Text = VerbDefs[i].Arabic,
                            Foreground = Brushes.Green,
                            FontSize = 40,
                            FontFamily = new FontFamily("Scheherazade")
                        },
                        new LineBreak(),
                        new Run(){ Text = VerbDefs[i].English, Foreground = Brushes.LightBlue, FontSize = 20 }
                        },
                    Margin = new Thickness(0, 0, 20, 0),
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetRow(sideHead, i);
                sideGrid.Children.Add(sideHead);
            }

            int colIndex = 0;
            foreach (var group in groups) {
                if (group.No == 1 || group.No == 14) {
                    var subGroups = group.Values.GroupBy(x => x.SubPatternNo, (k, v) => new { No = k, Values = v });
                    var headGrid = new Grid() {
                        RowDefinitions = {
                            new RowDefinition(),
                            new RowDefinition()
                        }
                    };
                    Grid.SetColumn(headGrid, group.No - 1);
                    topGrid.Children.Add(headGrid);

                    var subGroupsCount = subGroups.Count();
                    var headBlock = new TextBlock() {
                        Text = "Form " + group.No,
                        FontSize = 20,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    Grid.SetColumnSpan(headBlock, subGroupsCount);
                    headGrid.Children.Add(headBlock);

                    foreach (var subGroup in subGroups) {
                        headGrid.ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col" + colIndex });
                        var rect = new Rectangle() {
                            Stroke = Brushes.Gray,
                            StrokeDashArray = { 4d, 4d }
                        };
                        var rightThickness = headGrid.ColumnDefinitions.Count == subGroupsCount ? 0 : 1;
                        var border = new Border() {
                            BorderBrush = new VisualBrush() { Visual = rect },
                            BorderThickness = new Thickness(0, 1, rightThickness, 0)
                        };
                        rect.SetBinding(Rectangle.WidthProperty, new Binding("ActualWidth") { Source = border });
                        rect.SetBinding(Rectangle.HeightProperty, new Binding("ActualHeight") { Source = border });
                        Grid.SetColumn(border, headGrid.ColumnDefinitions.Count - 1);
                        Grid.SetRow(border, 1);
                        headGrid.Children.Add(border);

                        var subHeadBlock = new TextBlock() {
                            Text = "Pattern " + subGroup.No,
                            FontSize = 15,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        };
                        Grid.SetColumn(subHeadBlock, headGrid.ColumnDefinitions.Count - 1);
                        Grid.SetRow(subHeadBlock, 1);
                        headGrid.Children.Add(subHeadBlock);

                        int rowIndex = 0;
                        foreach (var pattern in subGroup.Values) {
                            var content = new TextBlock() {
                                Text = pattern.Pattern,
                                FlowDirection = FlowDirection.RightToLeft,
                                FontFamily = new FontFamily("Scheherazade"),
                                FontSize = 50,
                                HorizontalAlignment = HorizontalAlignment.Center,
                                Margin = new Thickness(10, 0, 10, 0)
                            };
                            if(rowIndex < 5) {
                                content.Foreground = brush;
                                int subLength = rowIndex == 4 ? 0 : 1;
                                content.Tag = pattern.Pattern.Substring(0, pattern.Pattern.Length - subLength);
                            }
                            if (rowIndex == 4) content.Text = "-";
                            Grid.SetColumn(content, colIndex);
                            Grid.SetRow(content, rowIndex++);
                            mainGrid.Children.Add(content);
                        }
                        colIndex++;
                    }
                }
                else {
                    var headBlock = new TextBlock() {
                        Text = "Form " + group.No,
                        FontSize = 20,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center
                    };
                    Grid.SetColumn(headBlock, group.No - 1);
                    topGrid.Children.Add(headBlock);

                    int rowIndex = 0;
                    foreach (var pattern in group.Values) {
                        var content = new TextBlock() {
                            Text = pattern.Pattern,
                            FlowDirection = FlowDirection.RightToLeft,
                            FontFamily = new FontFamily("Scheherazade"),
                            FontSize = 50,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            Margin = new Thickness(10, 0, 10, 0)
                        };
                        if (rowIndex < 5) {
                            content.Foreground = brush;
                            int subLength = rowIndex == 4 ? 0 : 1;
                            content.Tag = pattern.Pattern.Substring(0, pattern.Pattern.Length - subLength);
                        }
                        if (rowIndex == 4) content.Text = "-";
                        Grid.SetColumn(content, colIndex);
                        Grid.SetRow(content, rowIndex++);
                        mainGrid.Children.Add(content);
                    }
                    colIndex++;
                }
            }
            
            topScroll.Margin = new Thickness(0, 0, SystemParameters.VerticalScrollBarWidth, 0);
            sideScroll.Margin = new Thickness(0, 0, 0, SystemParameters.HorizontalScrollBarHeight);
            topScroll.Content = topGrid;
            sideScroll.Content = sideGrid;
            mainScroll.Content = mainGrid;
        }

        void conjugate() {
            if (mainGrid is null) return;
            string pastBeginning = "";
            string pastEnding = "";
            string presentBeginning = "";
            string presentEnding = "";
            string imperativeEnding = "";
            string x = "";
            if (Gender) {
                //Masculine
                switch (Person) {
                    case true: // third
                        if (Number is null) x = "3MD"; // third person masculine dual
                        else if (Number.Value) x = "3MS"; // singular
                        else x = "3MP"; // plural
                        break;
                    case false: // first
                        if (Number is null) x = "1MD"; // first person masculine dual
                        else if (Number.Value) x = "1MS"; // singular
                        else x = "1MP"; // plural
                        break;
                    default: // second
                        if (Number is null) x = "2MD"; // second person masculine dual
                        else if (Number.Value) x = "2MS"; // singular
                        else x = "2MP"; // plural
                        break;
                }
            }
            else {
                switch (Person) {
                    case true: // third
                        if (Number is null) x = "3FD"; // third person feminine dual
                        else if (Number.Value) x = "3FS"; // singular
                        else x = "3FP"; // plural
                        break;
                    case false: // first
                        if (Number is null) x = "1FD"; // first person feminine dual
                        else if (Number.Value) x = "1FS"; // singular
                        else x = "1FP"; // plural
                        break;
                    default: // second
                        if (Number is null) x = "2FD"; // second person feminine dual
                        else if (Number.Value) x = "2FS"; // singular
                        else x = "2FP"; // plural
                        break;
                }
            }

            switch (x) {
                case "3MS":
                    pastEnding = "َ"; // fatha
                    presentEnding = "ُ"; // damma
                    break;
                case "3FS":
                    pastEnding = "َت"; // fatha
                    presentBeginning = "ت";
                    presentEnding = "ُ"; // damma
                    break;
                case "3MD":
                    pastEnding = "َا"; // fatha
                    presentEnding = "انِ";
                    break;
                case "3FD":
                    pastEnding = "َتا"; // fatha
                    presentBeginning = "ت";
                    presentEnding = "انِ";
                    break;
                case "3MP":
                    pastEnding = "وا";
                    presentEnding = "ونَ";
                    break;
                case "3FP":
                    pastEnding = presentEnding = "نَ";
                    break;
                case "2MS":
                    pastEnding = "تَ";
                    presentBeginning = "ت";
                    presentEnding = "ُ"; // damma
                    break;
                case "2FS":
                    pastEnding = "تِ";
                    presentBeginning = "ت";
                    presentEnding = "ينَ";
                    imperativeEnding = "ِي"; // kesra
                    break;
                case "2MD":
                case "2FD":
                    pastEnding = "تُما";
                    presentBeginning = "ت";
                    presentEnding = "انِ";
                    imperativeEnding = "ا";
                    break;
                case "2MP":
                    pastEnding = "تُم";
                    presentBeginning = "ت";
                    presentEnding = "ونَ";
                    imperativeEnding = "وا";
                    break;
                case "2FP":
                    pastEnding = "تُنَّ";
                    presentBeginning = "ت";
                    presentEnding = "نَ";
                    imperativeEnding = "نَ";
                    break;
                case "1MS":
                case "1FS":
                    pastEnding = "تُ";
                    presentBeginning = "ا";
                    presentEnding = "ُ"; // damma
                    break;
                case "1MD":
                case "1FD":
                case "1MP":
                case "1FP":
                    pastEnding = "نا";
                    presentBeginning = "ن";
                    presentEnding = "ُ"; // damma
                    break;
            }

            foreach (UIElement child in mainGrid.Children) {
                var block = (TextBlock)child;
                var row = Grid.GetRow(block);
                if(row == 0 || row == 1) {
                    block.Text = pastBeginning + block.Tag + pastEnding;
                }
                else if(row == 2 || row == 3) {
                    var tag = block.Tag;
                    if (!string.Equals(presentBeginning, ""))
                        tag = tag.ToString().Substring(1, tag.ToString().Length - 1);
                    block.Text = presentBeginning + tag + presentEnding;
                }
                else if(row == 4) {
                    if (Person is null) {
                        var tag = block.Tag.ToString();
                        var singular = Number.HasValue ? Number.Value : false;
                        if(!Gender && singular) {
                            var column = Grid.GetColumn(block);
                            if (column == 10 || column == 17)
                                tag = tag.Substring(0, tag.Length - 1);
                        }
                        block.Text = tag + imperativeEnding;
                    }
                    else block.Text = "-";
                }
            }
            brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
        }

        void onScrollChanged(object sender, ScrollChangedEventArgs e) {
            topScroll.ScrollToHorizontalOffset(e.HorizontalOffset);
            sideScroll.ScrollToVerticalOffset(e.VerticalOffset);
        }
    }
}
