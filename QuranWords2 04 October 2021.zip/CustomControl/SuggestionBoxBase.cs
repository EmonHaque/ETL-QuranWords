﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;

namespace Quran2.CustomControl
{
    public abstract class SuggestionBoxBase : TextBox
    {
        bool userMode;
        Popup popSuggestion;
        protected ListBox listSuggestion;
        protected abstract ICollectionView source { get; }
        protected abstract void setText();
        protected abstract void setQueryAndRefresh();

        public SuggestionBoxBase() {
            FontSize = 20;
            Margin = new Thickness(5);
            HorizontalContentAlignment = HorizontalAlignment.Stretch;
            VerticalAlignment = VerticalAlignment.Stretch;
            VerticalContentAlignment = VerticalAlignment.Center;

            listSuggestion = new ListBox() {
                BorderThickness = new Thickness(0),
                HorizontalContentAlignment = HorizontalAlignment.Stretch,
                ItemsSource = source
            };
            listSuggestion.SetValue(TextElement.FontSizeProperty, 20d);

            popSuggestion = new Popup() {
                VerticalOffset = 5,
                HorizontalOffset = 10,
                MaxHeight = 300,
                StaysOpen = false,
                PlacementTarget = this,
                Child = listSuggestion
            };
            Loaded += subscribe;
            Unloaded += unSubscribe;
        }

        void subscribe(object sender, RoutedEventArgs e) {
            listSuggestion.KeyUp += setTextOnEnter;
            listSuggestion.MouseLeftButtonUp += setTextOnClick;
            userMode = true;
        }

        void unSubscribe(object sender, RoutedEventArgs e) {
            listSuggestion.KeyUp -= setTextOnEnter;
            listSuggestion.MouseLeftButtonUp -= setTextOnClick;
        }

        void setTextOnClick(object sender, MouseButtonEventArgs e) {
            setText();
            CaretIndex = Text.Length;
            popSuggestion.IsOpen = false;
            Keyboard.Focus(this);
        }

        void setTextOnEnter(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            setText();
            CaretIndex = Text.Length;
            popSuggestion.IsOpen = false;
            Keyboard.Focus(this);
        }
        
        protected override void OnKeyUp(KeyEventArgs e) {
            if (e.Key != Key.Down) return;
            if (popSuggestion.IsOpen) {
                listSuggestion.SelectedIndex = 0;
                Keyboard.Focus((ListBoxItem)listSuggestion.ItemContainerGenerator.ContainerFromItem(listSuggestion.SelectedItem));
            }
        }
        protected override void OnTextChanged(TextChangedEventArgs e) {
            if (!userMode) return;
            if (string.IsNullOrWhiteSpace(Text)) return;
            setQueryAndRefresh();
            popSuggestion.PlacementRectangle = GetRectFromCharacterIndex(CaretIndex);
            popSuggestion.IsOpen = true;
        }
    }
}
