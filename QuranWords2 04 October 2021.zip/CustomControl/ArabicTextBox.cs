﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Quran2.CustomControl
{
    class ArabicTextBox : TextBox
    {
        public ArabicTextBox() {
            FontFamily = new FontFamily("Scheherazade");
            FontSize = 40;
            FlowDirection = FlowDirection.RightToLeft;
            HorizontalAlignment = HorizontalAlignment.Stretch;
            VerticalAlignment = VerticalAlignment.Stretch;
            VerticalContentAlignment = VerticalAlignment.Center;
            Margin = new Thickness(5);
        }
    }
}
