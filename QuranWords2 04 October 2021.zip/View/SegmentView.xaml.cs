﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Quran2
{
    public partial class SegmentView : UserControl, INotifyPropertyChanged
    {
        string query;
        public string Query {
            get { return query; }
            set { query = value.Trim(); Segments.Refresh(); }
        }

        public CorpusData SegmentInfo { get; set; }
        public ICollectionView Segments { get; set; }
        public static event Action SegmentsAdded;
        public event PropertyChangedEventHandler PropertyChanged;

        public SegmentView() {
            InitializeComponent();
            Segments = new CollectionViewSource() { Source = App.segments }.View;
            Segments.Filter = filterContains;
            SegmentInfo = new();
            DataContext = this;
            WordView.SegmentsChanged += onSegmentsChanged;
        }

        void onSegmentsChanged() {
            Segments = new CollectionViewSource() { Source = App.segments }.View;
            resetFilter(null, null);
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Segments)));
        }

        bool filterContains(object o) {
            if (string.IsNullOrEmpty(Query)) return true;
            return ((Segment)o).Content.Contains(Query);
        }
        bool filterStartsWith(object o) {
            if (string.IsNullOrEmpty(Query)) return true;
            return ((Segment)o).Content.StartsWith(Query);
        }
        bool filterPatternStartsWith(object o) {
            if (string.IsNullOrEmpty(Query)) return true;
            var segment = ((Segment)o).Content;
            bool match = segment.Length >= Query.Length;
            if (match) {
                for (int i = 0; i < Query.Length; i++) {
                    if (Query[i].Equals('ـ')) continue; // Shift + B
                    if (!Query[i].Equals(segment[i])) {
                        match = false;
                        break;
                    }
                }
            }
            return match;
        }
        bool filterPatternEquals(object o) {
            if (string.IsNullOrEmpty(Query)) return true;
            if (string.IsNullOrWhiteSpace(Query)) return true;
            var segment = ((Segment)o).Content;
            bool match = segment.Length == Query.Length;
            if (match) {
                for (int i = 0; i < Query.Length; i++) {
                    if (Query[i].Equals('ـ')) continue; // Shift + B
                    if (!Query[i].Equals(segment[i])) {
                        match = false;
                        break;
                    }
                }
            }
            return match;
        }
        void resetFilter(object sender, SelectionChangedEventArgs e) {
            if (Segments is null) return;
            var content = ((ComboBoxItem)filterCombo.SelectedItem).Content;
            switch (content) {
                case "Contains": Segments.Filter = filterContains; break;
                case "Starts with": Segments.Filter = filterStartsWith; break;
                case "Pattern starts with": Segments.Filter = filterPatternStartsWith; break;
                case "Pattern equals": Segments.Filter = filterPatternEquals; break;
            }
        }

        async void segregate(object sender, RoutedEventArgs e) {
            if(segmentList.SelectedItems.Count == 0) {
                MessageBox.Show("Select one or more Segment", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var list = segmentList.SelectedItems.Cast<Segment>().ToList();
            var isLeading = head.IsChecked.Value;
            List<CorpusData> removed = new();

            await Task.Run(() => updateSegments(list, isLeading, removed));

            SegmentsAdded?.Invoke();

            SegmentInfo = new();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SegmentInfo)));
            App.getSegments();
            onSegmentsChanged();
        }

        void updateSegments(List<Segment> list, bool isLeading, List<CorpusData> removed) {
            Dispatcher.Invoke(() => infoBlock.Text = "Updating ...");
            var refs = App.corpusData
                .Where(x => list.Any(y => y.Content.Equals(x.Content) && y.POS.Equals(x.POS) && y.Detail.Equals(x.Detail)))
                .Select(x => new { x.Surah, x.Ayah, x.Word, x.Segment })
                .ToList();

            var occurences = App.corpusData
                .Where(x => refs.Any(y => y.Surah == x.Surah && y.Ayah == x.Ayah && y.Word == x.Word && x.Segment >= y.Segment))
                .GroupBy(x => new { x.Surah, x.Ayah, x.Word }, (r, l) => new {
                    Surah = r.Surah,
                    Ayah = r.Ayah,
                    word = r.Word,
                    Segments = l.ToList()
                })
                .ToList();

            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();
            command.Transaction = transaction;

            foreach (var occurence in occurences) {
                var seg = occurence.Segments.First();

                if (isLeading && !seg.Content.StartsWith(SegmentInfo.Content)) {
                    Dispatcher.Invoke(() => {
                        MessageBox.Show($"{seg.Content} doesn't start with {SegmentInfo.Content}");
                        infoBlock.Text = "Operation suspended";
                    });
                    return;
                }
                else if(!isLeading && !seg.Content.EndsWith(SegmentInfo.Content)) {
                    Dispatcher.Invoke(() => {
                        MessageBox.Show($"{seg.Content} doesn't end with {SegmentInfo.Content}");
                        infoBlock.Text = "Operation suspended";
                    });
                    return;
                }

                if(seg.Content.Length <= SegmentInfo.Content.Length) {
                    Dispatcher.Invoke(() => {
                        MessageBox.Show($"{seg.Content} cannot be segmented further");
                        infoBlock.Text = "Operation suspended";
                    });
                    return;
                }
                int newSegmentNo = 0;
                if (isLeading) {
                    newSegmentNo = seg.Segment;
                    seg.Content = seg.Content.Remove(0, SegmentInfo.Content.Length);
                }
                else {
                    newSegmentNo = seg.Segment + 1;
                    seg.Content = seg.Content.Remove(seg.Content.LastIndexOf(SegmentInfo.Content), SegmentInfo.Content.Length);
                }

                for (int i = 0; i < occurence.Segments.Count; i++) {
                    App.corpusData.Remove(occurence.Segments[i]);
                    removed.Add(occurence.Segments[i]);
                    command.CommandText = $@"DELETE FROM CorpusSegment WHERE Surah = {occurence.Segments[i].Surah} AND 
                                             Ayah = {occurence.Segments[i].Ayah} AND Word = {occurence.Segments[i].Word} 
                                             AND Segment = {occurence.Segments[i].Segment}";
                    command.ExecuteNonQuery();
                    if (i == 0) {
                        if (isLeading)
                            ++occurence.Segments[i].Segment;
                    }
                    else ++occurence.Segments[i].Segment;
                }
                var data = new CorpusData() {
                    Surah = seg.Surah,
                    Ayah = seg.Ayah,
                    Word = seg.Word,
                    Segment = newSegmentNo,
                    Content = SegmentInfo.Content,
                    POS = SegmentInfo.POS,
                    Detail = SegmentInfo.Detail
                };

                if (isLeading) occurence.Segments.Insert(0, data);
                else occurence.Segments.Insert(1, data);

                foreach (var segment in occurence.Segments) {
                    App.corpusData.Add(segment);
                    command.CommandText = $@"INSERT INTO CorpusSegment VALUES ({segment.Surah}, {segment.Ayah}, {segment.Word}, 
                                             {segment.Segment}, '{segment.Content}', '{segment.POS}', '{segment.Detail}',
                                             '{segment.Root}', null, null)";
                    command.ExecuteNonQuery();
                }
            }

            transaction.Commit();
            connection.Close();

            Dispatcher.Invoke(() => infoBlock.Text = "Done");
        }
    }
}
