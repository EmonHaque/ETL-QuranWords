﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Quran2
{
    public partial class POSDetail : UserControl, INotifyPropertyChanged
    {
        public PartsOfSpeech POS { get; set; }
        public Details Detail { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;

        public POSDetail() {
            InitializeComponent();
            POS = new();
            Detail = new();
            DataContext = this;
        }

        void addDetails(object sender, RoutedEventArgs e) {
            Detail.Id = App.details.Max(x => x.Id) + 1;
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = "INSERT INTO Details(Tag, Name, Description) VALUES(@Tag, @Name, @Description)";
            command.Parameters.AddWithValue("@Tag", Detail.Tag);
            command.Parameters.AddWithValue("@Name", Detail.Name);
            command.Parameters.AddWithValue("@Description", Detail.Description);
            command.ExecuteNonQuery();
            connection.Close();

            App.details.Add(Detail);
            Detail = new();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Detail)));
        }

        void addPartsOfSpeech(object sender, RoutedEventArgs e) {
            POS.Id = App.poss.Max(x => x.Id) + 1;
            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = "INSERT INTO PartsOfSpeech(Name, Tag, Description) VALUES(@Name, @Tag, @Description)";
            command.Parameters.AddWithValue("@Name", POS.Name);
            command.Parameters.AddWithValue("@Tag", POS.Tag);
            command.Parameters.AddWithValue("@Description", POS.Description);
            command.ExecuteNonQuery();
            connection.Close();

            App.poss.Add(POS);
            POS = new();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(POS)));
        }
    }
}
