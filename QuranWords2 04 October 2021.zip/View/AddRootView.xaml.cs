﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Quran2
{
    public partial class AddRootView : UserControl, INotifyPropertyChanged
    {
        public Root Root { get; set; }
        public ObservableCollection<RootLess> Roots { get; set; }
        public event PropertyChangedEventHandler PropertyChanged;

        public AddRootView() {
            InitializeComponent();
            Root = new();
            Roots = new ObservableCollection<RootLess>(App.rootLess);
            DataContext = this;
        }

        void update(object sender, RoutedEventArgs e) {
            if (rootList.SelectedItem is null) {
                MessageBox.Show("Select and Edit a word/letter", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if(App.roots.FirstOrDefault(x => x.CorpusRoot.Equals(Root.CorpusRoot)) is not null) {
                MessageBox.Show("Root exists", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            var roots = rootList.SelectedItems.Cast<RootLess>().ToList();
            var occurences = App.corpusData.Where(x => roots.Any(y => x.Content.Equals(y.Content))).ToList();

            using var connection = new SqliteConnection("data source = quran.db");
            connection.Open();
            var transaction = connection.BeginTransaction();
            using var command = connection.CreateCommand();

            foreach (var o in occurences) {
                command.CommandText = $@"UPDATE CorpusSegment SET Root = '{Root.CorpusRoot}' WHERE Content = '{o.Content}'";
                command.ExecuteNonQuery();
                o.Root = Root.CorpusRoot;
            }
            command.CommandText = @$"INSERT INTO Roots(Root, PRLKey, Meaning, Reference, IsCorpusRoot, IsOk) 
                                     VALUES(@Root, @Key, @Meaning, @Reference, null, 1)";
            command.Parameters.AddWithValue("@Root", Root.CorpusRoot);
            command.Parameters.AddWithValue("@Key", Root.PRLKey);
            command.Parameters.AddWithValue("@Meaning", Root.Meaning);
            command.Parameters.AddWithValue("@Reference", Root.Reference);
            command.ExecuteNonQuery();

            transaction.Commit();
            connection.Close();

            var first = roots.First();
            App.roots.Add(new Root() {
                Id = App.roots.Max(x => x.Id) + 1,
                CorpusRoot = Root.CorpusRoot,
                PRLKey = Root.PRLKey,
                Meaning = Root.Meaning,
                Reference = Root.Reference,
                IsCorpusRoot = false,
                IsOk = true
            });
            for (int i = 0; i < roots.Count; i++) Roots.Remove(roots[i]);


            Root = new Root();
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Root)));

        }
    }
}
